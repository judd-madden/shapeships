/**
 * Centaur Ship Catalogue Panel
 * 
 * Cloned from XeniteShipCataloguePanel.tsx
 * - Portal-based hover cards with ship rules from JSON
 * - Build eligibility feedback (UI-only, no backend)
 * - Uses canonical ship IDs from ShipDefinitionsUI
 * - Hand-authored layout matching Figma design exactly
 * 
 * NO backend calls, NO rules validation, NO engine imports
 */

import type { ActionPanelViewModel, GameSessionActions } from '../../../../../client/useGameSession';
import { ActionPanelScrollArea } from '../../../primitives/ActionPanelScrollArea';
import { CatalogueShipSlot } from '../shared/CatalogueShipSlot';
import { CatalogueCostNumber } from '../shared/CatalogueCostNumber';
import { ShipHoverCard } from '../shared/ShipHoverCard';
import { useShipCatalogueHover } from '../shared/useShipCatalogueHover';
import { getShipEligibilityForHover } from '../shared/ShipBuildEligibility';
import type { ShipDefId } from '../../../../../types/ShipTypes.engine';
import {
  ShipOfFearShip,
  ShipOfAngerShip,
  ShipOfEquality2Ship,
  ShipOfWisdom2Ship,
  ShipOfVigorShip,
  ShipOfFamily3Ship,
  ShipOfLegacyShip,
  ArkOfRedemptionShip,
  ArkOfTerrorShip,
  ArkOfFuryShip,
  ArkOfKnowledgeShip,
  ArkOfEntropyShip,
  ArkOfPowerShip,
  ArkOfDestructionShip,
  ArkOfDominationShip,
} from '../../../../../../graphics/centaur/assets';

type CatalogueFrame = 'desktop' | 'bare';
type CatalogueLayout = 'standard' | 'long';

const CENTAUR_DESKTOP_CANVAS = { width: 1210, height: 290 };
const CENTAUR_LONG_CANVAS = { width: 1446, height: 258 };

interface CentaurShipCataloguePanelProps {
  actions: GameSessionActions;
  buildCatalogue: ActionPanelViewModel['buildCatalogue'];
  frame?: CatalogueFrame;
  catalogueLayout?: CatalogueLayout;
  hoverDisabled?: boolean;
  interactionDisabled?: boolean;
  onShipInspect?: (shipId: ShipDefId) => void;
}

export function CentaurShipCataloguePanel({
  actions,
  buildCatalogue,
  frame = 'desktop',
  catalogueLayout = 'standard',
  hoverDisabled,
  interactionDisabled = false,
  onShipInspect,
}: CentaurShipCataloguePanelProps) {
  const hover = useShipCatalogueHover(hoverDisabled);
  const isBuildableContext = buildCatalogue.context === 'buildable';
  const isUnavailableContext = buildCatalogue.context === 'unavailable';
  const isLongCatalogueLayout = catalogueLayout === 'long';
  const canvas = isLongCatalogueLayout ? CENTAUR_LONG_CANVAS : CENTAUR_DESKTOP_CANVAS;
  const destructionPosition = isLongCatalogueLayout
    ? { left: '982px', top: '78px', width: '196.02px' }
    : { left: '1022px', top: '47px', width: '196.02px' };
  const dominationPosition = isLongCatalogueLayout
    ? { left: '1145px', top: '2px', width: '312.57px' }
    : { left: '755px', top: '150px', width: '312.57px' };
  const redemptionPosition = isLongCatalogueLayout
    ? { left: '702px', top: '25px', width: '165.564px' }
    : { left: '710px', top: '24.97px', width: '165.564px' };
  const powerPosition = isLongCatalogueLayout
    ? { left: '829px', top: '-5px', width: '220.57px' }
    : { left: '852px', top: '0', width: '220.57px' };

  function getSlotProps(shipId: ShipDefId) {
    const canAddShip = buildCatalogue.canAddShipById[shipId] === true;
    const isDimmed = isUnavailableContext || (isBuildableContext && !canAddShip);

    if (onShipInspect) {
      return {
        isDimmed,
        isClickable: true,
        onClick: () => onShipInspect(shipId),
      };
    }

    if (interactionDisabled) {
      return {
        isDimmed,
        isClickable: false,
      };
    }

    return {
      isDimmed,
      isClickable: isBuildableContext && canAddShip,
      onClick: () => actions.onBuildShip(shipId),
    };
  }

  function getDisplayCost(shipId: ShipDefId, fallbackCost: number): number {
    return isBuildableContext
      ? (buildCatalogue.displayCostByShipId[shipId] ?? fallbackCost)
      : fallbackCost;
  }

  const hoveredShipEligibility = hover.state.activeShipId
    ? getShipEligibilityForHover({
        shipId: hover.state.activeShipId,
        buildCatalogue,
      })
    : null;

  const content = (
    /* Container with exact width from Figma */
    <div
      className="relative"
      style={{
        width: `${canvas.width}px`,
        minHeight: `${canvas.height}px`,
        ...(frame === 'bare' ? { height: `${canvas.height}px` } : {}),
      }}
    >

          {/* Section Titles */}
          <p
            className="absolute font-['Roboto'] font-bold leading-[normal] text-[18px] text-white"
            style={{ left: '0', top: '0', fontVariationSettings: "'wdth' 100" }}
          >
            Centaur Basic Ships
          </p>
          
          <p
            className="absolute font-['Roboto'] font-bold leading-[normal] text-[18px] text-white"
            style={{ left: '427px', top: '0', fontVariationSettings: "'wdth' 100" }}
          >
            Centaur Upgraded Ships
          </p>

          {/* Vertical Divider */}
          <div
            className="absolute bg-[var(--shapeships-grey-70)]"
            style={{ left: '406px', top: '0', width: '1px', height: `${canvas.height}px` }}
          />

          {/* ================ BASIC SHIPS ================ */}
          
          {/* Basic Row 1: FEA, ANG, EQU, WIS */}
          <div
            className="absolute content-stretch flex items-center justify-between"
            style={{ left: '0', top: '30px', width: '386px' }}
          >
            {/* Ship of Fear */}
            <div
              className="content-stretch flex flex-col items-center relative shrink-0"
              style={{ width: '36px' }}
              onMouseEnter={(e) => hover.onEnter('FEA', e.currentTarget)}              
              onMouseLeave={() => hover.onLeave('FEA')}
            >
              <CatalogueShipSlot
                shipId="FEA"
                graphic={
                  <div className="relative shrink-0" style={{ height: '36px', width: '36px' }}>
                    <ShipOfFearShip />
                  </div>
                }
                {...getSlotProps('FEA')}
              >
                <CatalogueCostNumber cost={getDisplayCost('FEA', 2)} className="min-w-full relative shrink-0 w-[min-content]" />
              </CatalogueShipSlot>
            </div>

            {/* Ship of Anger */}
            <div
              className="content-stretch flex flex-col items-center relative shrink-0"
              style={{ width: '69.3px' }}
              onMouseEnter={(e) => hover.onEnter('ANG', e.currentTarget)}              
              onMouseLeave={() => hover.onLeave('ANG')}
            >
              <CatalogueShipSlot
                shipId="ANG"
                graphic={
                  <div className="relative shrink-0" style={{ height: '36px', width: '69.3px' }}>
                    <ShipOfAngerShip />
                  </div>
                }
                {...getSlotProps('ANG')}
              >
                <CatalogueCostNumber cost={getDisplayCost('ANG', 3)} className="min-w-full relative shrink-0 w-[min-content]" />
              </CatalogueShipSlot>
            </div>

            {/* Ship of Equality (max-charge variant) */}
            <div
              className="content-stretch flex flex-col items-center relative shrink-0"
              style={{ width: '86.4px' }}
              onMouseEnter={(e) => hover.onEnter('EQU', e.currentTarget)}              
              onMouseLeave={() => hover.onLeave('EQU')}
            >
              <CatalogueShipSlot
                shipId="EQU"
                graphic={
                  <div className="relative shrink-0" style={{ height: '45px', width: '86.4px' }}>
                    <ShipOfEquality2Ship />
                  </div>
                }
                {...getSlotProps('EQU')}
              >
                <CatalogueCostNumber cost={getDisplayCost('EQU', 4)} className="min-w-full relative shrink-0 w-[min-content]" />
              </CatalogueShipSlot>
            </div>

            {/* Ship of Wisdom (max-charge variant) */}
            <div
              className="content-stretch flex flex-col items-center relative shrink-0"
              style={{ width: '81px' }}
              onMouseEnter={(e) => hover.onEnter('WIS', e.currentTarget)}
              onMouseLeave={() => hover.onLeave('WIS')}
            >
              <CatalogueShipSlot
                shipId="WIS"
                graphic={
                  <div className="relative shrink-0" style={{ height: '81px', width: '81px' }}>
                    <ShipOfWisdom2Ship />
                  </div>
                }
                {...getSlotProps('WIS')}
              >
                <CatalogueCostNumber cost={getDisplayCost('WIS', 4)} className="min-w-full relative shrink-0 w-[min-content]" />
              </CatalogueShipSlot>
            </div>
          </div>

          {/* Basic Row 2: VIG, FAM, LEG */}
          <div
            className="absolute content-stretch flex items-end justify-between"
            style={{ left: '0', top: '138px', width: '386px', paddingLeft: '16px', paddingRight: '16px' }}
          >
            {/* Ship of Vigor */}
            <div
              className="content-stretch flex flex-col items-center relative shrink-0"
              style={{ width: '86px' }}
              onMouseEnter={(e) => hover.onEnter('VIG', e.currentTarget)}
              onMouseLeave={() => hover.onLeave('VIG')}
            >
              <CatalogueShipSlot
                shipId="VIG"
                graphic={
                  <div className="relative shrink-0" style={{ height: '76px', width: '86px' }}>
                    <ShipOfVigorShip />
                  </div>
                }
                {...getSlotProps('VIG')}
              >
                <CatalogueCostNumber cost={getDisplayCost('VIG', 6)} className="min-w-full relative shrink-0 w-[min-content]" />
              </CatalogueShipSlot>
            </div>

            {/* Ship of Family (max-charge variant) */}
            <div
              className="content-stretch flex flex-col items-center relative shrink-0"
              style={{ width: '96px' }}
              onMouseEnter={(e) => hover.onEnter('FAM', e.currentTarget)}
              onMouseLeave={() => hover.onLeave('FAM')}
            >
              <CatalogueShipSlot
                shipId="FAM"
                graphic={
                  <div className="relative shrink-0" style={{ height: '96px', width: '96px' }}>
                    <ShipOfFamily3Ship />
                  </div>
                }
                {...getSlotProps('FAM')}
              >
                <CatalogueCostNumber cost={getDisplayCost('FAM', 6)} className="min-w-full relative shrink-0 w-[min-content]" />
              </CatalogueShipSlot>
            </div>

            {/* Ship of Legacy */}
            <div
              className="content-stretch flex flex-col items-center relative shrink-0"
              style={{ width: '100.8px' }}
              onMouseEnter={(e) => hover.onEnter('LEG', e.currentTarget)}
              onMouseLeave={() => hover.onLeave('LEG')}
            >
              <CatalogueShipSlot
                shipId="LEG"
                graphic={
                  <div className="relative shrink-0" style={{ height: '68.4px', width: '100.8px' }}>
                    <ShipOfLegacyShip />
                  </div>
                }
                {...getSlotProps('LEG')}
              >
                <CatalogueCostNumber cost={getDisplayCost('LEG', 8)} className="min-w-full relative shrink-0 w-[min-content]" />
              </CatalogueShipSlot>
            </div>
          </div>

          {/* ================ UPGRADED SHIPS ================ */}

          {/* Ark of Terror */}
          <div
            className="absolute content-stretch flex flex-col items-center"
            style={{ left: '427px', top: '54px', width: '112px' }}
            onMouseEnter={(e) => hover.onEnter('TER', e.currentTarget)}
              onMouseLeave={() => hover.onLeave('TER')}
          >
            <CatalogueShipSlot
              shipId="TER"
              graphic={
                <div className="relative shrink-0" style={{ height: '33px', width: '112px' }}>
                  <ArkOfTerrorShip />
                </div>
              }
              {...getSlotProps('TER')}
            >
              <CatalogueCostNumber cost={getDisplayCost('TER', 7)} className="relative shrink-0 w-full" />
            </CatalogueShipSlot>
          </div>

          {/* Ark of Fury */}
          <div
            className="absolute content-stretch flex flex-col items-center"
            style={{ left: '427px', top: '135px', width: '69.3px' }}
            onMouseEnter={(e) => hover.onEnter('FUR', e.currentTarget)}
              onMouseLeave={() => hover.onLeave('FUR')}
          >
            <CatalogueShipSlot
              shipId="FUR"
              graphic={
                <div className="relative shrink-0" style={{ height: '95.4px', width: '69.3px' }}>
                  <ArkOfFuryShip />
                </div>
              }
              {...getSlotProps('FUR')}
            >
              <CatalogueCostNumber cost={getDisplayCost('FUR', 10)} className="relative shrink-0 w-full" />
            </CatalogueShipSlot>
          </div>

          {/* Ark of Entropy */}
          <div
            className="absolute content-stretch flex flex-col items-center"
            style={{ left: '512px', top: '123px', width: '86.4px' }}
            onMouseEnter={(e) => hover.onEnter('ENT', e.currentTarget)}
              onMouseLeave={() => hover.onLeave('ENT')}
          >
            <CatalogueShipSlot
              shipId="ENT"
              graphic={
                <div className="relative shrink-0" style={{ height: '107.1px', width: '86.4px' }}>
                  <ArkOfEntropyShip />
                </div>
              }
              {...getSlotProps('ENT')}
            >
              <CatalogueCostNumber cost={getDisplayCost('ENT', 12)} className="relative shrink-0 w-full" />
            </CatalogueShipSlot>
          </div>

          {/* Ark of Knowledge */}
          <div
            className="absolute content-stretch flex flex-col items-center"
            style={{ left: '615px', top: '53px', width: '85.05px' }}
            onMouseEnter={(e) => hover.onEnter('KNO', e.currentTarget)}
              onMouseLeave={() => hover.onLeave('KNO')}
          >
            <CatalogueShipSlot
              shipId="KNO"
              graphic={
                <div className="relative shrink-0" style={{ height: '175.2', width: '85.05px' }}>
                  <div className="w-full h-full catalogue-ship-fit">
                  <ArkOfKnowledgeShip />
                    </div>
                </div>
              }
              {...getSlotProps('KNO')}
            >
              <CatalogueCostNumber cost={getDisplayCost('KNO', 12)} className="relative shrink-0 w-full" />
            </CatalogueShipSlot>
          </div>


          {/* Ark of Redemption */}
          <div
            className="absolute content-stretch flex flex-col items-center"
            style={redemptionPosition}
            onMouseEnter={(e) => hover.onEnter('RED', e.currentTarget)}
              onMouseLeave={() => hover.onLeave('RED')}
          >
            <CatalogueShipSlot
              shipId="RED"
              graphic={
                <div className="relative shrink-0" style={{ height: '151.2px', width: '165.564px' }}>
                  <div className="w-full h-full catalogue-ship-fit">
                  <ArkOfRedemptionShip />
                  </div>
                </div>
              }
              {...getSlotProps('RED')}
            >
              <CatalogueCostNumber cost={getDisplayCost('RED', 15)} className="relative shrink-0 w-full" />
            </CatalogueShipSlot>
          </div>
          
          {/* Ark of Power */}
          <div
            className="absolute content-stretch flex flex-col items-center"
            style={powerPosition}
            onMouseEnter={(e) => hover.onEnter('POW', e.currentTarget)}
              onMouseLeave={() => hover.onLeave('POW')}
          >
            <CatalogueShipSlot
              shipId="POW"
              graphic={
                <div className="relative shrink-0" style={{ height: '132.76px', width: '220.57px' }}>
                  <div className="w-full h-full catalogue-ship-fit">
                  <ArkOfPowerShip />
                  </div>
                </div>
              }
              {...getSlotProps('POW')}
            >
              <CatalogueCostNumber cost={getDisplayCost('POW', 20)} className="relative shrink-0 w-full" />
            </CatalogueShipSlot>
          </div>

          {/* Ark of Destruction */}
          <div
            className="absolute content-stretch flex flex-col items-center"
            style={destructionPosition}
            onMouseEnter={(e) => hover.onEnter('DES', e.currentTarget)}
              onMouseLeave={() => hover.onLeave('DES')}
          >
            <CatalogueShipSlot
              shipId="DES"
              graphic={
                <div className="relative shrink-0" style={{ height: '166.62px', width: '196.02px' }}>
                  <div className="w-full h-full catalogue-ship-fit">
                  <ArkOfDestructionShip />
                  </div>
                </div>
              }
              {...getSlotProps('DES')}
            >
              <CatalogueCostNumber cost={getDisplayCost('DES', 31)} className="relative shrink-0" />
            </CatalogueShipSlot>
          </div>

          {/* Ark of Domination */}
          <div
            className="absolute content-stretch flex flex-col items-center"
            style={dominationPosition}
            onMouseEnter={(e) => hover.onEnter('DOM', e.currentTarget)}
              onMouseLeave={() => hover.onLeave('DOM')}
          >
            <CatalogueShipSlot
              shipId="DOM"
              graphic={
                <div className="relative shrink-0" style={{ height: '214.95px', width: '312.57px' }}>
                  <div className="w-full h-full catalogue-ship-fit">
                  <ArkOfDominationShip />
                  </div>
                </div>
              }
              {...getSlotProps('DOM')}
            >
              <CatalogueCostNumber cost={getDisplayCost('DOM', 40)} className="relative shrink-0" />
            </CatalogueShipSlot>
          </div>

        </div>
      );

  return (
    <>
      {frame === 'desktop' ? <ActionPanelScrollArea>{content}</ActionPanelScrollArea> : content}
      
      {/* Single hover card rendered via portal */}
      {!hoverDisabled && hover.state.activeShipId && hover.state.anchorRect && hoveredShipEligibility && (
        <ShipHoverCard
          shipId={hover.state.activeShipId}
          anchorRect={hover.state.anchorRect}
          eligibility={hoveredShipEligibility}
        />
      )}
    </>
  );
}
