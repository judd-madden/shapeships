/**
 * Ancient Ship Catalogue Panel
 *
 * LEFT SIDE: Ancient Basic Ships (clickable, full wiring)
 * RIGHT SIDE: Ancient Solar Powers (static UI placeholder, no logic)
 *
 * Pattern cloned from CentaurShipCataloguePanel.tsx
 * NO backend calls, NO rules validation, NO engine imports
 */

import type { ActionPanelViewModel, GameSessionActions } from "../../../../../client/useGameSession";
import { ActionPanelScrollArea } from "../../../primitives/ActionPanelScrollArea";
import { CatalogueShipSlot } from "../shared/CatalogueShipSlot";
import { CatalogueCostNumber } from "../shared/CatalogueCostNumber";
import { ShipHoverCard } from "../shared/ShipHoverCard";
import { useShipCatalogueHover } from "../shared/useShipCatalogueHover";
import { getShipEligibilityForHover } from "../shared/ShipBuildEligibility";
import type { ShipDefId } from "../../../../../types/ShipTypes.engine";
import {
  MercuryCore,
  PlutoCore,
  QuantumMystic,
  Spiral,
  UranusCore,
  SolarReserve4,
  Cube,
} from "../../../../../../graphics/ancient/assets";

type CatalogueFrame = 'desktop' | 'bare';
type CatalogueLayout = 'standard' | 'long';

const ANCIENT_DESKTOP_CANVAS = { width: 1210, height: 420 };
const ANCIENT_LONG_CANVAS = { width: 1446, height: 258 };

interface AncientShipCataloguePanelProps {
  actions: GameSessionActions;
  buildCatalogue: ActionPanelViewModel['buildCatalogue'];
  frame?: CatalogueFrame;
  catalogueLayout?: CatalogueLayout;
  hoverDisabled?: boolean;
  interactionDisabled?: boolean;
  onShipInspect?: (shipId: ShipDefId) => void;
}

export function AncientShipCataloguePanel({
  actions,
  buildCatalogue,
  frame = 'desktop',
  catalogueLayout = 'standard',
  hoverDisabled,
  interactionDisabled = false,
  onShipInspect,
}: AncientShipCataloguePanelProps) {
  const hover = useShipCatalogueHover(hoverDisabled);
  const isBuildableContext = buildCatalogue.context === 'buildable';
  const isUnavailableContext = buildCatalogue.context === 'unavailable';
  const isLongCatalogueLayout = catalogueLayout === 'long';
  const canvas = isLongCatalogueLayout ? ANCIENT_LONG_CANVAS : ANCIENT_DESKTOP_CANVAS;
  const blackHolePosition = isLongCatalogueLayout
    ? { left: "803px", top: "17px", width: "356px" }
    : { left: "0px", top: "200px", width: "356px" };

  function getSlotProps(shipId: ShipDefId) {
    const canAddShip = buildCatalogue.canAddShipById[shipId] === true;
    const isDimmed = isUnavailableContext || (isBuildableContext && !canAddShip);

    if (onShipInspect) {
      return {
        isDimmed,
        isClickable: true,
        onClick: () => onShipInspect(shipId),
      };
    }

    if (interactionDisabled) {
      return {
        isDimmed,
        isClickable: false,
      };
    }

    return {
      isDimmed,
      isClickable: isBuildableContext && canAddShip,
      onClick: () => actions.onBuildShip(shipId),
    };
  }

  function getDisplayCost(shipId: ShipDefId, fallbackCost: number): number {
    return isBuildableContext
      ? (buildCatalogue.displayCostByShipId[shipId] ?? fallbackCost)
      : fallbackCost;
  }

  const hoveredShipEligibility = hover.state.activeShipId
    ? getShipEligibilityForHover({
        shipId: hover.state.activeShipId,
        buildCatalogue,
      })
    : null;

  const content = (
    /* Container with exact width matching design */
    <div
      className="relative"
      style={{
        width: `${canvas.width}px`,
        minHeight: `${canvas.height}px`,
        ...(frame === 'bare' ? { height: `${canvas.height}px` } : {}),
      }}
    >

          {/* Section Titles */}
          <p
            className="absolute font-['Roboto'] font-bold leading-[normal] text-[18px] text-white"
            style={{
              left: "0",
              top: "0",
              fontVariationSettings: "'wdth' 100",
            }}
          >
            Ancient Basic Ships
          </p>

          <p
            className="absolute font-['Roboto'] font-bold leading-[normal] text-[18px] text-white"
            style={{
              left: "427px",
              top: "0",
              fontVariationSettings: "'wdth' 100",
            }}
          >
            [In Development!]
          </p>

          {/* Vertical Divider */}
          <div
            className="absolute bg-[var(--shapeships-grey-70)]"
            style={{
              left: "407px",
              top: "0",
              width: "1px",
              height: `${canvas.height}px`,
            }}
          />

          {/* ================ LEFT HALF: BASIC SHIPS (CLICKABLE) ================ */}

          {/* Basic Ships Row 1 */}
          <div
            className="absolute content-stretch flex items-end justify-between"
            style={{ left: "0px", top: "25px", width: "386px" }}
          >
            {/* Mercury Core */}
            <div
              className="content-stretch flex flex-col gap-[8px] items-center shrink-0"
              style={{ width: "40px" }}
              onMouseEnter={(e) =>
                hover.onEnter("MER", e.currentTarget)
              }
              onMouseLeave={() => hover.onLeave("MER")}
            >
              <CatalogueShipSlot
                shipId="MER"
                graphic={
                  <div
                    className="relative shrink-0"
                    style={{ height: "85px", width: "40px" }}
                  >
                    <MercuryCore />
                  </div>
                }
                {...getSlotProps("MER")}
              >
                <CatalogueCostNumber
                  cost={getDisplayCost("MER", 4)}
                  className="relative shrink-0 w-full"
                />
              </CatalogueShipSlot>
            </div>

            {/* Pluto Core */}
            <div
              className="content-stretch flex flex-col gap-[8px] items-center shrink-0"
              style={{ width: "40px" }}
              onMouseEnter={(e) =>
                hover.onEnter("PLU", e.currentTarget)
              }
              onMouseLeave={() => hover.onLeave("PLU")}
            >
              <CatalogueShipSlot
                shipId="PLU"
                graphic={
                  <div
                    className="relative shrink-0"
                    style={{ height: "70px", width: "40px" }}
                  >
                    <PlutoCore />
                  </div>
                }
                {...getSlotProps("PLU")}
              >
                <CatalogueCostNumber
                  cost={getDisplayCost("PLU", 4)}
                  className="relative shrink-0 w-full"
                />
              </CatalogueShipSlot>
            </div>

            {/* Quantum Mystic */}
            <div
              className="content-stretch flex flex-col gap-[8px] items-center shrink-0"
              style={{ width: "90px" }}
              onMouseEnter={(e) =>
                hover.onEnter("QUA", e.currentTarget)
              }
              onMouseLeave={() => hover.onLeave("QUA")}
            >
              <CatalogueShipSlot
                shipId="QUA"
                graphic={
                  <div
                    className="relative shrink-0"
                    style={{ height: "57px", width: "90px" }}
                  >
                    <QuantumMystic />
                  </div>
                }
                {...getSlotProps("QUA")}
              >
                <CatalogueCostNumber
                  cost={getDisplayCost("QUA", 5)}
                  className="relative shrink-0 w-full"
                />
              </CatalogueShipSlot>
            </div>

            {/* Spiral */}
            <div
              className="content-stretch flex flex-col gap-[8px] items-center shrink-0"
              style={{ width: "60px" }}
              onMouseEnter={(e) =>
                hover.onEnter("SPI", e.currentTarget)
              }
              onMouseLeave={() => hover.onLeave("SPI")}
            >
              <CatalogueShipSlot
                shipId="SPI"
                graphic={
                  <div
                    className="relative shrink-0"
                    style={{ height: "60px", width: "60px" }}
                  >
                    <Spiral />
                  </div>
                }
                {...getSlotProps("SPI")}
              >
                <CatalogueCostNumber
                  cost={getDisplayCost("SPI", 6)}
                  className="relative shrink-0 w-full"
                />
              </CatalogueShipSlot>
            </div>
          </div>

          {/* Basic Ships Row 2 */}
          <div
            className="absolute content-stretch flex items-end justify-between px-[16px]"
            style={{
              left: "-5px",
              top: "151px",
              width: "396px",
            }}
          >
            {/* Uranus Core */}
            <div
              className="content-stretch flex flex-col gap-[8px] items-center shrink-0"
              style={{ width: "70px" }}
              onMouseEnter={(e) =>
                hover.onEnter("URA", e.currentTarget)
              }
              onMouseLeave={() => hover.onLeave("URA")}
            >
              <CatalogueShipSlot
                shipId="URA"
                graphic={
                  <div
                    className="relative shrink-0"
                    style={{ height: "70px", width: "70px" }}
                  >
                    <UranusCore />
                  </div>
                }
                {...getSlotProps("URA")}
              >
                <CatalogueCostNumber
                  cost={getDisplayCost("URA", 7)}
                  className="relative shrink-0 w-full"
                />
              </CatalogueShipSlot>
            </div>

            {/* Solar Reserve (use SolarReserve4 as default) */}
            <div
              className="content-stretch flex flex-col gap-[8px] items-center shrink-0"
              style={{ width: "80px" }}
              onMouseEnter={(e) =>
                hover.onEnter("SOL", e.currentTarget)
              }
              onMouseLeave={() => hover.onLeave("SOL")}
            >
              <CatalogueShipSlot
                shipId="SOL"
                graphic={
                  <div
                    className="relative shrink-0"
                    style={{ height: "80px", width: "80px" }}
                  >
                    <SolarReserve4 />
                  </div>
                }
                {...getSlotProps("SOL")}
              >
                <CatalogueCostNumber
                  cost={getDisplayCost("SOL", 8)}
                  className="relative shrink-0 w-full"
                />
              </CatalogueShipSlot>
            </div>

            {/* Cube */}
            <div
              className="content-stretch flex flex-col gap-[8px] items-center shrink-0"
              style={{ width: "70px" }}
              onMouseEnter={(e) =>
                hover.onEnter("CUB", e.currentTarget)
              }
              onMouseLeave={() => hover.onLeave("CUB")}
            >
              <CatalogueShipSlot
                shipId="CUB"
                graphic={
                  <div
                    className="relative shrink-0"
                    style={{ height: "70px", width: "70px" }}
                  >
                    <Cube />
                  </div>
                }
                {...getSlotProps("CUB")}
              >
                <CatalogueCostNumber
                  cost={getDisplayCost("CUB", 9)}
                  className="relative shrink-0 w-full"
                />
              </CatalogueShipSlot>
            </div>
          </div>

          {/* ================ RIGHT HALF: SOLAR POWERS (STATIC UI ONLY) ================ */}

          {/* Available Energy Header */}
          <div
            className="absolute content-stretch flex gap-[32px] items-center"
            style={{ right: "2px", top: "4px" }}
          >
            <p className="font-['Roboto'] font-normal leading-[20px] text-[15px] text-white">
              Available Energy:
            </p>
            <div className="content-stretch flex gap-[29px] items-center">
              {/* Red Energy */}
              <div className="content-stretch flex gap-[8px] items-center">
                <div className="relative shrink-0 size-[20px]">
                  <svg
                    className="block size-full"
                    fill="none"
                    preserveAspectRatio="none"
                    viewBox="0 0 20 20.4028"
                  >
                    <circle
                      cx="10"
                      cy="10"
                      fill="var(--shapeships-pastel-red)"
                      r="10"
                    />
                  </svg>
                </div>
                <p
                  className="font-['Roboto'] font-bold leading-[normal] text-[var(--shapeships-pastel-red)] text-[22px]"
                  style={{
                    fontVariationSettings: "'wdth' 100",
                  }}
                >
                  0 red
                </p>
              </div>

              {/* Green Energy */}
              <div className="content-stretch flex gap-[8px] items-center">
                <div className="relative shrink-0 size-[20px]">
                  <svg
                    className="block size-full"
                    fill="none"
                    preserveAspectRatio="none"
                    viewBox="0 0 20 20.4028"
                  >
                    <circle
                      cx="10"
                      cy="10"
                      fill="var(--shapeships-pastel-green)"
                      r="10"
                    />
                  </svg>
                </div>
                <p
                  className="font-['Roboto'] font-bold leading-[normal] text-[var(--shapeships-pastel-green)] text-[22px]"
                  style={{
                    fontVariationSettings: "'wdth' 100",
                  }}
                >
                  0 green
                </p>
              </div>

              {/* Blue Energy */}
              <div className="content-stretch flex gap-[8px] items-center">
                <div className="relative shrink-0 size-[20px]">
                  <svg
                    className="block size-full"
                    fill="none"
                    preserveAspectRatio="none"
                    viewBox="0 0 20 20.4028"
                  >
                    <circle
                      cx="10"
                      cy="10"
                      fill="var(--shapeships-pastel-blue)"
                      r="10"
                    />
                  </svg>
                </div>
                <p
                  className="font-['Roboto'] font-bold leading-[normal] text-[var(--shapeships-pastel-blue)] text-[22px]"
                  style={{
                    fontVariationSettings: "'wdth' 100",
                  }}
                >
                  0 blue
                </p>
              </div>
            </div>
          </div>

          {/* Solar Powers Wrapper - All buttons in one absolute positioned container */}
          <div
            className="absolute"
            style={{ left: "427px", top: "50px", right: "0" }}
          >
            {/* Solar Powers Grid - Row 1 */}
            <div
              className="absolute content-stretch flex gap-[30px] items-start"
              style={{ left: "0px", top: "0px" }}
            >
              {/* Asteroid (Red) */}
              <div className="content-stretch flex flex-col gap-[10px] items-center w-[169px]">
                <div className="h-[50px] relative rounded-[10px] w-full">
                  <div className="absolute border-2 border-[var(--shapeships-pastel-red)] border-solid inset-0 pointer-events-none rounded-[10px]" />
                  <div className="flex items-center justify-center size-full px-[20px] py-[19px]">
                    <div className="content-stretch flex gap-[10px] items-center justify-center">
                      <p
                        className="font-['Roboto'] font-bold leading-[normal] text-[var(--shapeships-pastel-red)] text-[16px] text-center"
                        style={{
                          fontVariationSettings: "'wdth' 100",
                        }}
                      >
                        Asteroid
                      </p>
                      <div className="relative shrink-0 size-[14.4px]">
                        <svg
                          className="block size-full"
                          fill="none"
                          preserveAspectRatio="none"
                          viewBox="0 0 16.248 16.248"
                        >
                          <circle
                            cx="8.124"
                            cy="8.124"
                            fill="black"
                            r="7.2"
                            stroke="var(--shapeships-pastel-red)"
                            strokeWidth="1.848"
                          />
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
                <p className="font-['Roboto'] font-normal leading-[20px] text-[15px] text-center text-white w-full">
                  Deal 1 damage
                </p>
              </div>

              {/* Life (Green) */}
              <div className="content-stretch flex flex-col gap-[11px] items-center w-[169px]">
                <div className="h-[50px] relative rounded-[10px] w-full">
                  <div className="absolute border-2 border-[var(--shapeships-pastel-green)] border-solid inset-0 pointer-events-none rounded-[10px]" />
                  <div className="flex items-center justify-center size-full px-[20px] py-[19px]">
                    <div className="content-stretch flex gap-[10px] items-center justify-center">
                      <p
                        className="font-['Roboto'] font-bold leading-[normal] text-[var(--shapeships-pastel-green)] text-[16px] text-center"
                        style={{
                          fontVariationSettings: "'wdth' 100",
                        }}
                      >
                        Life
                      </p>
                      <div className="relative shrink-0 size-[14.4px]">
                        <svg
                          className="block size-full"
                          fill="none"
                          preserveAspectRatio="none"
                          viewBox="0 0 16.248 16.248"
                        >
                          <circle
                            cx="8.124"
                            cy="8.124"
                            fill="black"
                            r="7.2"
                            stroke="var(--shapeships-pastel-green)"
                            strokeWidth="1.848"
                          />
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
                <p className="font-['Roboto'] font-normal leading-[20px] text-[15px] text-center text-white w-full">
                  Heal 1
                </p>
              </div>

              {/* Convert (Blue) */}
              <div className="content-stretch flex flex-col gap-[11px] items-center w-[169px]">
                <div className="h-[50px] relative rounded-[10px] w-full">
                  <div className="absolute border-2 border-[var(--shapeships-pastel-blue)] border-solid inset-0 pointer-events-none rounded-[10px]" />
                  <div className="flex items-center justify-center size-full px-[20px] py-[19px]">
                    <div className="content-stretch flex gap-[10px] items-center justify-center">
                      <p
                        className="font-['Roboto'] font-bold leading-[normal] text-[var(--shapeships-pastel-blue)] text-[16px] text-center"
                        style={{
                          fontVariationSettings: "'wdth' 100",
                        }}
                      >
                        Convert
                      </p>
                      <div className="relative shrink-0 size-[14.4px]">
                        <svg
                          className="block size-full"
                          fill="none"
                          preserveAspectRatio="none"
                          viewBox="0 0 16.248 16.248"
                        >
                          <circle
                            cx="8.124"
                            cy="8.124"
                            fill="black"
                            r="7.2"
                            stroke="var(--shapeships-pastel-blue)"
                            strokeWidth="1.848"
                          />
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
                <p className="font-['Roboto'] font-normal leading-[20px] text-[15px] text-center text-white w-full">
                  +1 Line
                </p>
              </div>

              {/* Siphon (Multi - Red+Green) */}
              <div className="content-stretch flex flex-col gap-[10px] items-center w-[169px]">
                <div className="h-[50px] relative rounded-[10px] w-full">
                  <div className="absolute border-2 border-[var(--shapeships-pastel-red)] border-solid inset-0 pointer-events-none rounded-[10px]" />
                  <div className="flex items-center justify-center size-full px-[20px] py-[19px]">
                    <div className="content-stretch flex gap-[10px] items-center justify-center">
                      {/* Red circles */}
                      <div className="h-[14.4px] w-[34.8px]">
                        <svg
                          className="block size-full"
                          fill="none"
                          preserveAspectRatio="none"
                          viewBox="0 0 36.648 16.248"
                        >
                          <circle
                            cx="8.124"
                            cy="8.124"
                            fill="black"
                            r="7.2"
                            stroke="var(--shapeships-pastel-red)"
                            strokeWidth="1.848"
                          />
                          <circle
                            cx="28.524"
                            cy="8.124"
                            fill="black"
                            r="7.2"
                            stroke="var(--shapeships-pastel-red)"
                            strokeWidth="1.848"
                          />
                        </svg>
                      </div>
                      <p
                        className="font-['Roboto'] font-bold leading-[normal] text-[16px] text-center text-white"
                        style={{
                          fontVariationSettings: "'wdth' 100",
                        }}
                      >
                        Siphon
                      </p>
                      {/* Green circles */}
                      <div className="h-[14.4px] w-[34.8px]">
                        <svg
                          className="block size-full"
                          fill="none"
                          preserveAspectRatio="none"
                          viewBox="0 0 36.648 16.248"
                        >
                          <circle
                            cx="8.124"
                            cy="8.124"
                            fill="black"
                            r="7.2"
                            stroke="var(--shapeships-pastel-green)"
                            strokeWidth="1.848"
                          />
                          <circle
                            cx="28.524"
                            cy="8.124"
                            fill="black"
                            r="7.2"
                            stroke="var(--shapeships-pastel-green)"
                            strokeWidth="1.848"
                          />
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
                <p className="font-['Roboto'] font-normal leading-[20px] text-[15px] text-center text-white w-full">
                  Deal X damage, heal X
                </p>
              </div>
            </div>

            {/* Solar Powers Grid - Row 2 */}
            <div
              className="absolute content-stretch flex gap-[30px] items-start"
              style={{ left: "0px", top: "100px" }}
            >
              {/* Supernova (Red) */}
              <div className="content-stretch flex flex-col gap-[10px] items-center w-[169px]">
                <div className="h-[50px] relative rounded-[10px] w-full">
                  <div className="absolute border-2 border-[var(--shapeships-pastel-red)] border-solid inset-0 pointer-events-none rounded-[10px]" />
                  <div className="flex items-center justify-center size-full px-[20px] py-[19px]">
                    <div className="content-stretch flex gap-[10px] items-center justify-center">
                      <p
                        className="font-['Roboto'] font-bold leading-[normal] text-[var(--shapeships-pastel-red)] text-[16px] text-center"
                        style={{
                          fontVariationSettings: "'wdth' 100",
                        }}
                      >
                        Supernova
                      </p>
                      <div className="h-[14.4px] w-[55.2px]">
                        <svg
                          className="block size-full"
                          fill="none"
                          preserveAspectRatio="none"
                          viewBox="0 0 57.048 16.248"
                        >
                          <circle
                            cx="8.124"
                            cy="8.124"
                            fill="black"
                            r="7.2"
                            stroke="var(--shapeships-pastel-red)"
                            strokeWidth="1.848"
                          />
                          <circle
                            cx="28.524"
                            cy="8.124"
                            fill="black"
                            r="7.2"
                            stroke="var(--shapeships-pastel-red)"
                            strokeWidth="1.848"
                          />
                          <circle
                            cx="48.924"
                            cy="8.124"
                            fill="black"
                            r="7.2"
                            stroke="var(--shapeships-pastel-red)"
                            strokeWidth="1.848"
                          />
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
                <p className="font-['Roboto'] font-normal leading-[20px] text-[15px] text-center text-white w-full">
                  Deal X damage
                </p>
              </div>

              {/* Star Birth (Green) */}
              <div className="content-stretch flex flex-col gap-[10px] items-center w-[169px]">
                <div className="h-[50px] relative rounded-[10px] w-full">
                  <div className="absolute border-2 border-[var(--shapeships-pastel-green)] border-solid inset-0 pointer-events-none rounded-[10px]" />
                  <div className="flex items-center justify-center size-full px-[20px] py-[19px]">
                    <div className="content-stretch flex gap-[10px] items-center justify-center">
                      <p
                        className="font-['Roboto'] font-bold leading-[normal] text-[var(--shapeships-pastel-green)] text-[16px] text-center"
                        style={{
                          fontVariationSettings: "'wdth' 100",
                        }}
                      >
                        Star Birth
                      </p>
                      <div className="h-[14.4px] w-[55.2px]">
                        <svg
                          className="block size-full"
                          fill="none"
                          preserveAspectRatio="none"
                          viewBox="0 0 57.048 16.248"
                        >
                          <circle
                            cx="8.124"
                            cy="8.124"
                            fill="black"
                            r="7.2"
                            stroke="var(--shapeships-pastel-green)"
                            strokeWidth="1.848"
                          />
                          <circle
                            cx="28.524"
                            cy="8.124"
                            fill="black"
                            r="7.2"
                            stroke="var(--shapeships-pastel-green)"
                            strokeWidth="1.848"
                          />
                          <circle
                            cx="48.924"
                            cy="8.124"
                            fill="black"
                            r="7.2"
                            stroke="var(--shapeships-pastel-green)"
                            strokeWidth="1.848"
                          />
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
                <p className="font-['Roboto'] font-normal leading-[20px] text-[15px] text-center text-white w-full">
                  Heal X
                </p>
              </div>

              {/* Simulacrum X (Blue) */}
              <div className="content-stretch flex flex-col gap-[10px] items-center w-[169px]">
                <div className="h-[50px] relative rounded-[10px] w-full">
                  <div className="absolute border-2 border-[var(--shapeships-pastel-blue)] border-solid inset-0 pointer-events-none rounded-[10px]" />
                  <div className="flex items-center justify-center size-full px-[20px] py-[19px]">
                    <div className="content-stretch flex gap-[10px] items-center justify-center">
                      <p
                        className="font-['Roboto'] font-bold leading-[normal] text-[var(--shapeships-pastel-blue)] text-[16px] text-center"
                        style={{
                          fontVariationSettings: "'wdth' 100",
                        }}
                      >
                        Simulacrum X
                      </p>
                      <div className="relative shrink-0 size-[14.4px]">
                        <svg
                          className="block size-full"
                          fill="none"
                          preserveAspectRatio="none"
                          viewBox="0 0 16.248 16.248"
                        >
                          <circle
                            cx="8.124"
                            cy="8.124"
                            fill="black"
                            r="7.2"
                            stroke="var(--shapeships-pastel-blue)"
                            strokeWidth="1.848"
                          />
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
                <p className="font-['Roboto'] font-normal leading-[20px] text-[15px] text-center text-white w-full">
                  Copy basic enemy ship
                </p>
              </div>

              {/* Vortex (Multi - Red+Green+Blue) */}
              <div className="content-stretch flex flex-col gap-[10px] items-center w-[169px]">
                <div className="h-[50px] relative rounded-[10px] w-full">
                  <div className="absolute border-2 border-[var(--shapeships-pastel-red)] border-solid inset-0 pointer-events-none rounded-[10px]" />
                  <div className="flex items-center justify-center size-full px-[20px] py-[19px]">
                    <div className="content-stretch flex gap-[10px] items-center justify-center">
                      {/* Red circles */}
                      <div className="h-[14.4px] w-[34.8px]">
                        <svg
                          className="block size-full"
                          fill="none"
                          preserveAspectRatio="none"
                          viewBox="0 0 36.648 16.248"
                        >
                          <circle
                            cx="8.124"
                            cy="8.124"
                            fill="black"
                            r="7.2"
                            stroke="var(--shapeships-pastel-red)"
                            strokeWidth="1.848"
                          />
                          <circle
                            cx="28.524"
                            cy="8.124"
                            fill="black"
                            r="7.2"
                            stroke="var(--shapeships-pastel-red)"
                            strokeWidth="1.848"
                          />
                        </svg>
                      </div>
                      {/* Green circles */}
                      <div className="h-[14.4px] w-[34.8px]">
                        <svg
                          className="block size-full"
                          fill="none"
                          preserveAspectRatio="none"
                          viewBox="0 0 36.648 16.248"
                        >
                          <circle
                            cx="8.124"
                            cy="8.124"
                            fill="black"
                            r="7.2"
                            stroke="var(--shapeships-pastel-green)"
                            strokeWidth="1.848"
                          />
                          <circle
                            cx="28.524"
                            cy="8.124"
                            fill="black"
                            r="7.2"
                            stroke="var(--shapeships-pastel-green)"
                            strokeWidth="1.848"
                          />
                        </svg>
                      </div>
                      <p
                        className="font-['Roboto'] font-bold leading-[normal] text-[16px] text-center text-white"
                        style={{
                          fontVariationSettings: "'wdth' 100",
                        }}
                      >
                        Vortex
                      </p>
                      {/* Blue circle */}
                      <div className="relative shrink-0 size-[14.4px]">
                        <svg
                          className="block size-full"
                          fill="none"
                          preserveAspectRatio="none"
                          viewBox="0 0 16.248 16.248"
                        >
                          <circle
                            cx="8.124"
                            cy="8.124"
                            fill="black"
                            r="7.2"
                            stroke="var(--shapeships-pastel-blue)"
                            strokeWidth="1.848"
                          />
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
                <p className="font-['Roboto'] font-normal leading-[20px] text-[15px] text-center text-white w-full">
                  Deal X damage
                </p>
              </div>
            </div>

            {/* Black Hole - Large Card */}
            <div
              className="absolute content-stretch flex flex-col gap-[10px] items-center"
              style={blackHolePosition}
            >
              <div className="h-[101.8px] relative rounded-[10px] w-full">
                <div className="absolute border-2 border-[var(--shapeships-pastel-red)] border-solid inset-0 pointer-events-none rounded-[10px]" />
                <div className="flex items-center justify-center size-full p-[20px]">
                  <div className="content-stretch flex flex-col gap-[10px] items-center justify-center w-full">
                    {/* Title and energy circles */}
                    <div className="content-stretch flex gap-[15px] items-start justify-between w-full">
                      <p
                        className="font-['Roboto'] font-bold leading-[normal] text-[var(--shapeships-pastel-red)] text-[20px]"
                        style={{
                          fontVariationSettings: "'wdth' 100",
                        }}
                      >
                        Black Hole
                      </p>
                      <div className="content-stretch flex gap-[10px] items-center">
                        {/* Red column */}
                        <div className="flex flex-col gap-[4px]">
                          <div className="relative shrink-0 size-[14.4px]">
                            <svg
                              className="block size-full"
                              fill="none"
                              preserveAspectRatio="none"
                              viewBox="0 0 16.248 16.248"
                            >
                              <circle
                                cx="8.124"
                                cy="8.124"
                                fill="black"
                                r="7.2"
                                stroke="var(--shapeships-pastel-red)"
                                strokeWidth="1.848"
                              />
                            </svg>
                          </div>
                          <div className="relative shrink-0 size-[14.4px]">
                            <svg
                              className="block size-full"
                              fill="none"
                              preserveAspectRatio="none"
                              viewBox="0 0 16.248 16.248"
                            >
                              <circle
                                cx="8.124"
                                cy="8.124"
                                fill="black"
                                r="7.2"
                                stroke="var(--shapeships-pastel-red)"
                                strokeWidth="1.848"
                              />
                            </svg>
                          </div>
                          <div className="relative shrink-0 size-[14.4px]">
                            <svg
                              className="block size-full"
                              fill="none"
                              preserveAspectRatio="none"
                              viewBox="0 0 16.248 16.248"
                            >
                              <circle
                                cx="8.124"
                                cy="8.124"
                                fill="black"
                                r="7.2"
                                stroke="var(--shapeships-pastel-red)"
                                strokeWidth="1.848"
                              />
                            </svg>
                          </div>
                        </div>
                        {/* Green column */}
                        <div className="flex flex-col gap-[4px]">
                          <div className="relative shrink-0 size-[14.4px]">
                            <svg
                              className="block size-full"
                              fill="none"
                              preserveAspectRatio="none"
                              viewBox="0 0 16.248 16.248"
                            >
                              <circle
                                cx="8.124"
                                cy="8.124"
                                fill="black"
                                r="7.2"
                                stroke="var(--shapeships-pastel-green)"
                                strokeWidth="1.848"
                              />
                            </svg>
                          </div>
                          <div className="relative shrink-0 size-[14.4px]">
                            <svg
                              className="block size-full"
                              fill="none"
                              preserveAspectRatio="none"
                              viewBox="0 0 16.248 16.248"
                            >
                              <circle
                                cx="8.124"
                                cy="8.124"
                                fill="black"
                                r="7.2"
                                stroke="var(--shapeships-pastel-green)"
                                strokeWidth="1.848"
                              />
                            </svg>
                          </div>
                          <div className="relative shrink-0 size-[14.4px]">
                            <svg
                              className="block size-full"
                              fill="none"
                              preserveAspectRatio="none"
                              viewBox="0 0 16.248 16.248"
                            >
                              <circle
                                cx="8.124"
                                cy="8.124"
                                fill="black"
                                r="7.2"
                                stroke="var(--shapeships-pastel-green)"
                                strokeWidth="1.848"
                              />
                            </svg>
                          </div>
                        </div>
                        {/* Blue column */}
                        <div className="flex flex-col gap-[4px]">
                          <div className="relative shrink-0 size-[14.4px]">
                            <svg
                              className="block size-full"
                              fill="none"
                              preserveAspectRatio="none"
                              viewBox="0 0 16.248 16.248"
                            >
                              <circle
                                cx="8.124"
                                cy="8.124"
                                fill="black"
                                r="7.2"
                                stroke="var(--shapeships-pastel-blue)"
                                strokeWidth="1.848"
                              />
                            </svg>
                          </div>
                          <div className="relative shrink-0 size-[14.4px]">
                            <svg
                              className="block size-full"
                              fill="none"
                              preserveAspectRatio="none"
                              viewBox="0 0 16.248 16.248"
                            >
                              <circle
                                cx="8.124"
                                cy="8.124"
                                fill="black"
                                r="7.2"
                                stroke="var(--shapeships-pastel-blue)"
                                strokeWidth="1.848"
                              />
                            </svg>
                          </div>
                          <div className="relative shrink-0 size-[14.4px]">
                            <svg
                              className="block size-full"
                              fill="none"
                              preserveAspectRatio="none"
                              viewBox="0 0 16.248 16.248"
                            >
                              <circle
                                cx="8.124"
                                cy="8.124"
                                fill="black"
                                r="7.2"
                                stroke="var(--shapeships-pastel-blue)"
                                strokeWidth="1.848"
                              />
                            </svg>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="content-stretch flex flex-col gap-[4px] items-center w-full">
                <p className="font-['Roboto'] font-normal leading-[20px] text-[15px] text-center text-white w-full">
                  Destroy TWO of the opponent&apos;s basic ships.
                </p>
                <p className="font-['Roboto'] font-normal leading-[20px] text-[15px] text-center text-white w-full">
                  Deal 4 damage.
                </p>
              </div>
            </div>
          </div>
        </div>
      );

  return (
    <>
      {frame === 'desktop' ? <ActionPanelScrollArea>{content}</ActionPanelScrollArea> : content}

      {/* Single hover card rendered via portal (only for Basic Ships on left) */}
      {!hoverDisabled &&
        hover.state.activeShipId &&
        hover.state.anchorRect &&
        hoveredShipEligibility && (
          <ShipHoverCard
            shipId={hover.state.activeShipId}
            anchorRect={hover.state.anchorRect}
            eligibility={hoveredShipEligibility}
          />
        )}
    </>
  );
}
