/**
 * End of Game Action Panel
 * Shown when vm.activePanelId === 'ap.end_of_game.result'
 * Displays game result banner and post-game action buttons
 */

import { useEffect, useState } from 'react';
import { GameMenuButton } from '../../../../components/ui/primitives/buttons/GameMenuButton';

interface EndOfGameActionPanelProps {
  bannerText: string;       // headline (already composed in VM)
  bannerBgCssVar: string;   // e.g. "var(--shapeships-pastel-blue)"
  metaLeftText: string;     // "Game Over. 18 turns."
  metaRightText: string;    // "Shapeships Game: {me} v {opponent}"
  rematchHelperText: string;
  onReturnToMainMenu: () => void;
  onRematch: () => void;
  onDownloadBattleLog: () => void;
}

export function EndOfGameActionPanel({
  bannerText,
  bannerBgCssVar,
  metaLeftText,
  metaRightText,
  rematchHelperText,
  onReturnToMainMenu,
  onRematch,
  onDownloadBattleLog,
}: EndOfGameActionPanelProps) {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(false);

    let raf1: number | null = null;
    let raf2: number | null = null;

    raf1 = window.requestAnimationFrame(() => {
      raf2 = window.requestAnimationFrame(() => {
        setIsVisible(true);
      });
    });

    return () => {
      if (raf1 !== null) {
        window.cancelAnimationFrame(raf1);
      }
      if (raf2 !== null) {
        window.cancelAnimationFrame(raf2);
      }
    };
  }, [bannerText, metaLeftText, metaRightText, rematchHelperText]);

  return (
    <div
      className={`flex-row items-center w-full h-[280px] transition-opacity duration-200 ease-out ${
        isVisible ? 'opacity-100' : 'opacity-0'
      }`}
    >
      {/* Top Banner */}
      <div 
        className="content-stretch flex flex-col font-bold gap-[12px] h-[150px] items-center justify-center px-[20px] py-[27px] rounded-tl-[10px] text-black w-full"
        style={{ background: bannerBgCssVar }}
      >
        {/* Headline */}
        <p 
          className="leading-[normal] relative shrink-0 text-[50px] text-center"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          {bannerText}
        </p>

        {/* Meta Row */}
        <div className="content-stretch flex gap-[24px] items-center relative shrink-0 text-[18px]">
          <p 
            className="leading-[normal] relative shrink-0 text-center"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            {metaLeftText}
          </p>
          <p 
            className="leading-[normal] relative shrink-0 text-center"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            {metaRightText}
          </p>
        </div>
      </div>

      {/* Buttons (centered below banner) */}
      <div className="content-stretch flex items-center w-full pt-[40px]">
        <div className="content-stretch flex gap-[20px] items-start justify-center w-full">
          <GameMenuButton onClick={onReturnToMainMenu}>
            Return to Main Menu
          </GameMenuButton>

          <div className="flex w-[210px] flex-col items-center">
            <GameMenuButton onClick={onRematch} pendingLabel="CREATING...">
              New Game
            </GameMenuButton>
            <p
              className="mt-[8px] text-center text-[16px] font-normal leading-[1.3] text-white"
              style={{ fontVariationSettings: "'wdth' 100" }}
            >
              {rematchHelperText}
            </p>
          </div>

          <GameMenuButton onClick={onDownloadBattleLog}>
            Download Battle Log
          </GameMenuButton>
        </div>
      </div>
    </div>
  );
}
