/**
 * ShipAnimationWrapper
 * --------------------
 * IMPORTANT:
 * This wrapper is intended ONLY for ships rendered in the live fleet areas
 * on the BoardStage (mode === 'board').
 *
 * It must NOT be used in:
 * - Action / build catalogues
 * - Rules or species views
 * - Hover cards or static previews
 *
 * Animations here are driven by fleet state + UX tokens, NOT rules logic.
 */

import {
  useEffect,
  useRef,
  useState,
  type AnimationEvent,
  type CSSProperties,
} from 'react';
import type { ShipDefId } from '../../types/ShipTypes.engine';

// ============================================================================
// TYPES
// ============================================================================

export type ShipAnimToken = {
  entryNonce: number;
  activationNonce: number;
  stackAddNonce: number; // NEW: triggers when count increases on existing stack
  stackCount: number;
};

export type FleetAnimVM = {
  my: Partial<Record<string, ShipAnimToken>>;       // renderKey -> token
  opponent: Partial<Record<string, ShipAnimToken>>; // renderKey -> token
};

// ============================================================================
// TARGETING
// ============================================================================

export type TargetingVisualState = 'available' | 'hovered' | 'selected';

export const TARGETING_GLOW_SIZE_PX = 200;
export const TARGETING_PREVIEW_SCALE = 0.5;
export const TARGETING_PREVIEW_OFFSET_PX = 10;

const TARGETING_WHITE_GLOW =
  'radial-gradient(circle, rgba(255,255,255,1) 0%, rgba(255,255,255,0) 60%)';
const TARGETING_RED_GLOW =
  'radial-gradient(circle, rgba(221,0,0,1) 0%, rgba(221,0,0,0) 60%)';

export function getTargetingVisualState(targetState?: {
  isTargetable: boolean;
  isHovered: boolean;
  isSelected: boolean;
} | null): TargetingVisualState | null {
  if (!targetState) {
    return null;
  }

  if (targetState.isSelected) {
    return 'selected';
  }

  if (targetState.isHovered && targetState.isTargetable) {
    return 'hovered';
  }

  if (targetState.isTargetable) {
    return 'available';
  }

  return null;
}

export function getTargetingGlowClassName(visualState: TargetingVisualState): string {
  return visualState === 'available'
    ? 'ss-targeting-glow ss-targeting-glow-pulse'
    : 'ss-targeting-glow';
}

export function getTargetingGlowStyle(
  visualState: TargetingVisualState,
  scale = 1
): CSSProperties {
  const sizePx = TARGETING_GLOW_SIZE_PX * scale;

  return {
    width: `${sizePx}px`,
    height: `${sizePx}px`,
    backgroundImage: visualState === 'selected' ? TARGETING_RED_GLOW : TARGETING_WHITE_GLOW,
    opacity: visualState === 'available' ? 0.55 : 1,
    pointerEvents: 'none',
  };
}

export function getTargetingPreviewStyle(visualState: Extract<TargetingVisualState, 'hovered' | 'selected'>): React.CSSProperties {
  return {
    top: '100%',
    opacity: visualState === 'selected' ? 1 : 0.5,
    pointerEvents: 'none',
    transform: `translate(-50%, ${TARGETING_PREVIEW_OFFSET_PX}px) scale(${TARGETING_PREVIEW_SCALE})`,
    transformOrigin: 'top center',
  };
}

// ============================================================================
// ANIMATION PRESETS (SPLIT: ENTRY + ACTIVATION)
// ============================================================================
// These classes are in globals.css

type EntryPresetId = 'default' | 'defender' | 'commander' | 'carrier' | 'starship' | 'xenite' | 'to-right';
type ActivationPresetId = 'default' | 'carrier' | 'xenite';

const ENTRY_PRESETS: Record<EntryPresetId, { entryClass: string }> = {
  default: { entryClass: 'ss-entry-default' },
  defender: { entryClass: 'ss-entry-defender' },
  commander: { entryClass: 'ss-entry-commander' },
  carrier: { entryClass: 'ss-entry-carrier' },
  starship: { entryClass: 'ss-entry-starship' },
  xenite: { entryClass: 'ss-entry-xenite' },
  'to-right': { entryClass: 'ss-entry-to-right' },
};

const ACTIVATION_PRESETS: Record<ActivationPresetId, { 
  activationClass: string; 
  scaleMode: 'stackLinear' | 'none';
}> = {
  default: { 
    activationClass: 'ss-activate-default', 
    scaleMode: 'stackLinear',
  },
  carrier: { 
    activationClass: 'ss-activate-carrier', 
    scaleMode: 'none', // rotate only, no scale intensity
  },
  xenite: {
    activationClass: 'ss-activate-xenite',
    scaleMode: 'none', // jiggle only, no scale intensity
  },
};

const SHIP_ANIM: Partial<Record<ShipDefId, { 
  entry: EntryPresetId; 
  activation: ActivationPresetId;
}>> = {
  // Existing ships (renamed fighter → default)
  DEF: { entry: 'defender', activation: 'default' },
  FIG: { entry: 'default', activation: 'default' },
  INT: { entry: 'default', activation: 'default' },

  // Human Basic ships
  COM: { entry: 'commander', activation: 'default' },
  ORB: { entry: 'defender', activation: 'default' }, // "same as Defender"
  CAR: { entry: 'carrier', activation: 'carrier' },  // override activation
  STA: { entry: 'starship', activation: 'default' },

  // Human Upgraded ships
  FRI: { entry: 'default', activation: 'default' },
  TAC: { entry: 'default', activation: 'default' },
  GUA: { entry: 'defender', activation: 'default' }, // like Defender
  SCI: { entry: 'default', activation: 'default' }, 
  BAT: { entry: 'default', activation: 'default' },
  EAR: { entry: 'default', activation: 'default' },
  DRE: { entry: 'default', activation: 'default' },
  LEV: { entry: 'default', activation: 'default' },

  // Xenite ships
  XEN: { entry: 'xenite', activation: 'xenite' },
  ANT: { entry: 'default', activation: 'default' },
  MAN: { entry: 'xenite', activation: 'xenite' },
  EVO: { entry: 'defender', activation: 'default' },
  HEL: { entry: 'xenite', activation: 'xenite' },
  BUG: { entry: 'xenite', activation: 'xenite' },
  ZEN: { entry: 'xenite', activation: 'xenite' },
  DSW: { entry: 'default', activation: 'default' },
  AAR: { entry: 'default', activation: 'default' },
  OXF: { entry: 'defender', activation: 'default' },
  ASF: { entry: 'defender', activation: 'default' },
  SAC: { entry: 'xenite', activation: 'xenite' },
  QUE: { entry: 'xenite', activation: 'xenite' },
  CHR: { entry: 'default', activation: 'default' },
  HVE: { entry: 'default', activation: 'default' },

  // Centaur ships
  FEA: { entry: 'to-right', activation: 'default' },
  ANG: { entry: 'to-right', activation: 'default' },
  EQU: { entry: 'to-right', activation: 'default' },
  WIS: { entry: 'defender', activation: 'default' },
  VIG: { entry: 'default', activation: 'default' },
  FAM: { entry: 'starship', activation: 'carrier' },
  LEG: { entry: 'to-right', activation: 'default' },
  TER: { entry: 'to-right', activation: 'default' },
  FUR: { entry: 'to-right', activation: 'default' },
  KNO: { entry: 'default', activation: 'default' },
  ENT: { entry: 'to-right', activation: 'default' },
  RED: { entry: 'default', activation: 'default' },
  POW: { entry: 'default', activation: 'default' },
  DES: { entry: 'default', activation: 'default' },
  DOM: { entry: 'default', activation: 'default' },
};

// ============================================================================
// ACTIVATION SCALE HELPER
// ============================================================================

/**
 * Compute activation scale based on stack count
 */
export function computeActivationScale(stackCount: number): number {
  const base = 0.944;
  const k = 0.206;
  const max = 2.4;

  const scale = base + k * Math.sqrt(Math.max(0, stackCount));
  return Math.min(scale, max);
}

// ============================================================================
// SHIP ANIMATION WRAPPER
// ============================================================================

interface ShipAnimationWrapperProps {
  shipDefId: ShipDefId;
  token?: ShipAnimToken;
  enableHoverActivation?: boolean;
  activationDelayMs?: number; // Paired activation stagger delay
  children: React.ReactNode;
}

export function ShipAnimationWrapper({
  shipDefId,
  token,
  enableHoverActivation = false,
  activationDelayMs = 0,
  children,
}: ShipAnimationWrapperProps) {
  const activationNonce = token?.activationNonce ?? 0;
  const previousActivationNonceRef = useRef(activationNonce);
  const [activeActivationNonce, setActiveActivationNonce] = useState<number | null>(null);

  useEffect(() => {
    const previousActivationNonce = previousActivationNonceRef.current;
    previousActivationNonceRef.current = activationNonce;

    if (activationNonce === 0) {
      setActiveActivationNonce(null);
      return;
    }

    if (activationNonce !== previousActivationNonce) {
      setActiveActivationNonce(activationNonce);
    }
  }, [activationNonce]);

  // Lookup animation config for this ship
  const cfg = SHIP_ANIM[shipDefId];
  
  // If no config OR no token, render children directly (no animation)
  if (!cfg || !token) {
    return <>{children}</>;
  }

  const entryPreset = ENTRY_PRESETS[cfg.entry];
  const activationPreset = ACTIVATION_PRESETS[cfg.activation];

  // Compute activation scale from stack count (only for stackLinear mode)
  const actScale = activationPreset.scaleMode === 'stackLinear' 
    ? computeActivationScale(token.stackCount) 
    : 1;

  // Data attribute for hover: map activation preset to CSS selector
  const dataAnimValue = cfg.activation; // 'default' | 'carrier' | 'xenite'
  const isExplicitActivationActive =
    activationNonce > 0 && activeActivationNonce === activationNonce;

  const handleActivationAnimationEnd = (
    event: AnimationEvent<HTMLDivElement>,
    completedActivationNonce: number
  ) => {
    if (event.currentTarget !== event.target) {
      return;
    }

    setActiveActivationNonce((current) =>
      current === completedActivationNonce ? null : current
    );
  };

  return (
    <div
      className="ss-shipAnimRoot"
      data-anim={dataAnimValue}
      data-anim-hover={enableHoverActivation ? '1' : '0'}
      style={{ '--ss-act-scale': actScale } as React.CSSProperties}
    >
      {/* Entry animation layer (keyed by entryNonce) */}
      <div
        key={`entry-${token.entryNonce}`}
        className={`ss-shipEntryLayer ${entryPreset.entryClass}`}
      >
        {/* Stack-add pulse layer (keyed by stackAddNonce) */}
        <div
          key={`stackadd-${token.stackAddNonce}`}
          className={token.stackAddNonce > 0 ? 'ss-stack-add' : ''}
        >
          {/* Activation animation layer (keyed by activationNonce) */}
          <div
            key={`activate-${activationNonce}`}
            className={`ss-shipActivateLayer ${isExplicitActivationActive ? activationPreset.activationClass : ''}`}
            style={{
              animationDelay: isExplicitActivationActive && activationDelayMs > 0 ? `${activationDelayMs}ms` : undefined,
            }}
            onAnimationEnd={(event) =>
              handleActivationAnimationEnd(event, activationNonce)
            }
          >
            {children}
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// TURN INCREMENT PULSE
// ============================================================================

export interface TurnIncrementPulseOptions {
  enabled: boolean;
  turn: number | null;
}

export interface TurnIncrementPulseState {
  isActive: boolean;
  runKey: number;
  onAnimationEnd: (event: AnimationEvent<HTMLDivElement>) => void;
}

export const BOARD_TURN_PULSE_LIFECYCLE_ANIMATION_NAME = 'ssBoardTurnPulseLifecycle';

function usePrefersReducedMotion(): boolean {
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);

  useEffect(() => {
    const mediaQuery = window.matchMedia?.('(prefers-reduced-motion: reduce)');
    if (!mediaQuery) {
      return;
    }

    const update = () => setPrefersReducedMotion(Boolean(mediaQuery.matches));

    update();
    mediaQuery.addEventListener?.('change', update);

    return () => {
      mediaQuery.removeEventListener?.('change', update);
    };
  }, []);

  return prefersReducedMotion;
}

export function useTurnIncrementPulse({
  enabled,
  turn,
}: TurnIncrementPulseOptions): TurnIncrementPulseState {
  const previousTurnRef = useRef<number | null>(null);
  const [isActive, setIsActive] = useState(false);
  const [runKey, setRunKey] = useState(0);

  useEffect(() => {
    if (!enabled || turn === null) {
      previousTurnRef.current = null;
      setIsActive(false);
      return;
    }

    const previousTurn = previousTurnRef.current;

    if (previousTurn === null) {
      previousTurnRef.current = turn;
      return;
    }

    previousTurnRef.current = turn;

    if (turn <= previousTurn) {
      return;
    }

    setIsActive(true);
    setRunKey((current) => current + 1);
  }, [enabled, turn]);

  function onAnimationEnd(event: AnimationEvent<HTMLDivElement>) {
    if (event.target !== event.currentTarget) {
      return;
    }

    if (event.animationName !== BOARD_TURN_PULSE_LIFECYCLE_ANIMATION_NAME) {
      return;
    }

    setIsActive(false);
  }

  return {
    isActive,
    runKey,
    onAnimationEnd,
  };
}

export interface PhaseEntryPulseOptions {
  enabled: boolean;
  phaseKey: string | null;
  targetPhaseKey: string;
}

export function usePhaseEntryPulse({
  enabled,
  phaseKey,
  targetPhaseKey,
}: PhaseEntryPulseOptions): TurnIncrementPulseState {
  const prefersReducedMotion = usePrefersReducedMotion();
  const previousPhaseRef = useRef<string | null>(null);
  const [isActive, setIsActive] = useState(false);
  const [runKey, setRunKey] = useState(0);

  useEffect(() => {
    if (!enabled || prefersReducedMotion) {
      setIsActive(false);
    }
  }, [enabled, prefersReducedMotion]);

  useEffect(() => {
    const previousPhase = previousPhaseRef.current;
    previousPhaseRef.current = phaseKey;

    if (!enabled || prefersReducedMotion || phaseKey === null) {
      return;
    }

    if (previousPhase === null) {
      return;
    }

    if (phaseKey !== targetPhaseKey || previousPhase === targetPhaseKey) {
      return;
    }

    setIsActive(true);
    setRunKey((current) => current + 1);
  }, [enabled, phaseKey, prefersReducedMotion, targetPhaseKey]);

  function onAnimationEnd(event: AnimationEvent<HTMLDivElement>) {
    if (event.target !== event.currentTarget) {
      return;
    }

    if (event.animationName !== BOARD_TURN_PULSE_LIFECYCLE_ANIMATION_NAME) {
      return;
    }

    setIsActive(false);
  }

  return {
    isActive,
    runKey,
    onAnimationEnd,
  };
}

// ============================================================================
// LEFT RAIL TURN TAKEOVER
// ============================================================================

export interface TurnTakeoverState {
  turn: number | null;
  runKey: number;
  timingStyle: CSSProperties;
  onOverlayAnimationEnd: (event: AnimationEvent<HTMLDivElement>) => void;
}

export const TURN_TAKEOVER_LIFECYCLE_ANIMATION_NAME = 'ssLeftRailTurnTakeoverLifecycle';
export const TURN_TAKEOVER_WIPE_IN_MS = 280;
export const TURN_TAKEOVER_TEXT_IN_DELAY_MS = 48;
export const TURN_TAKEOVER_TEXT_IN_MS = 320;
export const TURN_TAKEOVER_HOLD_MS = 1300;
export const TURN_TAKEOVER_TEXT_OUT_MS = 360;
export const TURN_TAKEOVER_WIPE_OUT_DELAY_MS = 30;
export const TURN_TAKEOVER_WIPE_OUT_MS = 180;
export const TURN_TAKEOVER_ENTER_SETTLE_MS = Math.max(
  TURN_TAKEOVER_WIPE_IN_MS,
  TURN_TAKEOVER_TEXT_IN_DELAY_MS + TURN_TAKEOVER_TEXT_IN_MS,
);
export const TURN_TAKEOVER_EXIT_SETTLE_MS = Math.max(
  TURN_TAKEOVER_TEXT_OUT_MS,
  TURN_TAKEOVER_WIPE_OUT_DELAY_MS + TURN_TAKEOVER_WIPE_OUT_MS,
);
export const TURN_TAKEOVER_TOTAL_MS =
  TURN_TAKEOVER_ENTER_SETTLE_MS + TURN_TAKEOVER_HOLD_MS + TURN_TAKEOVER_EXIT_SETTLE_MS;

export const TURN_TAKEOVER_TIMING_STYLE = {
  '--ss-turn-takeover-total': `${TURN_TAKEOVER_TOTAL_MS}ms`,
  '--ss-turn-takeover-wipe-in': `${TURN_TAKEOVER_WIPE_IN_MS}ms`,
  '--ss-turn-takeover-text-in-delay': `${TURN_TAKEOVER_TEXT_IN_DELAY_MS}ms`,
  '--ss-turn-takeover-text-in': `${TURN_TAKEOVER_TEXT_IN_MS}ms`,
  '--ss-turn-takeover-text-out': `${TURN_TAKEOVER_TEXT_OUT_MS}ms`,
  '--ss-turn-takeover-wipe-out-delay': `${TURN_TAKEOVER_WIPE_OUT_DELAY_MS}ms`,
  '--ss-turn-takeover-wipe-out': `${TURN_TAKEOVER_WIPE_OUT_MS}ms`,
} as CSSProperties;

export function useLeftRailTurnTakeover(args: {
  turn: number | null;
  animateKey: number;
}): TurnTakeoverState {
  const { turn, animateKey } = args;
  const previousAnimateKeyRef = useRef<number>(animateKey);
  const [displayedTurn, setDisplayedTurn] = useState<number | null>(null);
  const [runKey, setRunKey] = useState(0);

  useEffect(() => {
    if (animateKey <= previousAnimateKeyRef.current) {
      previousAnimateKeyRef.current = animateKey;
      return;
    }

    previousAnimateKeyRef.current = animateKey;

    if (turn === null) {
      return;
    }

    setDisplayedTurn(turn);
    setRunKey((current) => current + 1);
  }, [animateKey, turn]);

  function onOverlayAnimationEnd(event: AnimationEvent<HTMLDivElement>) {
    if (event.target !== event.currentTarget) {
      return;
    }

    if (event.animationName !== TURN_TAKEOVER_LIFECYCLE_ANIMATION_NAME) {
      return;
    }

    setDisplayedTurn(null);
  }

  return {
    turn: displayedTurn,
    runKey,
    timingStyle: TURN_TAKEOVER_TIMING_STYLE,
    onOverlayAnimationEnd,
  };
}
