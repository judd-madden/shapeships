/**
 * VIEW-MODEL CONSTRUCTION
 * 
 * Maps game state and derived values into the GameSessionViewModel.
 */

import type { ActionPanelId } from '../../display/actionPanel/ActionPanelRegistry';
import type { SpeciesId } from '../../../components/ui/primitives/buttons/SpeciesCardButton';
import type { ShipDefId } from '../../types/ShipTypes.engine';
import type { ShipChoiceGroupSpec, ShipChoicesPanelGroup } from '../../types/ShipChoiceTypes';
import type {
  ActionPanelTabVm,
  BattleLogHistoryResponse,
  BoardViewModel,
  BuildDrawingActionFamily,
  EvolverChoiceId,
  FirstStrikeActionFamily,
  FleetAreaHealthDeltaFlashVm,
  GameSessionViewModel,
  GameSessionChatEntry,
  HealthResolutionPresentationVm,
  HudStatusTone,
} from './types';
import {
  formatCountedShipChoiceHeading,
  getShipChoicePanelSpec,
} from '../../display/actionPanel/panels/ShipChoiceRegistry';
import { mapBattleLogTurns } from './battleLog';
import { deriveMobileDiceModifierSlots } from './mobileDiceModifierSlots';
import {
  getAllocatedTargetIdsForRenderableAction,
  getRenderableActionChoiceIds,
  getRenderableActionRequiredTargetCount,
  getRenderableServerChoiceActions,
  isRenderableTargetedAction,
  isRenderableTargetedActionComplete,
} from './availableActions';
import type { CentaurChargeSubTabId } from './types';

function getNamedGroupHeading(
  phaseKey: string,
  heading: string,
  gameData: any
): string {
  const knoRerollPassIndex = gameData?.turnData?.knoRerollPassIndex;
  if (
    phaseKey === 'build.dice_roll' &&
    heading === 'Ark of Knowledge' &&
    (knoRerollPassIndex === 1 || knoRerollPassIndex === 2 || knoRerollPassIndex === 3)
  ) {
    return `Ark of Knowledge ${knoRerollPassIndex}`;
  }

  return heading;
}

function getTargetedActionButtons(args: {
  buttons: ShipChoiceGroupSpec['buttons'];
  action: any;
  sourceInstanceId: string;
  selectedChoiceIdBySourceInstanceId: Record<string, string>;
  allocatedDestroyTargetIdsBySourceInstanceId: Record<string, string[]>;
  allocatedDestroyTargetIdBySourceInstanceId: Record<string, string>;
}) {
  const {
    buttons,
    action,
    sourceInstanceId,
    selectedChoiceIdBySourceInstanceId,
    allocatedDestroyTargetIdsBySourceInstanceId,
    allocatedDestroyTargetIdBySourceInstanceId,
  } = args;

  if (!isRenderableTargetedAction(action)) {
    return buttons;
  }

  const selectedChoiceId = selectedChoiceIdBySourceInstanceId[sourceInstanceId];
  const hasAllocatedTarget =
    getAllocatedTargetIdsForRenderableAction(
      action,
      allocatedDestroyTargetIdsBySourceInstanceId,
      allocatedDestroyTargetIdBySourceInstanceId
    ).length === getRenderableActionRequiredTargetCount(action);

  return buttons.map((button) => {
    if (button.choiceId == null || button.choiceId !== selectedChoiceId) {
      return button;
    }

    if (button.requiresTargeting !== true) {
      return button;
    }

    return {
      ...button,
      instructionText: hasAllocatedTarget
        ? action.kind === 'paired_destroy_target'
          ? 'Will destroy both selected ships.'
          : 'Will destroy selected ship.'
        : button.instructionText,
    };
  });
}

function getProjectedChoiceAmount(
  action: { choices?: Array<{ choiceId?: string; projectedAmount?: number }> },
  choiceId: string
): number | null {
  if (!Array.isArray(action?.choices)) return null;

  const match = action.choices.find((choice) => choice?.choiceId === choiceId);
  const projectedAmount = match?.projectedAmount;

  if (typeof projectedAmount !== 'number' || !Number.isInteger(projectedAmount)) {
    return null;
  }

  return projectedAmount;
}

function getProjectedActionButtons(args: {
  buttons: ShipChoiceGroupSpec['buttons'];
  action: any;
  shipDefId: ShipDefId;
}) {
  const { buttons, action, shipDefId } = args;

  if (shipDefId !== 'FAM') {
    return buttons;
  }

  return buttons.map((button) => {
    if (button.choiceId !== 'damage' && button.choiceId !== 'heal') {
      return button;
    }

    const projectedAmount = getProjectedChoiceAmount(action, button.choiceId);
    if (projectedAmount == null) {
      return button;
    }

    return {
      ...button,
      label: button.choiceId === 'damage'
        ? `Deal ${projectedAmount} Damage`
        : `Heal ${projectedAmount}`,
    };
  });
}

export function mapGameSessionVm(args: {
  isBootstrapping: boolean;
  viewer: GameSessionViewModel['viewer'];

  me: any;
  opponent: any;
  displayLeftPlayer: any;
  displayRightPlayer: any;
  displayLeftSpeciesLabel: string;
  displayRightSpeciesLabel: string;
  displayLeftSpeciesId: SpeciesId | null;
  displayRightSpeciesId: SpeciesId | null;

  p1HasJoined: boolean;
  p2HasJoined: boolean;

  p1IsReady: boolean;
  p2IsReady: boolean;
  
  p1ClockFormatted: string;
  p2ClockFormatted: string;

  p1StatusText?: string;
  p2StatusText?: string;

  p1StatusTone: HudStatusTone;
  p2StatusTone: HudStatusTone;

  turnNumber: number;
  phaseKey: string;
  phaseIcon: 'build' | 'battle';

  effectiveGameId: string | null;
  allPlayers: any[];

  activePanelId: ActionPanelId;
  tabs: ActionPanelTabVm[];
  buildCatalogue: GameSessionViewModel['actionPanel']['buildCatalogue'];

  board: BoardViewModel;
  healthResolutionLockActive: boolean;
  healthResolutionPresentationActive: boolean;
  healthResolutionOverlay?: HealthResolutionPresentationVm;
  myFleetHealthDeltaFlash?: FleetAreaHealthDeltaFlashVm;
  opponentFleetHealthDeltaFlash?: FleetAreaHealthDeltaFlashVm;
  healthDeltaPresentationKey?: string;

  readyEnabled: boolean;
  readyDisabledReason: string | null;
  resumeSyncLocked: boolean;

  battleLogHistory: BattleLogHistoryResponse | null;

  getMajorPhaseLabel: (phaseKey: string) => string;
  getSubphaseLabelFromPhaseKey: (phaseKey: string) => string;
  
  chatEntries: GameSessionChatEntry[];
  controllersByPlayerId?: Record<string, { kind?: string; chosenPlanId?: string }>;

  // New params for menu/end-of-game panels
  isFinished: boolean;
  winnerPlayerId: string | null;
  resultReason:
    | 'decisive'
    | 'narrow'
    | 'mutual_destruction'
    | 'resignation'
    | 'timeout'
    | 'timeout_draw'
    | 'agreement'
    | null;
  
  // Ready UX state (SENDING/WAITING labels)
  readyUx: { clickedThisPhase: boolean; sendingNow: boolean };
  
  // Server availableActions for charge panels
  availableActions: any[] | null;

  // Selection state for ship choice panels
  selectedChoiceIdBySourceInstanceId: Record<string, string>;
  allocatedDestroyTargetIdsBySourceInstanceId: Record<string, string[]>;
  allocatedDestroyTargetIdBySourceInstanceId: Record<string, string>;
  destroyTargetSatisfiedBySourceInstanceId: Record<string, boolean>;
  
  // Raw gameData for server truth
  gameData: any;
  shipsByPlayerId?: Record<string, any[]>;
  chronoswarmRolls?: unknown[];
  
  // Left rail dice presentation (client-delayed during health lock)
  leftRailDiceValue: 1 | 2 | 3 | 4 | 5 | 6;
  leftRailDiceAnimateKey: number;
  leftRailTurnTakeoverTurn: number | null;
  leftRailTurnTakeoverAnimateKey: number;
  leftRailChronoswarmAnimateKey: number;

  // Client-only build preview counts (used for special panels like Frigate trigger selection)
  buildPreviewCounts: Record<string, number>;

  // Client-only Frigate trigger selections (ordered list, length = buildPreviewCounts.FRI)
  frigateSelectedTriggers: number[];

  // Client-only Evolver selections (existing EVO instances + preview EVO rows)
  evolverRowIds: string[];
  evolverChoicesByRowId: Record<string, EvolverChoiceId>;
  buildDrawingFamilySwitch?: {
    activeFamily: BuildDrawingActionFamily;
    availableFamilies: BuildDrawingActionFamily[];
  };
  firstStrikeFamilySwitch?: {
    activeFamily: FirstStrikeActionFamily;
    availableFamilies: FirstStrikeActionFamily[];
  };
  centaurChargeSubTab?: CentaurChargeSubTabId;
  centaurChargeAvailableTabs?: CentaurChargeSubTabId[];
  buildDrawingEconomyDisplay?: {
    ordinaryAvailable: number;
    joiningAvailable: number;
    projectedSavedOrdinary: number;
    projectedSavedJoining: number;
    projectedSavedCombined: number;
    projectedSavedWasCapped: boolean;
  } | null;
}): GameSessionViewModel {
  const {
    isBootstrapping,
    viewer,
    me,
    opponent,
    displayLeftPlayer,
    displayRightPlayer,
    displayLeftSpeciesLabel,
    displayRightSpeciesLabel,
    displayLeftSpeciesId,
    displayRightSpeciesId,
    p1HasJoined,
    p2HasJoined,
    p1IsReady,
    p2IsReady,
    p1ClockFormatted,
    p2ClockFormatted,
    p1StatusText,
    p2StatusText,
    p1StatusTone,
    p2StatusTone,
    turnNumber,
    phaseKey,
    phaseIcon,
    effectiveGameId,
    allPlayers,
    activePanelId,
    tabs,
    buildCatalogue,
    board,
    healthResolutionPresentationActive,
    healthResolutionOverlay,
    myFleetHealthDeltaFlash,
    opponentFleetHealthDeltaFlash,
    healthDeltaPresentationKey,
    readyEnabled,
    readyDisabledReason,
    resumeSyncLocked,
    battleLogHistory,
    getMajorPhaseLabel,
    getSubphaseLabelFromPhaseKey,
    chatEntries,
    controllersByPlayerId,
    isFinished,
    winnerPlayerId,
    resultReason,
    readyUx,
    availableActions,
    selectedChoiceIdBySourceInstanceId,
    allocatedDestroyTargetIdsBySourceInstanceId,
    allocatedDestroyTargetIdBySourceInstanceId,
    destroyTargetSatisfiedBySourceInstanceId,
    gameData,
    shipsByPlayerId = {},
    chronoswarmRolls,
    leftRailDiceValue,
    leftRailDiceAnimateKey,
    leftRailTurnTakeoverTurn,
    leftRailTurnTakeoverAnimateKey,
    leftRailChronoswarmAnimateKey,
    buildPreviewCounts,
    frigateSelectedTriggers,
    evolverRowIds,
    evolverChoicesByRowId,
    buildDrawingFamilySwitch,
    firstStrikeFamilySwitch,
    centaurChargeSubTab,
    centaurChargeAvailableTabs,
    buildDrawingEconomyDisplay,
  } = args;
  const isSpectator = viewer.isSpectator === true;
  
  // Map chat entries to LeftRail VM format
  const chatMessages = chatEntries.map(entry =>
    entry.type === 'system'
      ? {
          type: 'system' as const,
          text: entry.content ?? '',
        }
      : entry.type === 'rematch_invite'
        ? {
            type: 'rematch_invite' as const,
            text: entry.content ?? (entry.playerName ? `${entry.playerName} wants to play again` : 'Rematch invite'),
            targetGameId: entry.newGameId ?? null,
          }
        : {
            type: 'player' as const,
            playerName: entry.playerName ?? 'Unknown',
            text: entry.content ?? '',
          }
  );

  // ============================================================================
  // E2) DERIVE DISPLAY NAMES (MY NAME FIRST)
  // ============================================================================
  
    const displayLeftName = displayLeftPlayer?.name || 'Player 1';
    const displayRightName = displayRightPlayer?.name || 'Player 2';
    const getDisplayPlayerIdentityKey = (player: any): string | null =>
      player?.id ?? player?.playerId ?? player?.sessionId ?? null;

    // Use the same derivation as vm.gameCode (mapVm does not have `gameId`)
    const gameCode = effectiveGameId
        ? effectiveGameId.substring(0, 6).toUpperCase()
        : 'NOGAME';

    // Big heading
    const title = `${displayLeftName} vs ${displayRightName}`;

    // Small line under it
    const inProgressSubtitle = `Shapeships Game #${gameCode} - Turn ${turnNumber}`;
    const battleLogVm = mapBattleLogTurns({
      battleLogHistory,
      localPlayerId: displayLeftPlayer?.playerId ?? displayLeftPlayer?.id ?? displayLeftPlayer?.sessionId ?? null,
      localPlayerName: displayLeftName,
      opponentPlayerId: displayRightPlayer?.playerId ?? displayRightPlayer?.id ?? displayRightPlayer?.sessionId ?? null,
      opponentName: displayRightName,
    });
  const playerEntries = Array.isArray(allPlayers)
    ? allPlayers.filter((player: any) => player?.role === 'player')
    : [];
  
  // ============================================================================
  // E4) SWITCH PANEL ID WHEN FINISHED
  // ============================================================================
  
  let finalActivePanelId = activePanelId;
  let finalTabs = tabs;
  
  if (isFinished && !healthResolutionPresentationActive) {
    if (finalActivePanelId === 'ap.menu.root') {
      finalActivePanelId = 'ap.end_of_game.result';
    }

    // Update Menu tab to point to end-of-game panel
    finalTabs = tabs.map(tab => {
      if (tab.tabId === 'tab.menu') {
        return {
          ...tab,
          targetPanelId: 'ap.end_of_game.result' as ActionPanelId,
        };
      }
      return tab;
    });
  }

  // ============================================================================
  // E5) RESULT BANNER BACKGROUND: WINNING SPECIES
  // ============================================================================
  
  // Map species to CSS var
  function speciesToBannerBgCssVar(species: SpeciesId | null): string {
    switch (species) {
      case 'human':
        return 'var(--shapeships-pastel-blue)';
      case 'xenite':
        return 'var(--shapeships-pastel-green)';
      case 'centaur':
        return 'var(--shapeships-pastel-red)';
      case 'ancient':
        return 'var(--shapeships-pastel-purple)';
      default:
        // Default to Human blue if species unknown
        return 'var(--shapeships-pastel-blue)';
    }
  }

  function normalizeSpecies(species: unknown): SpeciesId | null {
    switch (typeof species === 'string' ? species.toLowerCase() : null) {
      case 'human':
        return 'human';
      case 'xenite':
        return 'xenite';
      case 'centaur':
        return 'centaur';
      case 'ancient':
        return 'ancient';
      default:
        return null;
    }
  }
  
  // ============================================================================
  // E6) RESULT HEADLINE TEXT RULES
  // ============================================================================

  const winnerPlayer = winnerPlayerId
    ? allPlayers.find((player: any) =>
        player?.id === winnerPlayerId ||
        player?.playerId === winnerPlayerId ||
        player?.sessionId === winnerPlayerId
      ) ?? null
    : null;
  const displayLeftWon = Boolean(
    winnerPlayerId &&
    (
      winnerPlayerId === displayLeftPlayer?.playerId ||
      winnerPlayerId === displayLeftPlayer?.id ||
      winnerPlayerId === displayLeftPlayer?.sessionId
    )
  );
  const displayRightWon = Boolean(
    winnerPlayerId &&
    (
      winnerPlayerId === displayRightPlayer?.playerId ||
      winnerPlayerId === displayRightPlayer?.id ||
      winnerPlayerId === displayRightPlayer?.sessionId
    )
  );
  const winnerName = winnerPlayer?.name
    ?? (displayLeftWon ? displayLeftName : undefined)
    ?? (displayRightWon ? displayRightName : undefined)
    ?? 'Unknown player';
  const winnerSpeciesId =
    displayLeftWon
      ? displayLeftSpeciesId
      : displayRightWon
        ? displayRightSpeciesId
        : normalizeSpecies(winnerPlayer?.faction ?? winnerPlayer?.species);

  let bannerText: string;
  let bannerBgCssVar: string;

  switch (resultReason) {
    case 'decisive':
      bannerText = `Decisive Victory! ${winnerName} wins!`;
      bannerBgCssVar = speciesToBannerBgCssVar(winnerSpeciesId);
      break;
    case 'narrow':
      bannerText = `Narrow Victory! ${winnerName} wins!`;
      bannerBgCssVar = speciesToBannerBgCssVar(winnerSpeciesId);
      break;
    case 'timeout':
      bannerText = `Time Victory! ${winnerName} wins!`;
      bannerBgCssVar = speciesToBannerBgCssVar(winnerSpeciesId);
      break;
    case 'resignation':
      bannerText = `Victory! ${winnerName} wins!`;
      bannerBgCssVar = speciesToBannerBgCssVar(winnerSpeciesId);
      break;
    case 'agreement':
      bannerText = 'Draw by agreement! Live long and prosper.';
      bannerBgCssVar = 'var(--shapeships-grey-50)';
      break;
    case 'mutual_destruction':
      bannerText = 'Draw! You both blew up.';
      bannerBgCssVar = 'var(--shapeships-grey-50)';
      break;
    case 'timeout_draw':
      bannerText = 'Draw! Time expired.';
      bannerBgCssVar = 'var(--shapeships-grey-50)';
      break;
    default:
      if (winnerPlayerId) {
        bannerText = `Victory! ${winnerName} wins!`;
        bannerBgCssVar = speciesToBannerBgCssVar(winnerSpeciesId);
      } else {
        bannerText = 'Draw!';
        bannerBgCssVar = 'var(--shapeships-grey-50)';
      }
      break;
  }

  const isDrawResult =
    resultReason === 'mutual_destruction' ||
    resultReason === 'agreement' ||
    resultReason === 'timeout_draw';

  const finalP1StatusText =
    !p1HasJoined
      ? undefined
      : !isFinished
        ? p1StatusText
        : !winnerPlayerId || isDrawResult
          ? 'Draw'
          : displayLeftWon
            ? 'Won'
            : 'Lost';

  const finalP2StatusText =
    !p2HasJoined
      ? undefined
      : !isFinished
        ? p2StatusText
        : !winnerPlayerId || isDrawResult
          ? 'Draw'
          : displayRightWon
            ? 'Won'
            : 'Lost';

  const finalP1StatusTone: HudStatusTone =
    !finalP1StatusText ? 'hidden' : (!isFinished && finalP1StatusText === 'Ready' ? 'ready' : 'neutral');

  const finalP2StatusTone: HudStatusTone =
    !finalP2StatusText ? 'hidden' : (!isFinished && finalP2StatusText === 'Ready' ? 'ready' : 'neutral');
  
  // ============================================================================
  // E7) RESULT META LINE STRINGS
  // ============================================================================
  
  const metaLeftText = `Game Over. ${turnNumber} turns.`;
  const metaRightText = title; // Same title string as in-progress
  const rematchHelperText =
    opponent?.id != null && controllersByPlayerId?.[opponent.id]?.kind === 'bot'
      ? 'Play again against computer'
      : 'Link will be posted in chat';
  
  // ============================================================================
  // DERIVE ACTION PANEL UI DATA (frigateDrawing, evolverDrawing, shipChoices)
  // ============================================================================

  // Helper: Get fleet count
  function getFleetCount(
    myFleet: Array<{ shipDefId: string; count: number }> | undefined,
    shipDefId: string
  ): number {
    if (!myFleet) return 0;
    const found = myFleet.find(e => e?.shipDefId === shipDefId);
    const n = found?.count;
    return typeof n === 'number' && Number.isInteger(n) && n > 0 ? n : 0;
  }

  const myFleet = board.mode === 'board' ? board.myFleet : undefined;

  // Frigate drawing (build preview count, not fleet count)
  const frigateCount = Number.isInteger(buildPreviewCounts?.FRI) ? Math.max(0, buildPreviewCounts.FRI) : 0;
  const frigateDrawing = frigateCount > 0 ? { frigateCount, selectedTriggers: frigateSelectedTriggers } : undefined;

  const evolverDrawing = evolverRowIds.length > 0
    ? {
        rows: evolverRowIds.map((rowId) => ({
          rowId,
          choiceId: evolverChoicesByRowId[rowId] ?? 'hold',
        })),
      }
    : undefined;

  function formatBuildDrawingReadyNote(args: {
    ordinary: number;
    joining: number;
    combined: number;
    wasCapped: boolean;
  }): string {
    const cappedSuffix = args.wasCapped ? ' (max)' : '';

    if (args.ordinary > 0 && args.joining > 0) {
      const lineLabel = args.ordinary === 1 ? 'line' : 'lines';
      return `Save ${args.ordinary} ${lineLabel} + ${args.joining}j${cappedSuffix}`;
    }

    if (args.ordinary > 0) {
      const lineLabel = args.ordinary === 1 ? 'line' : 'lines';
      return `Save ${args.ordinary} ${lineLabel}${cappedSuffix}`;
    }

    if (args.joining > 0) {
      return `Save ${args.joining}j${cappedSuffix}`;
    }

    return `Save ${args.combined} lines${cappedSuffix}`;
  }

  // ============================================================================
  // READY BUTTON LABEL DERIVATION (CLIENT UX LAYER)
  // ============================================================================
  //
  // Goals:
  // - Server remains authority on readiness (p1IsReady/p2IsReady)
  // - Client can show "SENDING..." while awaiting the ready intent flow
  // - Client can show "WAITING..." when player was auto-readied because they have no actions
  //
  // IMPORTANT: ReadyButton primitive shows grey background only when selected=false and disabled=true.
  // Selected branch is always green in ReadyButton.tsx.
  // So for SENDING/WAITING we force selected=false.
  //
  // ============================================================================
  
  let readyButtonLabel = 'READY';
  let readyButtonNote: string | null = null;
  let finalReadyDisabled = !readyEnabled;
  let finalReadyDisabledReason = readyDisabledReason;
  let finalReadySelected = p1IsReady;
  let autoReadyWaiting = false;
  
  // Helper: detect whether I have any actionable input this phase
  // Conservative rule: any availableActions means "I have something".
  // In your current code, availableActions is authoritative for charge phases and null otherwise.
  // This is enough for the WAITING heuristic without server changes.
  const iHaveActionsThisPhase =
    Array.isArray(availableActions) && availableActions.length > 0;
  
  if (isFinished) {
    // Game over: button shows "GAME OVER" and is disabled
    readyButtonLabel = 'GAME OVER';
    finalReadyDisabled = true;
    finalReadySelected = false;
    finalReadyDisabledReason = 'Game over.';
  } else if (healthResolutionPresentationActive) {
    readyButtonLabel = 'RESOLVING';
    finalReadyDisabled = true;
    finalReadySelected = false;
    finalReadyDisabledReason = null;
  } else if (resumeSyncLocked) {
    readyButtonLabel = 'SYNCING...';
    finalReadyDisabled = true;
    finalReadySelected = false;
    finalReadyDisabledReason = null;
  } else if (readyUx?.sendingNow) {
    // Case 1: user clicked Ready and we are awaiting server validation/refresh
    readyButtonLabel = 'SENDING...';
    finalReadyDisabled = true;
    finalReadySelected = false;
    finalReadyDisabledReason = null;
  } else {
    // Case 2: auto-ready because I have no actions; show WAITING if opponent not ready yet.
    //
    // Condition:
    // - server says I'm ready (p1IsReady)
    // - I did NOT explicitly click ready this phase (clickedThisPhase false)
    // - I have no actions this phase (no availableActions)
    // - opponent not ready (still waiting on them)
    autoReadyWaiting =
      p1IsReady &&
      !readyUx?.clickedThisPhase &&
      !iHaveActionsThisPhase &&
      !p2IsReady;
    
    if (autoReadyWaiting) {
      readyButtonLabel = 'WAITING...';
      finalReadyDisabled = true;
      finalReadySelected = false;
      finalReadyDisabledReason = null;
    }
  }

  let subphaseTitle = isFinished ? 'Game Over' : getSubphaseLabelFromPhaseKey(phaseKey);
  let subphaseTitleSuffix: string | null = null;
  let mobileSubphaseTitleExtra: string | null = null;
  let subphaseSubheading = isFinished ? '\u00A0' : getMajorPhaseLabel(phaseKey);

  if (!isFinished && phaseKey === 'battle.end_of_turn_resolution') {
    subphaseTitle = 'End of Turn';
    subphaseSubheading = 'Healing and damage is resolved';
  }

  if (!isFinished && isSpectator && phaseKey === 'build.drawing') {
    subphaseTitle = 'Drawing';
    subphaseTitleSuffix = null;
    subphaseSubheading = 'Players are drawing ships';
  } else if (!isFinished && buildDrawingEconomyDisplay != null) {
    subphaseTitle = String(buildDrawingEconomyDisplay.ordinaryAvailable);
    subphaseTitleSuffix = 'lines available';
    mobileSubphaseTitleExtra = buildDrawingEconomyDisplay.joiningAvailable > 0
      ? `+${buildDrawingEconomyDisplay.joiningAvailable} joining`
      : null;
    subphaseSubheading = buildDrawingEconomyDisplay.joiningAvailable > 0
      ? `${buildDrawingEconomyDisplay.joiningAvailable} joining lines available`
      : 'Spend lines to build ships';

    if (!healthResolutionPresentationActive && !readyUx?.sendingNow && !autoReadyWaiting && !p1IsReady) {
      readyButtonLabel = 'READY';
      readyButtonNote = formatBuildDrawingReadyNote({
        ordinary: buildDrawingEconomyDisplay.projectedSavedOrdinary,
        joining: buildDrawingEconomyDisplay.projectedSavedJoining,
        combined: buildDrawingEconomyDisplay.projectedSavedCombined,
        wasCapped: buildDrawingEconomyDisplay.projectedSavedWasCapped,
      });
    }
  }

  if (
    phaseKey === 'build.ships_that_build' &&
    !isFinished &&
    !healthResolutionPresentationActive &&
    !readyUx?.sendingNow &&
    !autoReadyWaiting &&
    !p1IsReady &&
    readyEnabled
  ) {
    readyButtonLabel = 'READY';
    readyButtonNote = 'Proceed to Drawing';
  }

  if (!isFinished && phaseKey === 'battle.reveal') {
    readyButtonLabel = 'REVEALING';
    readyButtonNote = null;
    finalReadyDisabled = true;
    finalReadySelected = false;
    finalReadyDisabledReason = null;
  } else if (!isFinished && phaseKey === 'battle.end_of_turn_resolution') {
    readyButtonLabel = 'RESOLVING';
    readyButtonNote = null;
    finalReadyDisabled = true;
    finalReadySelected = false;
    finalReadyDisabledReason = null;
  }

  if (!isFinished && healthResolutionPresentationActive) {
    readyButtonLabel = 'RESOLVING';
    readyButtonNote = null;
    finalReadyDisabled = true;
    finalReadySelected = false;
    finalReadyDisabledReason = null;
  }
  
  // Ship choices (derive groups from registry spec)
  let shipChoices:
    | {
        groups: ShipChoicesPanelGroup[];
        showOpponentAlsoHasCharges?: boolean;
        opponentEligibleAtDeclarationStart?: boolean;
        opponentAlsoHasChargesHeading?: string;
        opponentAlsoHasChargesLines?: string[];
        selectedChoiceIdBySourceInstanceId?: Record<string, string>;
        centaurChargeTabs?: {
          activeTab: CentaurChargeSubTabId;
          availableTabs: CentaurChargeSubTabId[];
        };
      }
    | undefined;

  const shipChoiceSpec = getShipChoicePanelSpec(finalActivePanelId);

  if (shipChoiceSpec && shipChoiceSpec.kind === 'buttons') {
    // Check if this is a server-choice phase (use server availableActions)
    const isServerChoicePhase = 
      phaseKey === 'build.dice_roll' ||
      phaseKey === 'build.ships_that_build' ||
      phaseKey === 'battle.first_strike' ||
      phaseKey === 'battle.charge_declaration' || 
      phaseKey === 'battle.charge_response';

    const derivedGroups: ShipChoicesPanelGroup[] = [];

    if (isServerChoicePhase && Array.isArray(availableActions)) {
      // Server-choice phases: derive from authoritative availableActions
      const choiceActions = getRenderableServerChoiceActions(phaseKey, availableActions);

      // Build map of instanceId -> currentCharges for phase-start snapshot
      const chargesByInstanceId = new Map<string, number>();
      const myShips = gameData?.ships?.[me?.id] ?? [];
      const shipOrderByInstanceId = new Map<string, number>();
      for (const [shipIndex, ship] of myShips.entries()) {
        const instanceId = ship?.instanceId ?? ship?.id;
        if (instanceId) {
          if (!shipOrderByInstanceId.has(instanceId)) {
            shipOrderByInstanceId.set(instanceId, shipIndex);
          }
          chargesByInstanceId.set(instanceId, Number(ship?.chargesCurrent ?? 0));
        }
      }

      function sortActionsByFleetOrder<
        T extends { sourceInstanceId?: string; actionId?: string }
      >(actions: T[]): T[] {
        return [...actions].sort((a, b) => {
          const aOrder = shipOrderByInstanceId.get(a.sourceInstanceId ?? '');
          const bOrder = shipOrderByInstanceId.get(b.sourceInstanceId ?? '');
          const aKnown = aOrder != null;
          const bKnown = bOrder != null;

          if (aKnown && bKnown && aOrder !== bOrder) {
            return aOrder - bOrder;
          }

          if (aKnown !== bKnown) {
            return aKnown ? -1 : 1;
          }

          const actionIdCompare = (a.actionId ?? '').localeCompare(b.actionId ?? '');
          if (actionIdCompare !== 0) {
            return actionIdCompare;
          }

          return (a.sourceInstanceId ?? '').localeCompare(b.sourceInstanceId ?? '');
        });
      }

      for (const groupSpec of shipChoiceSpec.groups) {
        if (
          finalActivePanelId === 'ap.battle.charges.centaur' &&
          groupSpec.internalTab &&
          centaurChargeSubTab &&
          groupSpec.internalTab !== centaurChargeSubTab
        ) {
          continue;
        }

        if (groupSpec.kind === 'counted') {
          // Find all matching server actions for this shipDefId
          const matches = sortActionsByFleetOrder(
            choiceActions.filter(
              (a: any) => a.shipDefId === groupSpec.shipDefId
            )
          );

          if (matches.length === 0) continue;

          const count = matches.length;
          const heading = formatCountedShipChoiceHeading(groupSpec, count);
          const ships = matches.map((m: any) => ({
            shipDefId: groupSpec.shipDefId,
                buttons: getProjectedActionButtons({
                  buttons: getTargetedActionButtons({
                    buttons: groupSpec.buttons,
                    action: m,
                    sourceInstanceId: m.sourceInstanceId,
                    selectedChoiceIdBySourceInstanceId,
                    allocatedDestroyTargetIdsBySourceInstanceId,
                    allocatedDestroyTargetIdBySourceInstanceId,
                  }),
                  action: m,
              shipDefId: groupSpec.shipDefId,
            }),
            sourceInstanceId: m.sourceInstanceId,
            actionId: m.actionId,
            availableChoiceIds: getRenderableActionChoiceIds(m),
            currentCharges: chargesByInstanceId.get(m.sourceInstanceId) ?? null,
          }));

          derivedGroups.push({
            heading,
            ships,
            groupHelpText: groupSpec.groupHelpText,
          });
        } else if (groupSpec.kind === 'named') {
          // Named group: expand each ship per server action instance
          const expandedShips: Array<{
            shipDefId: ShipDefId;
            buttons: typeof groupSpec.ships[number]['buttons'];
            sourceInstanceId: string;
            actionId: string;
            availableChoiceIds: string[];
            currentCharges: number | null;
          }> = [];

          for (const ship of groupSpec.ships) {
            const matches = sortActionsByFleetOrder(
              choiceActions.filter(
                (a: any) => a.shipDefId === ship.shipDefId
              )
            );

            for (const m of matches) {
              expandedShips.push({
                shipDefId: ship.shipDefId,
                buttons: getProjectedActionButtons({
                  buttons: getTargetedActionButtons({
                    buttons: ship.buttons,
                    action: m,
                    sourceInstanceId: m.sourceInstanceId,
                    selectedChoiceIdBySourceInstanceId,
                    allocatedDestroyTargetIdsBySourceInstanceId,
                    allocatedDestroyTargetIdBySourceInstanceId,
                  }),
                  action: m,
                  shipDefId: ship.shipDefId,
                }),
                sourceInstanceId: m.sourceInstanceId,
                actionId: m.actionId,
                availableChoiceIds: getRenderableActionChoiceIds(m),
                currentCharges: chargesByInstanceId.get(m.sourceInstanceId) ?? null,
              });
            }
          }

          if (expandedShips.length > 0) {
            derivedGroups.push({
              heading: getNamedGroupHeading(phaseKey, groupSpec.heading, gameData),
              ships: expandedShips,
              groupHelpText: groupSpec.groupHelpText,
            });
          }
        }
      }
    } else {
      // NON-CHARGE PHASES: Derive from fleet counts (existing behavior)
      for (const groupSpec of shipChoiceSpec.groups) {
        if (groupSpec.kind === 'counted') {
          // Counted group: derive count from fleet
          const count = getFleetCount(myFleet, groupSpec.shipDefId);
          if (count === 0) continue; // skip if player has none

          const heading = formatCountedShipChoiceHeading(groupSpec, count);
          const ships = Array.from({ length: count }, () => ({
            shipDefId: groupSpec.shipDefId,
            buttons: groupSpec.buttons,
          }));

          derivedGroups.push({
            heading,
            ships,
            groupHelpText: groupSpec.groupHelpText,
          });
        } else if (groupSpec.kind === 'named') {
          // Named group: expand each ship by its fleet count
          const expandedShips: Array<{
            shipDefId: ShipDefId;
            buttons: typeof groupSpec.ships[number]['buttons'];
          }> = [];

          for (const ship of groupSpec.ships) {
            const count = getFleetCount(myFleet, ship.shipDefId);
            if (count === 0) continue; // skip if player has none

            // Expand to count instances
            for (let i = 0; i < count; i++) {
              expandedShips.push({
                shipDefId: ship.shipDefId,
                buttons: ship.buttons,
              });
            }
          }

          // Only include group if at least one ship present
          if (expandedShips.length > 0) {
            derivedGroups.push({
              heading: getNamedGroupHeading(phaseKey, groupSpec.heading, gameData),
              ships: expandedShips,
              groupHelpText: groupSpec.groupHelpText,
            });
          }
        }
      }
    }

    // Only set shipChoices if we have groups
    if (derivedGroups.length > 0) {
      const eligibleSnapshot =
        gameData?.turnData?.chargeDeclarationEligibleByPlayerId as Record<string, boolean> | undefined;

      const opponentEligibleAtDeclarationStart =
        phaseKey === 'battle.charge_declaration' &&
        !!(opponent?.id && eligibleSnapshot && eligibleSnapshot[opponent.id] === true);

      shipChoices = {
        groups: derivedGroups,
        showOpponentAlsoHasCharges: shipChoiceSpec.showOpponentAlsoHasCharges ?? false,
        opponentEligibleAtDeclarationStart,
        opponentAlsoHasChargesHeading: undefined,
        opponentAlsoHasChargesLines: undefined,
        selectedChoiceIdBySourceInstanceId,
        centaurChargeTabs:
          finalActivePanelId === 'ap.battle.charges.centaur' &&
          centaurChargeSubTab &&
          Array.isArray(centaurChargeAvailableTabs) &&
          centaurChargeAvailableTabs.length > 0
            ? {
                activeTab: centaurChargeSubTab,
                availableTabs: centaurChargeAvailableTabs,
              }
            : undefined,
      };
    }
  }

  // Server-projected actions for the CURRENT phase (safe default)
  const availableActionsSafe = availableActions ?? [];
  const hasActionsForMe = Array.isArray(availableActionsSafe) && availableActionsSafe.length > 0;
  const currentPlayerId = me?.id ?? null;
  const activePlayers = playerEntries;
  const authoritativePendingDrawOffer = (() => {
    const pendingDrawOffer = gameData?.pendingDrawOffer;
    if (
      pendingDrawOffer &&
      typeof pendingDrawOffer.offererPlayerId === 'string' &&
      typeof pendingDrawOffer.offereePlayerId === 'string'
    ) {
      return pendingDrawOffer;
    }

    const legacyOfferedBy = gameData?.drawAgreement?.offeredBy;
    if (typeof legacyOfferedBy !== 'string' || legacyOfferedBy.length === 0) {
      return null;
    }

    const inferredOfferee = activePlayers.find((player: any) => player?.id !== legacyOfferedBy);
    if (!inferredOfferee?.id) {
      return null;
    }

    return {
      offererPlayerId: legacyOfferedBy,
      offereePlayerId: inferredOfferee.id,
      offeredTurnNumber: turnNumber,
    };
  })();
  const drawOffererName = (() => {
    if (!authoritativePendingDrawOffer) {
      return null;
    }

    const offererId = authoritativePendingDrawOffer.offererPlayerId;
    if (offererId === me?.id) {
      return me?.name ?? 'Player 1';
    }
    if (offererId === opponent?.id) {
      return opponent?.name ?? 'Player 2';
    }

    const matchingPlayer = activePlayers.find((player: any) => player?.id === offererId);
    return matchingPlayer?.name ?? 'Unknown player';
  })();
  const canRespondToDrawOffer =
    !isFinished &&
    currentPlayerId != null &&
    authoritativePendingDrawOffer?.offereePlayerId === currentPlayerId;
  const currentTurnLastDrawOffer =
    currentPlayerId != null
      ? gameData?.lastDrawOfferTurnByPlayerId?.[currentPlayerId]
      : null;
  const canOfferDraw =
    !isFinished &&
    me?.role === 'player' &&
    Boolean(opponent?.id) &&
    authoritativePendingDrawOffer == null &&
    currentTurnLastDrawOffer !== turnNumber;
  const canResign = !isFinished && me?.role === 'player';
  const getPlayerIdentityKey = (player: any): string | null =>
    player?.playerId ?? player?.id ?? player?.sessionId ?? null;
  const getPlayerIdentityKeys = (player: any): Set<string> => {
    const keys = [player?.playerId, player?.id, player?.sessionId]
      .filter((value): value is string => typeof value === 'string' && value.length > 0);
    return new Set(keys);
  };
  const menuMeIdentityKey = getPlayerIdentityKey(me);
  const menuMeIdentityKeys = getPlayerIdentityKeys(me);
  const onlyOneJoinedSeat = p1HasJoined !== p2HasJoined;
  const onlyJoinedPlayer = onlyOneJoinedSeat
    ? p1HasJoined
      ? me
      : p2HasJoined
        ? opponent
        : null
    : null;
  const onlyJoinedPlayerIdentityKey = getPlayerIdentityKey(onlyJoinedPlayer);
  const onlyJoinedPlayerMatchesViewer =
    menuMeIdentityKey != null &&
    onlyJoinedPlayerIdentityKey != null &&
    onlyJoinedPlayerIdentityKey === menuMeIdentityKey;
  const hasExplicitOpponentBotController = (() => {
    if (!controllersByPlayerId || typeof controllersByPlayerId !== 'object') {
      return false;
    }

    if (opponent?.id && controllersByPlayerId[opponent.id]?.kind === 'bot') {
      return true;
    }

    return Object.entries(controllersByPlayerId).some(([playerId, controller]) =>
      controller?.kind === 'bot' && !menuMeIdentityKeys.has(playerId)
    );
  })();
  const canAbortGame =
    !isFinished &&
    me?.role === 'player' &&
    onlyOneJoinedSeat &&
    onlyJoinedPlayerMatchesViewer &&
    !hasExplicitOpponentBotController;
  const largeChoicePanelOverrides = (() => {
    if (finalActivePanelId === 'ap.battle.first_strike.centaur') {
      const domActions = getRenderableServerChoiceActions(phaseKey, availableActions).filter(
        (action) => action.kind === 'destroy_target' && action.shipDefId === 'DOM'
      );

      if (domActions.length === 0) {
        return undefined;
      }

      const domAction =
        domActions.find((action) =>
          destroyTargetSatisfiedBySourceInstanceId[action.sourceInstanceId] !== true
        ) ?? domActions[0];

      const requiredTargetCount = getRenderableActionRequiredTargetCount(domAction);
      const isComplete = isRenderableTargetedActionComplete({
        action: domAction,
        selectedChoiceIdBySourceInstanceId,
        allocatedDestroyTargetIdsBySourceInstanceId,
        allocatedDestroyTargetIdBySourceInstanceId,
      });

      if (!isComplete && requiredTargetCount === 2) {
        return { instruction: 'You must select two basic enemy ships on the battlefield to steal!' };
      }

      if (!isComplete) {
        return { instruction: 'You must select one basic enemy ship on the battlefield to steal!' };
      }

      return {
        instruction: requiredTargetCount === 2
          ? 'Steal opponent ships'
          : 'Steal opponent ship',
      };
    }

    if (finalActivePanelId !== 'ap.battle.first_strike.xenite') {
      return undefined;
    }

    const sacActions = getRenderableServerChoiceActions(phaseKey, availableActions).filter(
      (action) => action.kind === 'destroy_target' && action.shipDefId === 'SAC'
    );

    if (sacActions.length === 0) {
      return undefined;
    }

    const currentSacAction =
      sacActions.find((action) =>
        destroyTargetSatisfiedBySourceInstanceId[action.sourceInstanceId] !== true
      ) ?? sacActions[0];

    const currentSourceInstanceId =
      typeof currentSacAction?.sourceInstanceId === 'string'
        ? currentSacAction.sourceInstanceId
        : null;

    const meId = typeof me?.id === 'string' ? me.id : null;
    const myFleet = meId ? gameData?.ships?.[meId] ?? [] : [];
    const sacBuiltThisTurnIds = Array.isArray(myFleet)
      ? myFleet
        .filter((ship: any) =>
          ship?.shipDefId === 'SAC' &&
          ship?.createdTurn === turnNumber &&
          typeof ship?.instanceId === 'string'
        )
        .map((ship: any) => ship.instanceId as string)
      : [];
    const sacBuiltThisTurnIdSet = new Set(sacBuiltThisTurnIds);

    const unresolvedSourceInstanceIds = sacActions
      .map((action) => action?.sourceInstanceId)
      .filter(
        (sourceInstanceId): sourceInstanceId is string =>
          typeof sourceInstanceId === 'string' && sourceInstanceId.length > 0
      );

    const onceOnlyFired = gameData?.powerMemory?.onceOnlyFired;
    const resolvedSourceInstanceIds: string[] = [];
    if (onceOnlyFired && typeof onceOnlyFired === 'object') {
      for (const [memoryKey, didFire] of Object.entries(onceOnlyFired as Record<string, unknown>)) {
        if (didFire !== true || !memoryKey.endsWith('::SAC#0')) continue;
        const sourceInstanceId = memoryKey.slice(0, -'::SAC#0'.length);
        if (!sacBuiltThisTurnIdSet.has(sourceInstanceId)) continue;
        resolvedSourceInstanceIds.push(sourceInstanceId);
      }
    }

    const fullStableSacSourceInstanceIds = Array.from(
      new Set([...unresolvedSourceInstanceIds, ...resolvedSourceInstanceIds])
    ).sort((a, b) => a.localeCompare(b));

    let title = 'Sacrificial Pool';
    if (fullStableSacSourceInstanceIds.length > 1 && currentSourceInstanceId) {
      const ordinalIndex = fullStableSacSourceInstanceIds.indexOf(currentSourceInstanceId);
      if (ordinalIndex >= 0) {
        title = `Sacrificial Pool ${ordinalIndex + 1}`;
      }
    }

    return {
      title,
      instruction: 'You must destroy an enemy basic ship.',
    };
  })();

  
  const vm: GameSessionViewModel = {
    isBootstrapping,
    viewer,
    
    hud: {
      p1Name: displayLeftName,
      p1Species: displayLeftSpeciesLabel,
      p1IsOnline: true,
      p1Clock: p1ClockFormatted, // Placeholder clock
      p1IsReady,
      p1StatusText: finalP1StatusText,
      p1StatusTone: finalP1StatusTone,
      
      p2Name: isSpectator ? displayRightName : (p2HasJoined ? displayRightName : 'Waiting...'),
      p2Species: displayRightSpeciesLabel,
      p2IsOnline: true,
      p2Clock: p2ClockFormatted, // Placeholder clock
      p2IsReady,
      p2StatusText: finalP2StatusText,
      p2StatusTone: finalP2StatusTone,
    },
    
    leftRail: {
      diceValue: leftRailDiceValue,
      diceAnimateKey: leftRailDiceAnimateKey,
      turnTakeoverTurn: leftRailTurnTakeoverTurn,
      turnTakeoverAnimateKey: leftRailTurnTakeoverAnimateKey,
      diceManipulationSlots: (() => {
        const authoritativeShipsByPlayerId =
          gameData?.ships ??
          gameData?.gameData?.ships ??
          {};

        const liveShips = Object.values(authoritativeShipsByPlayerId).flatMap((ships) =>
          Array.isArray(ships) ? ships : []
        );

        function isDiceModifierDisplayEligibleForCurrentTurn(ship: any): boolean {
          const createdTurn = ship?.createdTurn;
          if (!Number.isInteger(createdTurn)) return true;
          return createdTurn < turnNumber;
        }

        const presentShipDefIds = new Set(
          liveShips
            .filter(isDiceModifierDisplayEligibleForCurrentTurn)
            .map((ship) => String(ship?.shipDefId ?? ''))
            .filter((shipDefId): shipDefId is 'LEV' | 'KNO' | 'CHR' =>
              shipDefId === 'LEV' || shipDefId === 'KNO' || shipDefId === 'CHR'
            )
        );

        const chronoswarmRolls = Array.isArray(gameData?.turnData?.chronoswarmRolls)
          ? gameData.turnData.chronoswarmRolls.filter(
              (roll: unknown): roll is 1 | 2 | 3 | 4 | 5 | 6 =>
                typeof roll === 'number' && Number.isInteger(roll) && roll >= 1 && roll <= 6
            )
          : [];

        const levSlot = presentShipDefIds.has('LEV')
          ? {
              sourceShipDefId: 'LEV' as const,
              diceValues: [6 as const],
            }
          : null;

        const knoSlot = presentShipDefIds.has('KNO')
          ? {
              sourceShipDefId: 'KNO' as const,
            }
          : null;

        const chrSlot = presentShipDefIds.has('CHR')
          ? {
              sourceShipDefId: 'CHR' as const,
              diceValues: chronoswarmRolls,
              animateKey: leftRailChronoswarmAnimateKey,
            }
          : null;

        if (chrSlot) {
          return {
            left: knoSlot ?? levSlot,
            right: chrSlot,
          };
        }

        if (knoSlot && levSlot) {
          return {
            left: knoSlot,
            right: levSlot,
          };
        }

        return {
          left: knoSlot ?? levSlot,
          right: null,
        };
      })(),
      turn: turnNumber,
      phase: getMajorPhaseLabel(phaseKey),
      phaseIcon,
      subphase: getSubphaseLabelFromPhaseKey(phaseKey),
      gameCode: effectiveGameId ? effectiveGameId.substring(0, 6).toUpperCase() : 'NOGAME',
      chatMessages,
      drawOffer:
        authoritativePendingDrawOffer && drawOffererName
          ? {
              fromPlayer: drawOffererName,
              canRespond: canRespondToDrawOffer,
            }
          : null,
      ...battleLogVm,
    },
    
    board: board.mode === 'board'
      ? {
          ...board,
          mobileDiceModifierSlots: deriveMobileDiceModifierSlots({
            shipsByPlayerId,
            topPlayerId: getDisplayPlayerIdentityKey(displayRightPlayer),
            bottomPlayerId: getDisplayPlayerIdentityKey(displayLeftPlayer),
            turnNumber,
            chronoswarmRolls,
            chronoswarmAnimateKey: leftRailChronoswarmAnimateKey,
          }),
          myFleetHealthDeltaFlash,
          opponentFleetHealthDeltaFlash,
          healthDeltaPresentationKey,
        }
      : board,
    
    bottomActionRail: {
      // Future: build.drawing custom heading "X/Y lines available" + breakdown "Saved + Bonus + Dice" must come from server-authoritative fields (do not compute client-side).
      // Future: charge declaration/response subtexts should be gated by server-projected availability (e.g. availableActions / boolean), not guessed client-side.
      subphaseTitle,
      subphaseTitleSuffix,
      mobileSubphaseTitleExtra,
      subphaseSubheading,
      canUndoActions: false,
      readyButtonVisible: !isFinished && !isSpectator,
      readyButtonLabel,
      readyButtonNote,
      nextPhaseLabel: 'NEXT PHASE',
      readyDisabled: finalReadyDisabled,
      readyDisabledReason: finalReadyDisabledReason,
      readySelected: finalReadySelected,
      spectatorCount: allPlayers.filter((p: any) => p?.role === 'spectator').length,
      isSpectatorViewer: isSpectator,
    },
    
    actionPanel: {
      activePanelId: finalActivePanelId,
      tabs: finalTabs,
      buildCatalogue,
      menu: {
        title,
        subtitle: inProgressSubtitle,
        turnNumber,
        phaseKey,
        isSpectator,
        hasActionsForMe,
        canOfferDraw,
        canResign,
        canAbortGame,
      },
      endOfGame: isFinished ? {
        bannerText,
        bannerBgCssVar,
        metaLeftText,
        metaRightText,
        rematchHelperText,
      } : undefined,
      healthResolutionOverlay,
      tabInteractionLocked: healthResolutionPresentationActive,
      frigateDrawing,
      evolverDrawing,
      shipChoices,
      phaseLocalFamilySwitch:
        buildDrawingFamilySwitch && finalActivePanelId !== 'ap.menu.root'
          ? {
              phase: 'build.drawing' as const,
              activeFamily: buildDrawingFamilySwitch.activeFamily,
              availableFamilies: buildDrawingFamilySwitch.availableFamilies,
            }
          : firstStrikeFamilySwitch
            ? {
                phase: 'battle.first_strike' as const,
                activeFamily: firstStrikeFamilySwitch.activeFamily,
                availableFamilies: firstStrikeFamilySwitch.availableFamilies,
              }
            : undefined,
      largeChoicePanel: largeChoicePanelOverrides,
      availableActions: availableActionsSafe,
      selectedChoiceIdBySourceInstanceId,
    },
  };

  return vm;
}
