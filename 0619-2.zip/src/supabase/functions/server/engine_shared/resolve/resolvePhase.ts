/**
 * RESOLVE PHASE
 *
 * Single entry point for shared phase resolution.
 * Orchestrates: Ship Powers → Effects → Application
 *
 * WORKFLOW:
 * 1. Collect structured powers from active ships
 * 2. Translate powers to effects for current phase
 * 3. Apply effects to game state
 * 4. Return updated state + events
 *
 * This pass implements only battle.end_of_turn_resolution.
 * Future passes will expand to other phases.
 */

import type {
  GameState,
  LastTurnBreakdownRow,
  PendingTurnBreakdownEntry,
  ShipInstance,
} from '../../engine/state/GameStateTypes.ts';
import { GAME_STATE_TYPES_VERSION } from '../../engine/state/GameStateTypes.ts';
import type { PhaseKey } from '../phase/PhaseTable.ts';
import type { Effect, CreateShipEffect } from '../effects/Effect.ts';
import { EffectTiming, EffectKind, SurvivabilityRule } from '../effects/Effect.ts';
import { translateShipPowers, type TranslateContext } from '../effects/translateShipPowers.ts';
import { applyEffects, type EffectEvent } from '../effects/applyEffects.ts';
import {
  createBattleLogBuildCaptureEventsFromResolution,
  createBattleLogFinalizeTurnEvent,
  createBattleLogFrigateHitCaptureEventsFromResolution,
} from '../../engine/state/battleLogHistory.ts';
import {
  appendShipActivationCueBatch,
  getShipActivationSourcesFromAppliedEffects,
} from '../../engine/state/shipActivationCues.ts';
import { getCanonicalShipFamilyDisplayName } from '../defs/ShipDefinitionNames.ts';
import { getShipDefinition } from '../defs/ShipDefinitions.withStructuredPowers.ts';
import {
  computePhaseComputedEffects,
  applyComputedEffectModifiers,
  getEffectiveDiceRollForPlayer,
} from './phaseComputedEffects.ts';
import { debugLog } from '../../utils/serverLogger.ts';

function countCreatedShipsByTargetPlayerId(
  effects: Effect[]
): Record<string, number> {
  const counts: Record<string, number> = {};

  for (const effect of effects) {
    if (effect.kind !== EffectKind.CreateShip) continue;

    const playerId = effect.target.playerId;
    counts[playerId] = (counts[playerId] || 0) + 1;
  }

  return counts;
}

function incrementShipsMadeThisTurnCounter(
  state: GameState,
  countsByPlayerId: Record<string, number>
): GameState {
  const entries = Object.entries(countsByPlayerId).filter(([, amount]) =>
    Number.isInteger(amount) && amount > 0
  );

  if (entries.length === 0) return state;

  const priorTurnData = state.gameData.turnData || {};
  const priorCounts = priorTurnData.shipsMadeThisTurnByPlayerId || {};
  const nextCounts = { ...priorCounts };

  for (const [playerId, amount] of entries) {
    nextCounts[playerId] = (nextCounts[playerId] || 0) + amount;
  }

  return {
    ...state,
    gameData: {
      ...state.gameData,
      turnData: {
        ...priorTurnData,
        shipsMadeThisTurnByPlayerId: nextCounts,
      },
    },
  };
}

function getShipsThatBuildPassIndex(state: GameState): 1 | 2 {
  return state.gameData?.turnData?.shipsThatBuildPassIndex === 2 ? 2 : 1;
}

function getChronoswarmCountForPlayer(state: GameState, playerId: string): number {
  const raw = state.gameData?.turnData?.chronoswarmCountByPlayerId?.[playerId];
  const value = typeof raw === 'number' ? raw : 0;
  return Number.isInteger(value) && value > 0 ? value : 0;
}

function playerParticipatesInShipsThatBuildPass(
  state: GameState,
  playerId: string
): boolean {
  const passIndex = getShipsThatBuildPassIndex(state);
  return passIndex === 1 || getChronoswarmCountForPlayer(state, playerId) > 0;
}

function collectQueenAutoBuildEffects(
  state: GameState,
  phaseKey: PhaseKey
): CreateShipEffect[] {
  const currentTurn =
    state.gameData?.turnData?.turnNumber ??
    state.gameData?.turnNumber ??
    1;

  const activePlayers = state.players.filter((player) => player.role === 'player');
  const effects: CreateShipEffect[] = [];

  for (const player of activePlayers) {
    if (!playerParticipatesInShipsThatBuildPass(state, player.id)) continue;

    const fleet = state.gameData.ships?.[player.id] || [];
    const eligibleQueens = fleet.filter(
      (ship) => ship.shipDefId === 'QUE' && (ship.createdTurn ?? 0) < currentTurn
    );

    for (const queen of eligibleQueens) {
      effects.push({
        id: `queen_build_${currentTurn}_${queen.instanceId}`,
        ownerPlayerId: player.id,
        source: {
          type: 'ship',
          instanceId: queen.instanceId,
          shipDefId: queen.shipDefId,
        },
        timing: phaseKey,
        activationTag: EffectTiming.Automatic,
        target: { playerId: player.id },
        survivability: SurvivabilityRule.DiesWithSource,
        kind: EffectKind.CreateShip,
        shipDefId: 'XEN',
      });
    }
  }

  return effects;
}

function collectBugBreederAutoBuildEffects(
  state: GameState,
  phaseKey: PhaseKey
): Effect[] {
  const currentTurn =
    state.gameData?.turnData?.turnNumber ??
    state.gameData?.turnNumber ??
    1;

  const activePlayers = state.players.filter((player) => player.role === 'player');
  const effects: Effect[] = [];

  for (const player of activePlayers) {
    if (!playerParticipatesInShipsThatBuildPass(state, player.id)) continue;

    const fleet = state.gameData.ships?.[player.id] || [];
    const eligibleBugBreeders = fleet.filter(
      (ship) =>
        ship.shipDefId === 'BUG' &&
        (ship.createdTurn ?? 0) < currentTurn &&
        (ship.chargesCurrent ?? 0) >= 1
    );

    for (const bugBreeder of eligibleBugBreeders) {
      effects.push({
        id: `bug_build_${currentTurn}_${bugBreeder.instanceId}_charge`,
        ownerPlayerId: player.id,
        source: {
          type: 'ship',
          instanceId: bugBreeder.instanceId,
          shipDefId: bugBreeder.shipDefId,
        },
        timing: phaseKey,
        activationTag: EffectTiming.Automatic,
        target: { playerId: player.id },
        survivability: SurvivabilityRule.DiesWithSource,
        kind: EffectKind.SpendCharge,
        amount: 1,
      });

      effects.push({
        id: `bug_build_${currentTurn}_${bugBreeder.instanceId}_xenite`,
        ownerPlayerId: player.id,
        source: {
          type: 'ship',
          instanceId: bugBreeder.instanceId,
          shipDefId: bugBreeder.shipDefId,
        },
        timing: phaseKey,
        activationTag: EffectTiming.Automatic,
        target: { playerId: player.id },
        survivability: SurvivabilityRule.DiesWithSource,
        kind: EffectKind.CreateShip,
        shipDefId: 'XEN',
      });
    }
  }

  return effects;
}

function collectZenithAutoBuildEffects(
  state: GameState,
  phaseKey: PhaseKey
): CreateShipEffect[] {
  const currentTurn =
    state.gameData?.turnData?.turnNumber ??
    state.gameData?.turnNumber ??
    1;

  const activePlayers = state.players.filter((player) => player.role === 'player');
  const effects: CreateShipEffect[] = [];
  const passIndex = getShipsThatBuildPassIndex(state);

  for (const player of activePlayers) {
    if (!playerParticipatesInShipsThatBuildPass(state, player.id)) continue;

    const fleet = state.gameData.ships?.[player.id] || [];
    const eligibleZeniths = fleet.filter(
      (ship) => ship.shipDefId === 'ZEN' && (ship.createdTurn ?? 0) < currentTurn
    );
    const roll = passIndex === 2
      ? state.gameData?.turnData?.chronoswarmRolls?.[0]
      : getEffectiveDiceRollForPlayer(state, player.id);

    for (const zenith of eligibleZeniths) {
      if (roll === 2) {
        effects.push({
          id: `zenith_build_${currentTurn}_${zenith.instanceId}_xen_0`,
          ownerPlayerId: player.id,
          source: {
            type: 'ship',
            instanceId: zenith.instanceId,
            shipDefId: zenith.shipDefId,
          },
          timing: phaseKey,
          activationTag: EffectTiming.Automatic,
          target: { playerId: player.id },
          survivability: SurvivabilityRule.DiesWithSource,
          kind: EffectKind.CreateShip,
          shipDefId: 'XEN',
        });
        continue;
      }

      if (roll === 3) {
        effects.push({
          id: `zenith_build_${currentTurn}_${zenith.instanceId}_ant_0`,
          ownerPlayerId: player.id,
          source: {
            type: 'ship',
            instanceId: zenith.instanceId,
            shipDefId: zenith.shipDefId,
          },
          timing: phaseKey,
          activationTag: EffectTiming.Automatic,
          target: { playerId: player.id },
          survivability: SurvivabilityRule.DiesWithSource,
          kind: EffectKind.CreateShip,
          shipDefId: 'ANT',
        });
        continue;
      }

      if (roll === 4) {
        for (let i = 0; i < 2; i++) {
          effects.push({
            id: `zenith_build_${currentTurn}_${zenith.instanceId}_xen_${i}`,
            ownerPlayerId: player.id,
            source: {
              type: 'ship',
              instanceId: zenith.instanceId,
              shipDefId: zenith.shipDefId,
            },
            timing: phaseKey,
            activationTag: EffectTiming.Automatic,
            target: { playerId: player.id },
            survivability: SurvivabilityRule.DiesWithSource,
            kind: EffectKind.CreateShip,
            shipDefId: 'XEN',
          });
        }
      }
    }
  }

  return effects;
}

function getPlayerMaxHealth(): number {
  return 35;
}

type TurnTotals = {
  damageByPlayerId: Record<string, number>;
  healByPlayerId: Record<string, number>;
};

type LastTurnBreakdownSnapshots = {
  damageDealtByPlayerId: Record<string, LastTurnBreakdownRow[]>;
  healingReceivedByPlayerId: Record<string, LastTurnBreakdownRow[]>;
};

function buildBaseAmountByEffectId(effects: Effect[]): Record<string, number> {
  const baseAmountByEffectId: Record<string, number> = {};

  for (const effect of effects) {
    if (effect.kind !== EffectKind.Damage && effect.kind !== EffectKind.Heal) continue;
    baseAmountByEffectId[effect.id] = effect.amount;
  }

  return baseAmountByEffectId;
}

function formatAmountText(amount: number): string {
  return String(amount);
}

function sortBreakdownRows(rows: LastTurnBreakdownRow[]): LastTurnBreakdownRow[] {
  return [...rows].sort((a, b) => {
    if (b.amount !== a.amount) return b.amount - a.amount;
    return a.label.localeCompare(b.label);
  });
}

function getSanitizedEntryAmount(rawAmount: number): number {
  return Number.isFinite(rawAmount) ? rawAmount : 0;
}

function getSignedFinalAmountForPendingEntry(
  entry: PendingTurnBreakdownEntry,
  mapAmount: (entry: PendingTurnBreakdownEntry, amount: number) => number
): number {
  const baseAmount = getSanitizedEntryAmount(entry.baseAmount);
  const fallbackFinalAmount = baseAmount;
  const finalAmount = getSanitizedEntryAmount(
    Number.isFinite(entry.finalAmount) ? entry.finalAmount : fallbackFinalAmount
  );
  return mapAmount(entry, finalAmount);
}

function buildRowsForPendingEntries(
  entries: PendingTurnBreakdownEntry[],
  sciLabel: string,
  mapAmount: (entry: PendingTurnBreakdownEntry, amount: number) => number = (_, amount) => amount
): LastTurnBreakdownRow[] {
  const shipBuckets = new Map<string, { shipDefId: string; instanceIds: Set<string>; amount: number }>();
  const syntheticBuckets = new Map<string, number>();
  let sciAdjustmentAmount = 0;

  for (const entry of entries) {
    const baseAmount = mapAmount(entry, getSanitizedEntryAmount(entry.baseAmount));
    const finalAmount = getSignedFinalAmountForPendingEntry(entry, mapAmount);
    const sciDelta = finalAmount - baseAmount;
    sciAdjustmentAmount += sciDelta;

    if (baseAmount === 0) continue;

    if (entry.sourceShipDefId) {
      const existing = shipBuckets.get(entry.sourceShipDefId) ?? {
        shipDefId: entry.sourceShipDefId,
        instanceIds: new Set<string>(),
        amount: 0,
      };

      if (entry.sourceInstanceId) {
        existing.instanceIds.add(entry.sourceInstanceId);
      }

      existing.amount += baseAmount;
      shipBuckets.set(entry.sourceShipDefId, existing);
      continue;
    }

    const syntheticLabel = entry.sourceLabel || 'System';
    syntheticBuckets.set(syntheticLabel, (syntheticBuckets.get(syntheticLabel) || 0) + baseAmount);
  }

  const rows: LastTurnBreakdownRow[] = [];

  for (const bucket of shipBuckets.values()) {
    if (bucket.amount === 0) continue;
    const count = Math.max(bucket.instanceIds.size, 1);
    rows.push({
      rowKind: 'ship',
      label: getCanonicalShipFamilyDisplayName(bucket.shipDefId, count),
      count,
      amount: bucket.amount,
      amountText: formatAmountText(bucket.amount),
    });
  }

  for (const [label, amount] of syntheticBuckets.entries()) {
    if (amount === 0) continue;
    rows.push({
      rowKind: 'adjustment',
      label,
      amount,
      amountText: formatAmountText(amount),
    });
  }

  if (sciAdjustmentAmount !== 0) {
    rows.push({
      rowKind: 'adjustment',
      label: sciLabel,
      amount: sciAdjustmentAmount,
      amountText: formatAmountText(sciAdjustmentAmount),
    });
  }

  return sortBreakdownRows(rows.filter((row) => row.amount !== 0));
}

function buildLastTurnBreakdownSnapshots(
  state: GameState,
  totals: TurnTotals
): LastTurnBreakdownSnapshots {
  const activePlayers = state.players.filter((player) => player.role === 'player');
  const damageDealtByPlayerId: Record<string, LastTurnBreakdownRow[]> = {};
  const healingReceivedByPlayerId: Record<string, LastTurnBreakdownRow[]> = {};
  const opponentIdByPlayerId = new Map<string, string>();

  if (activePlayers.length === 2) {
    opponentIdByPlayerId.set(activePlayers[0].id, activePlayers[1].id);
    opponentIdByPlayerId.set(activePlayers[1].id, activePlayers[0].id);
  }

  const pendingEntries = state.gameData.pendingTurn?.breakdownEntries || [];

  for (const player of activePlayers) {
    const opponentId = opponentIdByPlayerId.get(player.id);
    const damageEntries = pendingEntries.filter(
      (entry) =>
        entry.kind === 'Damage' &&
        entry.ownerPlayerId === player.id &&
        entry.targetPlayerId === opponentId
    );
    const sustainEntries = pendingEntries.filter(
      (entry) =>
        (entry.kind === 'Heal' && entry.targetPlayerId === player.id) ||
        (
          entry.kind === 'Damage' &&
          entry.ownerPlayerId === player.id &&
          entry.targetPlayerId === player.id
        )
    );
    damageDealtByPlayerId[player.id] = buildRowsForPendingEntries(
      damageEntries,
      'Science Vessel'
    );
    healingReceivedByPlayerId[player.id] = buildRowsForPendingEntries(
      sustainEntries,
      'Science Vessel',
      (entry, amount) => entry.kind === 'Damage' ? -amount : amount
    );
  }

  return {
    damageDealtByPlayerId,
    healingReceivedByPlayerId,
  };
}

// ============================================================================
// RESOLVE PHASE
// ============================================================================

/**
 * Resolve a phase by processing all ship powers and applying effects
 *
 * @param state - Current game state
 * @param phaseKey - Phase key to resolve
 * @returns Updated state and events
 */
export function resolvePhase(
  state: GameState,
  phaseKey: PhaseKey
): { state: GameState; events: any[] } {
  debugLog(`[resolvePhase] Resolving phase: ${phaseKey}`);
  debugLog(`[resolvePhase] GameStateTypes version: ${GAME_STATE_TYPES_VERSION}`);

  // Handle ships_that_build phase (create ships from ship-building powers)
  if (phaseKey === 'build.ships_that_build') {
    return resolveShipsThatBuild(state, phaseKey);
  }

  // Handle end-of-build automatic ship creation
  if (phaseKey === 'build.end_of_build') {
    return resolveBuildEndOfBuild(state, phaseKey);
  }

  // Handle battle end-of-turn resolution (damage/heal effects)
  if (phaseKey === 'battle.end_of_turn_resolution') {
    return resolveBattleEndOfTurn(state, phaseKey);
  }

  // No resolution logic for other phases
  debugLog(`[resolvePhase] No resolution logic for phase: ${phaseKey}`);
  return { state, events: [] };
}

// ============================================================================
// SHIPS THAT BUILD RESOLUTION
// ============================================================================

/**
 * Resolve the ships_that_build phase by creating ships from ship-building powers
 *
 * @param state - Current game state
 * @param phaseKey - Phase key to resolve
 * @returns Updated state and events
 */
function resolveShipsThatBuild(
  state: GameState,
  phaseKey: PhaseKey
): { state: GameState; events: any[] } {
  debugLog(`[resolveShipsThatBuild] Resolving phase: ${phaseKey}`);
  const stateBeforeResolution = state;
  const turnNumber =
    stateBeforeResolution.gameData?.turnData?.turnNumber ??
    stateBeforeResolution.gameData?.turnNumber ??
    1;

  // Collect all effects from all ships
  const effects = [
    ...collectEffectsForPhase(state, phaseKey),
    ...collectBugBreederAutoBuildEffects(state, phaseKey),
    ...collectQueenAutoBuildEffects(state, phaseKey),
    ...collectZenithAutoBuildEffects(state, phaseKey),
  ];

  debugLog(`[resolveShipsThatBuild] Collected ${effects.length} effects for ${phaseKey}`);

  // Apply effects to state
  let result = applyEffects(state, effects);
  const allEvents: any[] = [...result.events];
  const createdShipsByPlayerId = countCreatedShipsByTargetPlayerId(effects);
  result = {
    ...result,
    state: incrementShipsMadeThisTurnCounter(
      result.state,
      createdShipsByPlayerId
    ),
  };

  debugLog(`[resolveShipsThatBuild] Applied effects, generated ${result.events.length} events`);

  for (const player of state.players.filter((entry) => entry.role === 'player')) {
    const playerEffects = effects.filter((effect) => effect.ownerPlayerId === player.id);
    allEvents.push(
      ...createBattleLogBuildCaptureEventsFromResolution({
        stateBeforeResolution,
        turnNumber,
        playerId: player.id,
        effects: playerEffects,
        effectEvents: result.events,
      }),
    );
  }

  const shipsThatBuildPassIndex =
    state.gameData?.turnData?.shipsThatBuildPassIndex === 2 ? 2 : 1;
  const stateWithActivationCues = appendShipActivationCueBatch(result.state, {
    key: `ship-activation:${turnNumber}:${phaseKey}:pass:${shipsThatBuildPassIndex}`,
    phaseKey,
    sources: getShipActivationSourcesFromAppliedEffects(effects, result.events),
  });

  return {
    ...result,
    state: stateWithActivationCues,
    events: allEvents,
  };
}

// ============================================================================
// BUILD END-OF-BUILD RESOLUTION
// ============================================================================

function resolveBuildEndOfBuild(
  state: GameState,
  phaseKey: PhaseKey
): { state: GameState; events: any[] } {
  debugLog(`[resolveBuildEndOfBuild] Resolving phase: ${phaseKey}`);
  const stateBeforeResolution = state;

  const currentTurn =
    state.gameData?.turnData?.turnNumber ??
    state.gameData?.turnNumber ??
    1;

  const priorTurnData = state.gameData.turnData || {};
  if (priorTurnData.buildEndOfBuildAppliedTurnNumber === currentTurn) {
    debugLog(`[resolveBuildEndOfBuild] Already applied for turn ${currentTurn}, skipping`);
    return { state, events: [] };
  }

  let workingState: GameState = {
    ...state,
    gameData: {
      ...state.gameData,
      turnData: {
        ...priorTurnData,
        buildEndOfBuildAppliedTurnNumber: currentTurn,
      },
    },
  };

  const activePlayers = workingState.players.filter((player) => player.role === 'player');
  const redemptionSources = activePlayers.flatMap((player) => {
    const fleet = workingState.gameData.ships?.[player.id] || [];
    return fleet
      .filter(
        (ship) =>
          ship.shipDefId === 'RED' &&
          (ship.createdTurn ?? 0) === currentTurn
      )
      .map((ship) => ({
        playerId: player.id,
        sourceInstanceId: ship.instanceId,
      }));
  });

  workingState = {
    ...workingState,
    players: workingState.players.map((player) => {
      if (player.role !== 'player') return player;

      const fleet = workingState.gameData.ships?.[player.id] || [];
      const builtRedThisTurn = fleet.some(
        (ship) =>
          ship.shipDefId === 'RED' &&
          (ship.createdTurn ?? 0) === currentTurn
      );

      if (!builtRedThisTurn) return player;

      // RED sets health directly during build.end_of_build; this is not healing.
      return {
        ...player,
        health: getPlayerMaxHealth(),
      };
    }),
  };

  const fighterEffects: CreateShipEffect[] = [];

  for (const player of activePlayers) {
    const fleet = workingState.gameData.ships?.[player.id] || [];
    const dreadnoughts = fleet.filter((ship) => ship.shipDefId === 'DRE');
    const totalShipsMadeThisTurn =
      workingState.gameData.turnData?.shipsMadeThisTurnByPlayerId?.[player.id] ?? 0;

    if (dreadnoughts.length <= 0 || totalShipsMadeThisTurn <= 0) continue;

    for (const dreadnought of dreadnoughts) {
      const shipsMade =
        (dreadnought.createdTurn ?? 0) === currentTurn
          ? Math.max(totalShipsMadeThisTurn - 1, 0)
          : totalShipsMadeThisTurn;

      if (shipsMade <= 0) continue;

      for (let i = 0; i < shipsMade; i++) {
        fighterEffects.push({
          id: `dreadnought_build_${currentTurn}_${dreadnought.instanceId}_${i}`,
          ownerPlayerId: player.id,
          source: {
            type: 'ship',
            instanceId: dreadnought.instanceId,
            shipDefId: dreadnought.shipDefId,
          },
          timing: phaseKey,
          activationTag: EffectTiming.Automatic,
          target: { playerId: player.id },
          survivability: SurvivabilityRule.DiesWithSource,
          kind: EffectKind.CreateShip,
          shipDefId: 'FIG',
          free: true,
          createdBy: 'dreadnought',
        });
      }

      debugLog(
        `[resolveBuildEndOfBuild] Dreadnought ${dreadnought.instanceId} spawning ${shipsMade} fighter(s) for player ${player.id}`
      );
    }
  }

  if (fighterEffects.length === 0) {
    debugLog('[resolveBuildEndOfBuild] No Dreadnought fighters to spawn');
    return {
      state: appendShipActivationCueBatch(workingState, {
        key: `ship-activation:${currentTurn}:${phaseKey}`,
        phaseKey,
        sources: redemptionSources,
      }),
      events: [],
    };
  }

  const applied = applyEffects(workingState, fighterEffects);
  const allEvents: any[] = [...applied.events];

  for (const player of activePlayers) {
    const playerEffects = fighterEffects.filter((effect) => effect.ownerPlayerId === player.id);
    allEvents.push(
      ...createBattleLogBuildCaptureEventsFromResolution({
        stateBeforeResolution,
        turnNumber: currentTurn,
        playerId: player.id,
        effects: playerEffects,
        effectEvents: applied.events,
      }),
    );
  }

  debugLog(
    `[resolveBuildEndOfBuild] Spawned ${fighterEffects.length} fighter(s), generated ${applied.events.length} events`
  );

  const stateWithActivationCues = appendShipActivationCueBatch(applied.state, {
    key: `ship-activation:${currentTurn}:${phaseKey}`,
    phaseKey,
    sources: [
      ...redemptionSources,
      ...getShipActivationSourcesFromAppliedEffects(
        fighterEffects,
        applied.events
      ),
    ],
  });

  return {
    ...applied,
    state: stateWithActivationCues,
    events: allEvents,
  };
}

// ============================================================================
// BATTLE END-OF-TURN RESOLUTION
// ============================================================================

/**
 * Resolve the battle.end_of_turn_resolution phase by applying damage/heal effects
 *
 * PHASE 3.0A: Deterministic aggregation via single pipeline
 * - applyEffects() accumulates Damage/Heal into state.gameData.pendingTurn
 * - Read totals from pendingTurn (no manual aggregation)
 * - Apply health mutations simultaneously (no order dependence)
 * - Store last turn deltas for UI/debug
 * - Clear pendingTurn for next turn
 *
 * @param state - Current game state
 * @param phaseKey - Phase key to resolve
 * @returns Updated state and events
 */
function resolveBattleEndOfTurn(
  state: GameState,
  phaseKey: PhaseKey
): { state: GameState; events: any[] } {
  debugLog(`[resolveBattleEndOfTurn] Resolving phase: ${phaseKey}`);
  const currentTurn =
    state.gameData?.turnData?.turnNumber ??
    state.gameData?.turnNumber ??
    1;
  const priorTurnData = state.gameData?.turnData || {};

  if (priorTurnData.endOfTurnResolutionAppliedTurnNumber === currentTurn) {
    debugLog(
      `[resolveBattleEndOfTurn] Already applied for turn ${currentTurn}, skipping`
    );
    return { state, events: [] };
  }

  // Initialize pendingTurn if not present
  if (!state.gameData.pendingTurn) {
    state = {
      ...state,
      gameData: {
        ...state.gameData,
        pendingTurn: {
          damageByPlayerId: {},
          healByPlayerId: {},
          breakdownEntries: [],
        },
      },
    };
  }

  // Initialize powerMemory if not present
  if (!state.gameData.powerMemory) {
    state = {
      ...state,
      gameData: {
        ...state.gameData,
        powerMemory: {
          onceOnlyFired: {},
        },
      },
    };
  }

  const powerMemory = state.gameData.powerMemory;
  if (!powerMemory?.onceOnlyFired) {
    state = {
      ...state,
      gameData: {
        ...state.gameData,
        powerMemory: {
          ...powerMemory,
          onceOnlyFired: {},
        },
      },
    };
  }

  // Step 1: Compute all computed effects for this phase (once-only, tiered, triggers, etc.)
  const computed = computePhaseComputedEffects(state, phaseKey);
  state = computed.state;
  const computedEffects = computed.effects;

  // Step 2: Collect all effects from ship powers
  const shipEffects = collectEffectsForPhase(state, phaseKey);

  debugLog(`[resolveBattleEndOfTurn] Collected ${shipEffects.length} ship effects + ${computedEffects.length} computed effects for ${phaseKey}`);

  // Step 3: Merge computed effects with ship effects
  const baseEffects = [...computedEffects, ...shipEffects];
  const baseAmountByEffectId = buildBaseAmountByEffectId(baseEffects);
  let effects = [...baseEffects];

  // Step 3.1: Apply computed effect modifiers (tiered multipliers, etc.)
  effects = applyComputedEffectModifiers(state, phaseKey, effects);

  // Step 4: Apply effects (accumulates Damage/Heal into pendingTurn)
  const applied = applyEffects(state, effects, { baseAmountByEffectId });
  const frigateHitCaptureEvents =
    createBattleLogFrigateHitCaptureEventsFromResolution({
      turnNumber: currentTurn,
      effects,
      effectEvents: applied.events,
    });

  debugLog(`[resolveBattleEndOfTurn] Applied effects, generated ${applied.events.length} events`);

  // Step 5: Extract totals from pendingTurn (canonical accumulation source)
  const totals = {
    damageByPlayerId: { ...(applied.state.gameData.pendingTurn?.damageByPlayerId || {}) },
    healByPlayerId: { ...(applied.state.gameData.pendingTurn?.healByPlayerId || {}) },
  };

  const lastTurnBreakdowns = buildLastTurnBreakdownSnapshots(applied.state, totals);

  debugLog(`[resolveBattleEndOfTurn] Pending turn totals:`, totals);

  // Step 6: Apply aggregated health changes simultaneously
  const healthResult = applyAggregatedHealth(applied.state, totals);
  const stateWithBreakdowns: GameState = {
    ...healthResult.state,
    gameData: {
      ...healthResult.state.gameData,
      lastTurnDamageDealtBreakdownByPlayerId: lastTurnBreakdowns.damageDealtByPlayerId,
      lastTurnHealingReceivedBreakdownByPlayerId: lastTurnBreakdowns.healingReceivedByPlayerId,
    },
  };

  debugLog(`[resolveBattleEndOfTurn] Applied aggregated health, generated ${healthResult.events.length} events`);

  // Step 7: Health clamping, victory evaluation, and terminal state
  const victoryResult = evaluateVictoryConditions(stateWithBreakdowns, [], phaseKey);

  // Step 8: Clear pendingTurn for next turn
  const clearedState = {
    ...victoryResult.state,
    gameData: {
      ...victoryResult.state.gameData,
      turnData: {
        ...(victoryResult.state.gameData?.turnData || {}),
        endOfTurnResolutionAppliedTurnNumber: currentTurn,
      },
      pendingTurn: {
        damageByPlayerId: {},
        healByPlayerId: {},
        breakdownEntries: [],
      },
    },
  };

  // Combine events: accumulation events + health change events + game over event (if any)
  const allEvents = [
    ...applied.events,
    ...frigateHitCaptureEvents,
    ...healthResult.events,
    ...victoryResult.events,
  ];

  return {
    state: appendShipActivationCueBatch(clearedState, {
      key: `ship-activation:${currentTurn}:${phaseKey}`,
      phaseKey,
      sources: getShipActivationSourcesFromAppliedEffects(
        effects,
        applied.events
      ),
    }),
    events: allEvents,
  };
}

// ============================================================================
// AGGREGATION STAGE
// ============================================================================

/**
 * Apply aggregated health changes simultaneously to all players
 *
 * @param state - Current game state
 * @param totals - Aggregated damage/heal totals
 * @returns Updated state with health applied and events generated
 */
function applyAggregatedHealth(
  state: GameState,
  totals: { damageByPlayerId: Record<string, number>; healByPlayerId: Record<string, number> }
): { state: GameState; events: EffectEvent[] } {
  const MAX_HEALTH = 35;
  const events: EffectEvent[] = [];
  const nowMs = Date.now();

  // Clone state
  const newState: GameState = { ...state };
  newState.players = [...state.players];
  newState.gameData = { ...state.gameData };

  // Track last turn deltas
  const lastTurnDamage: Record<string, number> = {};
  const lastTurnHeal: Record<string, number> = {};
  const lastTurnNet: Record<string, number> = {};

  // Apply aggregated health changes simultaneously
  for (let i = 0; i < newState.players.length; i++) {
    const player = { ...newState.players[i] };
    const playerId = player.id;

    const damage = totals.damageByPlayerId[playerId] || 0;
    const heal = totals.healByPlayerId[playerId] || 0;

    const previousHealth = player.health;
    const rawNewHealth = previousHealth - damage + heal;
    const newHealth = Math.min(rawNewHealth, MAX_HEALTH); // Clamp to max

    player.health = newHealth;
    newState.players[i] = player;

    // Store deltas
    lastTurnDamage[playerId] = damage;
    lastTurnHeal[playerId] = heal;
    lastTurnNet[playerId] = newHealth - previousHealth;

    debugLog(
      `[applyAggregatedHealth] Player ${playerId}: ${previousHealth} - ${damage} + ${heal} = ${rawNewHealth} (clamped to ${newHealth})`
    );

    // Generate event if there was a change
    if (damage > 0 || heal > 0) {
      events.push({
        type: 'EFFECT_APPLIED',
        effectId: `aggregated_${playerId}`,
        kind: 'AggregatedHealthChange',
        targetPlayerId: playerId,
        details: {
          damage,
          heal,
          previousHealth,
          newHealth,
          net: newHealth - previousHealth,
        },
        atMs: nowMs,
      });
    }
  }

  // Store last turn deltas on state
  newState.gameData = {
    ...newState.gameData,
    lastTurnDamageByPlayerId: lastTurnDamage,
    lastTurnHealByPlayerId: lastTurnHeal,
    lastTurnNetByPlayerId: lastTurnNet,
  };

  return { state: newState, events };
}

// ============================================================================
// EFFECT COLLECTION
// ============================================================================

/**
 * Collect all effects from all ships for a specific phase
 *
 * @param state - Current game state
 * @param phaseKey - Phase key to collect effects for
 * @returns Array of effects
 */
function collectEffectsForPhase(
  state: GameState,
  phaseKey: PhaseKey
): Effect[] {
  const effects: Effect[] = [];

  // Get active players (role === 'player')
  const activePlayers = state.players.filter(p => p.role === 'player');

  if (activePlayers.length !== 2) {
    console.warn(`[collectEffectsForPhase] Expected 2 active players, found ${activePlayers.length}`);
  }

  // Determine opponent for each player
  const playerIds = activePlayers.map(p => p.id);
  const opponentMap = new Map<string, string>();

  if (playerIds.length === 2) {
    opponentMap.set(playerIds[0], playerIds[1]);
    opponentMap.set(playerIds[1], playerIds[0]);
  }

  // Process each player's fleet
  for (const player of activePlayers) {
    const playerId = player.id;
    const opponentId = opponentMap.get(playerId);

    if (!opponentId) {
      console.warn(`[collectEffectsForPhase] No opponent found for player ${playerId}`);
      continue;
    }

    // Get player's ships
    const ships = state.gameData.ships?.[playerId] || [];

    debugLog(`[collectEffectsForPhase] Processing ${ships.length} ships for player ${playerId}`);

    // Process each ship
    for (const ship of ships) {
      const shipEffects = collectEffectsFromShip(
        ship,
        playerId,
        opponentId,
        phaseKey
      );

      effects.push(...shipEffects);
    }
  }

  return effects;
}

// ============================================================================
// SHIP EFFECT COLLECTION
// ============================================================================

/**
 * Collect effects from a single ship for a specific phase
 *
 * @param ship - Ship instance
 * @param ownerPlayerId - Owner player ID
 * @param opponentPlayerId - Opponent player ID
 * @param phaseKey - Phase key
 * @returns Array of effects
 */
function collectEffectsFromShip(
  ship: ShipInstance,
  ownerPlayerId: string,
  opponentPlayerId: string,
  phaseKey: PhaseKey
): Effect[] {
  // Get ship definition (joined view with structured powers)
  const shipDef = getShipDefinition(ship.shipDefId);

  if (!shipDef) {
    console.warn(`[collectEffectsFromShip] Ship definition not found: ${ship.shipDefId}`);
    return [];
  }

  // Use ship-level flattened structured powers (deterministic join output)
  const allStructuredPowers = shipDef.structuredPowers;

  if (!allStructuredPowers || allStructuredPowers.length === 0) {
    // No structured powers for this ship (expected for ships not yet implemented)
    return [];
  }

  // Create translation context
  const ctx: TranslateContext = {
    shipInstanceId: ship.instanceId,
    shipDefId: ship.shipDefId,
    ownerPlayerId,
    opponentPlayerId
  };

  // Translate structured powers to effects
  const effects = translateShipPowers(allStructuredPowers, phaseKey, ctx);

  if (effects.length > 0) {
    debugLog(
      `[collectEffectsFromShip] Ship ${ship.shipDefId} (${ship.instanceId}) ` +
      `produced ${effects.length} effects for ${phaseKey}`
    );
  }

  return effects;
}

// ============================================================================
// VICTORY EVALUATION
// ============================================================================

/**
 * Evaluate victory conditions after end-of-turn resolution
 *
 * Order:
 * 1. Clamp health to [no minimum, max 35]
 * 2. Evaluate victory conditions (player health, not ship health)
 * 3. Emit GAME_OVER if terminal
 *
 * @param state - Current game state after effects
 * @param events - Events generated during effect application
 * @param phaseKey - Phase key
 * @returns Updated state and events
 */
function evaluateVictoryConditions(
  state: GameState,
  events: EffectEvent[],
  phaseKey: PhaseKey
): { state: GameState; events: any[] } {
  // Only apply victory evaluation for end-of-turn resolution
  if (phaseKey !== 'battle.end_of_turn_resolution') {
    return { state, events };
  }

  // Skip if game is already finished (idempotent)
  if (state.status === 'finished') {
    return { state, events };
  }

  // Step 1: Clamp health to maximum 35 (no minimum clamp)
  let updatedState = clampPlayerHealth(state);

  // Step 2: Evaluate victory conditions
  const victoryResult = checkVictoryConditions(updatedState);

  // Step 3: If terminal, apply terminal state and emit GAME_OVER
  if (victoryResult.isTerminal) {
    const finalizedTurnNumber =
      updatedState.gameData?.turnData?.turnNumber ??
      updatedState.gameData?.turnNumber ??
      1;

    updatedState = {
      ...updatedState,
      status: 'finished',
      winnerPlayerId: victoryResult.winnerPlayerId,
      result: victoryResult.result,
      resultReason: victoryResult.reason,
      gameData: {
        ...updatedState.gameData,
        pendingDrawOffer: null,
        drawAgreement: null,
      },
    };

    const gameOverEvent: any = {
      type: 'GAME_OVER',
      phaseKey,
      winnerPlayerId: victoryResult.winnerPlayerId,
      result: victoryResult.result,
      finalHealth: victoryResult.finalHealth,
    };

    debugLog(
      `[Victory] Game over: ${victoryResult.result}, winner=${victoryResult.winnerPlayerId || 'null'}, ` +
      `health=${JSON.stringify(victoryResult.finalHealth)}`
    );

    return {
      state: updatedState,
      events: [
        ...events,
        createBattleLogFinalizeTurnEvent({
          finalizedTurnNumber,
          terminal: true,
          reason: 'terminal_victory',
          atMs: Date.now(),
        }),
        gameOverEvent,
      ],
    };
  }

  return { state: updatedState, events };
}

/**
 * Clamp player health to maximum of 35
 * Minimum is not clamped (negative values allowed for victory comparison)
 *
 * @param state - Current game state
 * @returns Updated state with clamped health
 */
function clampPlayerHealth(state: GameState): GameState {
  const MAX_HEALTH = 35;

  const updatedPlayers = state.players.map(player => {
    if (player.health > MAX_HEALTH) {
      return { ...player, health: MAX_HEALTH };
    }
    return player;
  });

  return {
    ...state,
    players: updatedPlayers,
  };
}

/**
 * Check victory conditions based on player health
 *
 * Rules:
 * - Decisive victory: One player health <= 0, other >= 1 (winner = survivor)
 * - Narrow victory: Both health <= 0, winner has higher health
 * - Draw: Both health <= 0 and equal
 * - No result: Game continues
 *
 * @param state - Current game state (after health clamp)
 * @returns Victory result
 */
function checkVictoryConditions(state: GameState): {
  isTerminal: boolean;
  winnerPlayerId: string | null;
  result: 'win' | 'draw';
  reason?: 'decisive' | 'narrow' | 'mutual_destruction';
  finalHealth: Record<string, number>;
} {
  // Get active players (role === 'player')
  const activePlayers = state.players.filter(p => p.role === 'player');

  if (activePlayers.length !== 2) {
    console.warn(`[checkVictoryConditions] Expected 2 active players, found ${activePlayers.length}`);
    return {
      isTerminal: false,
      winnerPlayerId: null,
      result: 'draw',
      finalHealth: {},
    };
  }

  const p1 = activePlayers[0];
  const p2 = activePlayers[1];
  const h1 = p1.health;
  const h2 = p2.health;

  const finalHealth: Record<string, number> = {
    [p1.id]: h1,
    [p2.id]: h2,
  };

  // Case 1: Decisive victory (one survivor)
  if (h1 <= 0 && h2 >= 1) {
    return {
      isTerminal: true,
      winnerPlayerId: p2.id,
      result: 'win',
      reason: 'decisive',
      finalHealth,
    };
  }

  if (h2 <= 0 && h1 >= 1) {
    return {
      isTerminal: true,
      winnerPlayerId: p1.id,
      result: 'win',
      reason: 'decisive',
      finalHealth,
    };
  }

  // Case 2: Both dead - check for narrow victory or draw
  if (h1 <= 0 && h2 <= 0) {
    if (h1 > h2) {
      // P1 has higher (less negative) health
      return {
        isTerminal: true,
        winnerPlayerId: p1.id,
        result: 'win',
        reason: 'narrow',
        finalHealth,
      };
    }

    if (h2 > h1) {
      // P2 has higher (less negative) health
      return {
        isTerminal: true,
        winnerPlayerId: p2.id,
        result: 'win',
        reason: 'narrow',
        finalHealth,
      };
    }

    // Equal health - draw
    return {
      isTerminal: true,
      winnerPlayerId: null,
      result: 'draw',
      reason: 'mutual_destruction',
      finalHealth,
    };
  }

  // Case 3: No terminal condition met - game continues
  return {
    isTerminal: false,
    winnerPlayerId: null,
    result: 'draw',
    finalHealth,
  };
}
