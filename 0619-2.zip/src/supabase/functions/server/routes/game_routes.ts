// ============================================================================
// GAME ROUTES
// ============================================================================
// Core multiplayer game endpoints (create, join, state, actions)
// Mechanical extraction from index.tsx - NO BEHAVIOR CHANGES
//
// Extracted from lines 1439-2425 of original index.tsx
// ============================================================================

import type { Hono } from "npm:hono";
import { advancePhase, advancePhaseCore } from '../engine/phase/advancePhase.ts';
import { onEnterPhase } from '../engine/phase/onEnterPhase.ts';
import { syncPhaseFields } from '../engine/phase/syncPhaseFields.ts';
import { initializeClocks, ensurePlayerClock, accrueClocks, clocksAreLive } from '../engine/clock/clock.ts';
import type { TimeControlConfig } from '../engine/clock/clock.ts';
import { getBuildCommitKey } from '../engine/intent/IntentTypes.ts';
import { hasRevealed } from '../engine/intent/CommitStore.ts';
import { resolveBuildSubmitAuthoritatively } from '../engine/intent/buildSubmitResolution.ts';
import type { ShipInstance } from '../engine/state/GameStateTypes.ts';
import { getShipActivationCueBatches } from '../engine/state/shipActivationCues.ts';
import { chooseDeterministicHumanBotPlanId, chooseFreshHumanBotPlanId, getHumanBotPlanById } from '../engine/bot/humanPlans.ts';
import { runBotsUntilSettled } from '../engine/bot/botRunner.ts';
import { buildPhaseKey } from '../engine_shared/phase/PhaseTable.ts';
import { computeLineBonusesForPlayer } from '../engine/lines/computeLineBonusForPlayer.ts';
import { fleetHasAvailablePowers } from '../engine/phase/fleetHasAvailablePowers.ts';
import { getShipById } from '../engine_shared/defs/ShipDefinitions.core.ts';
import { getShipDefinition } from '../engine_shared/defs/ShipDefinitions.withStructuredPowers.ts';
import type { StructuredShipPower } from '../engine_shared/effects/translateShipPowers.ts';
import { EffectKind } from '../engine_shared/effects/Effect.ts';
import { getValidDestroyTargets, getValidShipOfEqualityTargets } from '../engine_shared/resolve/destroyRules.ts';
import { countDistinctTypes } from '../engine_shared/resolve/phaseComputedEffects.ts';
import { rollD6 } from '../engine/util/rollD6.ts';
import {
  createEmptyBattleLogHistoryStore,
  getBattleLogHistoryKey,
  normalizeBattleLogHistoryStore,
  toBattleLogHistoryResponse,
} from '../engine/state/battleLogHistory.ts';
import { appendChatEntry } from './chat_kv.ts';
import { ensureStateRevision, withBumpedStateRevision } from './state_revision.ts';
import { debugLog } from '../utils/serverLogger.ts';

const INITIAL_SAVED_LINES = 3;

const PRIVATE_GAME_TIMED_PRESETS = {
  '5_0': { minutes: 5, incrementSeconds: 0, baseMs: 300_000, incrementMs: 0 },
  '10_5': { minutes: 10, incrementSeconds: 5, baseMs: 600_000, incrementMs: 5_000 },
  '15_10': { minutes: 15, incrementSeconds: 10, baseMs: 900_000, incrementMs: 10_000 },
  '30_20': { minutes: 30, incrementSeconds: 20, baseMs: 1_800_000, incrementMs: 20_000 },
} as const;

const LEGACY_PRIVATE_GAME_PRESET_KEY = '15_10' as const;

type CreateGameRequestBody = {
  playerName?: unknown;
  timed?: unknown;
  minutes?: unknown;
  incrementSeconds?: unknown;
  variantKey?: unknown;
};

type CreateComputerGameRequestBody = CreateGameRequestBody & {
  planId?: unknown;
};

function toTimeControlConfig(preset: (typeof PRIVATE_GAME_TIMED_PRESETS)[keyof typeof PRIVATE_GAME_TIMED_PRESETS]): TimeControlConfig {
  return {
    baseMs: preset.baseMs,
    incrementMs: preset.incrementMs,
  };
}

function resolveTimedPrivateGamePreset(
  minutes: unknown,
  incrementSeconds: unknown,
): TimeControlConfig | null {
  for (const preset of Object.values(PRIVATE_GAME_TIMED_PRESETS)) {
    if (preset.minutes === minutes && preset.incrementSeconds === incrementSeconds) {
      return toTimeControlConfig(preset);
    }
  }

  return null;
}

function resolveCreateGameTimeControl(body: CreateGameRequestBody): TimeControlConfig | null {
  if (body.timed === undefined) {
    return toTimeControlConfig(PRIVATE_GAME_TIMED_PRESETS[LEGACY_PRIVATE_GAME_PRESET_KEY]);
  }

  if (body.timed === false) {
    return null;
  }

  if (body.timed !== true) {
    throw new Error('timed must be a boolean when provided');
  }

  const timeControl = resolveTimedPrivateGamePreset(body.minutes, body.incrementSeconds);
  if (!timeControl) {
    throw new Error('Invalid timed preset. Supported presets are 5+0, 10+5, 15+10, and 30+20.');
  }

  return timeControl;
}

function createFreshGameData(
  gameId: string,
  playerId: string,
  playerName: string,
  timeControl?: TimeControlConfig | null,
) {
  const nowIso = new Date().toISOString();

  let gameData = {
    gameId,
    players: [
      {
        id: playerId,
        name: playerName,
        faction: null,
        isReady: false,
        isActive: true,
        role: 'player',
        joinedAt: nowIso,
        health: 25,
        lines: INITIAL_SAVED_LINES,
        joiningLines: 0,
        energy: 0
      }
    ],
    gameData: {
      ships: {
        [playerId]: []
      },
      currentPhase: 'setup',
      currentSubPhase: 'species_selection',
      turnNumber: 0,
      diceRoll: null,
      turnData: {
        turnNumber: 0,
        currentMajorPhase: 'setup',
        currentSubPhase: 'species_selection',
        requiredSubPhases: [],
        accumulatedDamage: {},
        accumulatedHealing: {},
        healthAtTurnStart: {},
        chargesDeclared: false,
        diceRoll: null,
        linesDistributed: false
      },
      phaseReadiness: [],
      phaseStartTime: nowIso
    },
    currentPhase: 'setup',
    currentSubPhase: 'species_selection',
    turnNumber: 0,
    actions: [
      {
        playerId: "system",
        playerName: "System",
        actionType: "system",
        content: `${playerName} joined as a player`,
        timestamp: nowIso
      }
    ],
    status: "waiting",
    createdAt: nowIso,
    stateRevision: 1,
  };

  gameData = initializeClocks(gameData, timeControl);
  gameData = syncPhaseFields(gameData);

  return gameData;
}

function createFreshComputerGameData(
  gameId: string,
  playerId: string,
  playerName: string,
  chosenPlanId: string,
  timeControl?: TimeControlConfig | null,
){
  const nowIso = new Date().toISOString();
  const botPlayerId = `bot_${gameId}`;

  let gameData = {
    gameId,
    players: [
      {
        id: playerId,
        name: playerName,
        faction: null,
        isReady: false,
        isActive: true,
        role: 'player',
        joinedAt: nowIso,
        health: 25,
        lines: INITIAL_SAVED_LINES,
        joiningLines: 0,
        energy: 0,
      },
      {
        id: botPlayerId,
        name: 'Computer',
        faction: null,
        isReady: false,
        isActive: true,
        role: 'player',
        joinedAt: nowIso,
        health: 25,
        lines: INITIAL_SAVED_LINES,
        joiningLines: 0,
        energy: 0,
      },
    ],
    controllersByPlayerId: {
      [playerId]: { kind: 'human' },
      [botPlayerId]: {
        kind: 'bot',
        speciesId: 'HUM',
        chosenPlanId,
      },
    },
    gameData: {
      ships: {
        [playerId]: [],
        [botPlayerId]: [],
      },
      currentPhase: 'setup',
      currentSubPhase: 'species_selection',
      turnNumber: 0,
      diceRoll: null,
      turnData: {
        turnNumber: 0,
        currentMajorPhase: 'setup',
        currentSubPhase: 'species_selection',
        requiredSubPhases: [],
        accumulatedDamage: {},
        accumulatedHealing: {},
        healthAtTurnStart: {},
        chargesDeclared: false,
        diceRoll: null,
        linesDistributed: false,
      },
      phaseReadiness: [],
      phaseStartTime: nowIso,
    },
    currentPhase: 'setup',
    currentSubPhase: 'species_selection',
    turnNumber: 0,
    actions: [
      {
        playerId: "system",
        playerName: "System",
        actionType: "system",
        content: `${playerName} created the game`,
        timestamp: nowIso,
      },
      {
        playerId: "system",
        playerName: "System",
        actionType: "system",
        content: "Game started! Players select species.",
        timestamp: nowIso,
      },
    ],
    status: "active",
    createdAt: nowIso,
    stateRevision: 1,
  };

  gameData = initializeClocks(gameData, timeControl);
  gameData = syncPhaseFields(gameData);

  return gameData;
}

function getTargetedChoiceEffect(option: any) {
  if (!Array.isArray(option?.effects)) return null;
  return option.effects.find(
    (effect: any) =>
      effect?.kind === EffectKind.Destroy ||
      effect?.kind === EffectKind.TransferShip
  ) ?? null;
}

function getProjectedRequiredTargetCount(effect: any, validTargetCount: number): number {
  const rawRequiredTargetCount =
    typeof effect?.requiredTargetCount === 'number'
      ? effect.requiredTargetCount
      : effect?.count;
  const baseRequiredTargetCount =
    Number.isInteger(rawRequiredTargetCount) && rawRequiredTargetCount > 0
      ? rawRequiredTargetCount
      : 1;
  return Math.min(baseRequiredTargetCount, Math.max(1, validTargetCount));
}

function isFirstStrikePowerAvailableForShip(state: any, shipInstance: ShipInstance, actionId: string, power: any): boolean {
  if (power?.onceOnly === 'on_build_turn') {
    const currentTurnNumber: number = state?.gameData?.turnNumber ?? 1;
    if (shipInstance?.createdTurn !== currentTurnNumber) {
      return false;
    }
  }

  if (power?.onceOnly) {
    const onceOnlyFired = state?.gameData?.powerMemory?.onceOnlyFired ?? {};
    if (onceOnlyFired[`${shipInstance.instanceId}::${actionId}`] === true) {
      return false;
    }
  }

  return true;
}

// ============================================================================
// HELPER: Get current phase key for readiness checking
// ============================================================================
function getPhaseKey(state: any): string | null {
  const major = state?.gameData?.currentPhase;
  const sub = state?.gameData?.currentSubPhase;
  if (!major || !sub) return null;
  return buildPhaseKey(major, sub);
}

function isHiddenBuildActivationCuePhase(phaseKey: string): boolean {
  return (
    phaseKey === 'build.ships_that_build' ||
    phaseKey === 'build.end_of_build'
  );
}

function projectShipActivationCueBatches(
  value: unknown,
  currentPhaseKey: string | null,
  gameStatus: unknown
) {
  const batches = getShipActivationCueBatches(value);
  const mayRevealHiddenBuildCues =
    gameStatus === 'finished' ||
    (typeof currentPhaseKey === 'string' && currentPhaseKey.startsWith('battle.'));

  if (mayRevealHiddenBuildCues) {
    return batches;
  }

  return batches.filter(
    (batch) => !isHiddenBuildActivationCuePhase(batch.phaseKey)
  );
}

function projectRequesterShipActivationCueBatches(
  value: unknown,
  currentPhaseKey: string | null,
  gameStatus: unknown,
  currentTurnNumber: number,
  requestingPlayerId: string,
  participantRole: unknown
) {
  if (
    participantRole !== 'player' ||
    gameStatus === 'finished' ||
    (typeof currentPhaseKey === 'string' && currentPhaseKey.startsWith('battle.'))
  ) {
    return [];
  }

  return getShipActivationCueBatches(value)
    .filter(
      (batch) =>
        batch.turnNumber === currentTurnNumber &&
        isHiddenBuildActivationCuePhase(batch.phaseKey)
    )
    .map((batch) => ({
      ...batch,
      sources: batch.sources.filter(
        (source) => source.playerId === requestingPlayerId
      ),
    }))
    .filter((batch) => batch.sources.length > 0);
}

// ============================================================================
// HELPER: Get subphases for available actions check
// ============================================================================
function getSubphasesForAvailableActions(phaseKey: string | null): string[] {
  switch (phaseKey) {
    case 'build.ships_that_build': return ['Ships That Build'];
    case 'battle.first_strike': return ['First Strike'];
    // Keep this minimal for now. Add more as you implement more player-input phases.
    default: return [];
  }
}

// ============================================================================
// HELPER: Check if player has available charge or solar option
// ============================================================================
function playerHasAvailableChargeOrSolarOption(state: any, playerId: string): boolean {
  const fleet = state?.gameData?.ships?.[playerId] ?? [];
  const players = state?.players ?? state?.gameData?.players ?? [];
  const player = players.find((p: any) => p?.id === playerId);
  const playerEnergy = player?.energy ?? 0;

  for (const shipInstance of fleet) {
    const shipDef = getShipById(shipInstance.shipDefId);
    if (!shipDef) continue;

    // Must have a power that is declarable in charge declaration window
    const hasChargePower = shipDef.powers?.some((p: any) => p?.subphase === 'Charge Declaration');
    if (!hasChargePower) continue;

    // Solar Power ships require energy
    if (shipDef.shipType === 'Solar Power') {
      if (playerEnergy > 0) return true;
      continue;
    }

    // Normal charge ships require chargesCurrent > 0 (fallback to 0 if absent)
    const chargesCurrent = shipInstance?.chargesCurrent ?? 0;
    if (chargesCurrent > 0) return true;
  }

  return false;
}

function getSnappedChargeSourceIds(state: any, playerId: string): string[] {
  const rawSourceIds = state?.gameData?.turnData?.chargeDeclarationEligibleSourceIdsByPlayerId?.[playerId];
  if (!Array.isArray(rawSourceIds)) {
    return [];
  }

  const sourceIds: string[] = [];
  const seen = new Set<string>();

  for (const sourceId of rawSourceIds) {
    if (typeof sourceId !== 'string' || sourceId.length === 0 || seen.has(sourceId)) continue;
    seen.add(sourceId);
    sourceIds.push(sourceId);
  }

  return sourceIds;
}

function resolveSnappedChargeSource(state: any, playerId: string, sourceInstanceId: string): ShipInstance | null {
  const liveFleet = state?.gameData?.ships?.[playerId] ?? [];
  const liveShip = liveFleet.find((ship: ShipInstance) => ship.instanceId === sourceInstanceId);
  if (liveShip) {
    return liveShip;
  }

  const voidFleet = state?.gameData?.voidShipsByPlayerId?.[playerId] ?? [];
  return voidFleet.find((ship: ShipInstance) => ship.instanceId === sourceInstanceId) ?? null;
}

function getChargeSourceShipsForPhase(state: any, playerId: string, phaseKey: string): ShipInstance[] {
  if (phaseKey !== 'battle.charge_declaration' && phaseKey !== 'battle.charge_response') {
    return [];
  }

  const sourceShips: ShipInstance[] = [];

  for (const sourceInstanceId of getSnappedChargeSourceIds(state, playerId)) {
    const ship = resolveSnappedChargeSource(state, playerId, sourceInstanceId);
    if (!ship) continue;
    sourceShips.push(ship);
  }

  return sourceShips;
}

function getProjectedChoiceMetadataForChargeAction(
  state: any,
  playerId: string,
  phaseKey: string,
  shipDefId: string,
  liveFleet: ShipInstance[],
  choiceId: string
) {
  if (shipDefId === 'FAM' && (choiceId === 'damage' || choiceId === 'heal')) {
    const snapshot =
      phaseKey === 'battle.charge_declaration' || phaseKey === 'battle.charge_response'
        ? state?.gameData?.turnData?.chargeDeclarationFleetSnapshotByPlayerId?.[playerId]
        : undefined;
    const countFleet = Array.isArray(snapshot) ? snapshot : liveFleet;

    return {
      choiceId,
      projectedAmount: countDistinctTypes(countFleet),
    };
  }

  return { choiceId };
}

function getShipsThatBuildPassIndex(state: any): 1 | 2 {
  return state?.gameData?.turnData?.shipsThatBuildPassIndex === 2 ? 2 : 1;
}

type KnoRerollPassIndex = 1 | 2 | 3;

function getKnoRerollPassIndex(state: any): KnoRerollPassIndex {
  const passIndex = state?.gameData?.turnData?.knoRerollPassIndex;
  return passIndex === 2 || passIndex === 3 ? passIndex : 1;
}

function getKnoCountForPlayer(state: any, playerId: string): number {
  const fleet = state?.gameData?.ships?.[playerId] ?? [];
  return Array.isArray(fleet)
    ? fleet.filter((ship: any) => ship?.shipDefId === 'KNO').length
    : 0;
}

function getKnoMaxRerollPassCountForPlayer(state: any, playerId: string): KnoRerollPassIndex | 0 {
  return Math.min(3, getKnoCountForPlayer(state, playerId)) as KnoRerollPassIndex | 0;
}

function playerHasKnoRerollForPass(state: any, playerId: string, passIndex: KnoRerollPassIndex): boolean {
  return getKnoMaxRerollPassCountForPlayer(state, playerId) >= passIndex;
}

function playerIsKnoRerollStopped(state: any, playerId: string): boolean {
  return state?.gameData?.turnData?.knoRerollStoppedByPlayerId?.[playerId] === true;
}

function playerCanActInKnoRerollPass(state: any, playerId: string, passIndex: KnoRerollPassIndex): boolean {
  return playerHasKnoRerollForPass(state, playerId, passIndex) && !playerIsKnoRerollStopped(state, playerId);
}

function getRepresentativeKnoInstanceIdForPass(state: any, playerId: string, passIndex: KnoRerollPassIndex): string | null {
  const fleet = state?.gameData?.ships?.[playerId] ?? [];
  const knoInstanceIds = Array.isArray(fleet)
    ? fleet
      .filter((ship: any) => ship?.shipDefId === 'KNO' && typeof ship?.instanceId === 'string')
      .map((ship: any) => ship.instanceId)
      .sort((a: string, b: string) => a.localeCompare(b))
    : [];

  if (knoInstanceIds.length === 0) return null;
  return knoInstanceIds[passIndex - 1] ?? knoInstanceIds[0];
}

function getChronoswarmCountForPlayer(state: any, playerId: string): number {
  const raw = state?.gameData?.turnData?.chronoswarmCountByPlayerId?.[playerId];
  return Number.isInteger(raw) && raw > 0 ? raw : 0;
}

function playerParticipatesInShipsThatBuildPass(state: any, playerId: string): boolean {
  const passIndex = getShipsThatBuildPassIndex(state);
  return passIndex === 1 || getChronoswarmCountForPlayer(state, playerId) > 0;
}

function shipAlreadyUsedInShipsThatBuildPass(state: any, sourceInstanceId: string): boolean {
  const passIndex = getShipsThatBuildPassIndex(state);
  return state?.gameData?.turnData?.shipsThatBuildPassUsageByInstanceId?.[sourceInstanceId]?.[passIndex] === true;
}

function projectChronoswarmTurnData(gameData: any, requestingPlayerId: string): any {
  const turnData = gameData?.gameData?.turnData;
  if (!turnData) return gameData;

  const filteredPendingKnoRerollChoiceByPassByPlayerId: Record<string, Partial<Record<KnoRerollPassIndex, 'reroll' | 'hold'>>> = {};
  if (turnData.pendingKnoRerollChoiceByPassByPlayerId?.[requestingPlayerId]) {
    filteredPendingKnoRerollChoiceByPassByPlayerId[requestingPlayerId] =
      turnData.pendingKnoRerollChoiceByPassByPlayerId[requestingPlayerId];
  }

  return {
    ...gameData,
    gameData: {
      ...gameData.gameData,
      turnData: {
        ...turnData,
        chronoswarmRolls: Array.isArray(turnData.chronoswarmRolls)
          ? turnData.chronoswarmRolls.filter((roll: unknown): roll is number => typeof roll === 'number')
          : [],
        chronoswarmCountByPlayerId: {
          ...(turnData.chronoswarmCountByPlayerId || {}),
        },
        knoRerollPassIndex:
          turnData.knoRerollPassIndex === 3
            ? 3
            : turnData.knoRerollPassIndex === 2
              ? 2
              : turnData.knoRerollPassIndex === 1
              ? 1
              : undefined,
        pendingKnoRerollChoiceByPassByPlayerId: filteredPendingKnoRerollChoiceByPassByPlayerId,
        shipsThatBuildPassIndex:
          turnData.shipsThatBuildPassIndex === 2
            ? 2
            : turnData.shipsThatBuildPassIndex === 1
              ? 1
              : undefined,
        chronoswarmSharedRollCount:
          typeof turnData.chronoswarmSharedRollCount === 'number'
            ? turnData.chronoswarmSharedRollCount
            : undefined,
      },
    },
  };
}

function getPublicSavedResourcesForPlayer(state: any, phaseKey: string | null, playerId: string): {
  savedLines: number;
  savedJoiningLines: number;
} {
  const player = (state?.players || []).find((candidate: any) => candidate?.id === playerId);
  const snapshot =
    phaseKey === 'build.drawing'
      ? state?.gameData?.turnData?.buildDrawingPublicSavedResourcesByPlayerId?.[playerId]
      : null;

  return {
    savedLines: snapshot?.savedLines ?? player?.lines ?? 0,
    savedJoiningLines: snapshot?.savedJoiningLines ?? player?.joiningLines ?? 0,
  };
}

// ============================================================================
// HELPER: Compute available actions for requesting player
// ============================================================================
function computeAvailableActionsForRequestingPlayer(state: any, playerId: string): any[] {
  const phaseKey = getPhaseKey(state);

  if (!phaseKey) return [];

  if (phaseKey === 'build.dice_roll') {
    const passIndex = getKnoRerollPassIndex(state);
    if (!playerCanActInKnoRerollPass(state, playerId, passIndex)) {
      return [];
    }

    const sourceInstanceId = getRepresentativeKnoInstanceIdForPass(state, playerId, passIndex);
    if (!sourceInstanceId) {
      return [];
    }

    return [
      {
        kind: 'choice',
        actionId: 'KNO#0',
        shipDefId: 'KNO',
        sourceInstanceId,
        choices: [{ choiceId: 'reroll' }, { choiceId: 'hold' }],
      },
    ];
  }

  // ============================================================================
  // CHARGE PHASES: Derive choice actions from structured powers
  // ============================================================================
  if (phaseKey === 'battle.charge_declaration' || phaseKey === 'battle.charge_response') {
    const actions: any[] = [];
    
    // Phase 3.1 Slice 2 — Patch C: Hide charge actions already used this turn (server truth)
    const turnNumber: number = state?.gameData?.turnNumber ?? 1;
    const usedMap: Record<string, number> =
      state?.gameData?.turnData?.chargePowerUsedByInstanceId ?? {};
    
    // Keep live fleet for response-time legality and projections.
    const fleet = state?.gameData?.ships?.[playerId] ?? [];
    const sourceShips = getChargeSourceShipsForPhase(state, playerId, phaseKey);
    
    // For each ship instance, find eligible choice powers
    for (const shipInstance of sourceShips) {
      const shipDefId = shipInstance.shipDefId;
      const sourceInstanceId = shipInstance.instanceId;
      
      // Load ship definition with structured powers
      const shipDef = getShipDefinition(shipDefId);
      if (!shipDef || !shipDef.structuredPowers) continue;
      
      // For each structured power (powerIndex = array position)
      for (let powerIndex = 0; powerIndex < shipDef.structuredPowers.length; powerIndex++) {
        const power: StructuredShipPower = shipDef.structuredPowers[powerIndex];
        
        // Only consider choice powers
        if (power.type !== 'choice') continue;
        
        // Only consider powers whose timings include current phase
        if (!power.timings.includes(phaseKey)) continue;
        
        // Check charge eligibility
        const actionRequiresCharge =
          (power.requiresCharge ?? false) ||
          (Array.isArray(power.options) && power.options.some((o: any) => o?.requiresCharge === true));
        
        // Patch C: If this power requires charge and this ship already spent a charge this turn, it is not eligible.
        if (actionRequiresCharge && usedMap[sourceInstanceId] === turnNumber) continue;
        
        if (actionRequiresCharge) {
          const chargesCurrent = shipInstance.chargesCurrent ?? 0;
          // If power-level chargeCost exists use it, otherwise default to 1
          const chargeCost = power.chargeCost ?? 1;
          if (chargesCurrent < chargeCost) continue; // Not eligible
        }
        
        // Emit choice action
        const actionId = `${shipDefId}#${powerIndex}`;
        const choices = power.options.map((opt) =>
          getProjectedChoiceMetadataForChargeAction(
            state,
            playerId,
            phaseKey,
            shipDefId,
            fleet,
            opt.choiceId
          )
        );

        if (shipDefId === 'EQU') {
          const { validOwnTargets, validOpponentTargets } = getValidShipOfEqualityTargets(
            state,
            playerId
          );

          if (validOwnTargets.length === 0 || validOpponentTargets.length === 0) {
            continue;
          }

          actions.push({
            kind: 'paired_destroy_target',
            actionId,
            shipDefId,
            sourceInstanceId,
            choices,
            validOwnTargets,
            validOpponentTargets,
            requiredTargetCount: 2,
          });
          continue;
        }
        
        actions.push({
          kind: 'choice',
          actionId,
          shipDefId,
          sourceInstanceId,
          choices
        });
      }
    }
    
    // Stable ordering: by shipDefId, then instanceId, then actionId
    actions.sort((a, b) => {
      if (a.shipDefId !== b.shipDefId) {
        return a.shipDefId.localeCompare(b.shipDefId);
      }
      if (a.sourceInstanceId !== b.sourceInstanceId) {
        return a.sourceInstanceId.localeCompare(b.sourceInstanceId);
      }
      return a.actionId.localeCompare(b.actionId);
    });
    
    return actions;
  }

  // ============================================================================
  // BATTLE.FirstStrike: Derive targeted destroy actions from structured powers (Guardian)
  // ============================================================================
  if (phaseKey === 'battle.first_strike') {
    const actions: any[] = [];

    const turnNumber: number = state?.gameData?.turnNumber ?? 1;
    const usedMap: Record<string, number> =
      state?.gameData?.turnData?.chargePowerUsedByInstanceId ?? {};

    const fleet = state?.gameData?.ships?.[playerId] ?? [];
    const opponentId = (state?.players || []).find((p: any) => p.role === 'player' && p.id !== playerId)?.id;

    for (const shipInstance of fleet) {
      const shipDefId = shipInstance.shipDefId;
      const sourceInstanceId = shipInstance.instanceId;

      const shipDef = getShipDefinition(shipDefId);
      if (!shipDef || !shipDef.structuredPowers) continue;

      for (let powerIndex = 0; powerIndex < shipDef.structuredPowers.length; powerIndex++) {
        const power: StructuredShipPower = shipDef.structuredPowers[powerIndex];
        if (power.type !== 'choice') continue;
        if (!power.timings.includes(phaseKey)) continue;

        const requiresCharge =
          (power.requiresCharge ?? false) ||
          (Array.isArray((power as any).options) && (power as any).options.some((o: any) => (o?.requiresCharge ?? false) === true));

        if (requiresCharge && usedMap[sourceInstanceId] === turnNumber) continue;
        if (requiresCharge) {
          const chargesCurrent = shipInstance.chargesCurrent ?? 0;
          const chargeCost = power.chargeCost ?? 1;
          if (chargesCurrent < chargeCost) continue;
        }

        const actionId = `${shipDefId}#${powerIndex}`;
        if (!isFirstStrikePowerAvailableForShip(state, shipInstance, actionId, power)) continue;

        const choices = power.options.map((opt: any) => ({ choiceId: opt.choiceId }));
        const targetedOption = power.options.find((opt: any) => getTargetedChoiceEffect(opt) != null);
        if (!targetedOption || !opponentId) continue;

        const targetedEffect = getTargetedChoiceEffect(targetedOption);
        if (!targetedEffect) continue;

        const validTargets = getValidDestroyTargets(state, {
          sourcePlayerId: playerId,
          targetScope: targetedEffect.targetPlayer === 'self' ? 'self' : 'opponent',
          restriction: targetedEffect.restriction ?? 'any',
        });

        if (validTargets.length === 0) {
          continue;
        }

        actions.push({
          kind: 'destroy_target',
          actionId: `${shipDefId}#${powerIndex}`,
          shipDefId,
          sourceInstanceId,
          choices,
          validTargets,
          requiredTargetCount: getProjectedRequiredTargetCount(targetedEffect, validTargets.length),
        });
      }
    }

    actions.sort((a, b) => {
      if (a.shipDefId !== b.shipDefId) return a.shipDefId.localeCompare(b.shipDefId);
      if (a.sourceInstanceId !== b.sourceInstanceId) return a.sourceInstanceId.localeCompare(b.sourceInstanceId);
      return a.actionId.localeCompare(b.actionId);
    });

    return actions;
  }

  // ============================================================================
  // BUILD.ShipsThatBuild: Derive choice actions from structured powers (Carrier, future builders)
  // ============================================================================
  if (phaseKey === 'build.ships_that_build') {
    const actions: any[] = [];
    if (!playerParticipatesInShipsThatBuildPass(state, playerId)) {
      return [];
    }

    const fleet = state?.gameData?.ships?.[playerId] ?? [];

    for (const shipInstance of fleet) {
      const shipDefId = shipInstance.shipDefId;
      const sourceInstanceId = shipInstance.instanceId;
      if (shipAlreadyUsedInShipsThatBuildPass(state, sourceInstanceId)) continue;

      const shipDef = getShipDefinition(shipDefId);
      if (!shipDef || !shipDef.structuredPowers) continue;

      for (let powerIndex = 0; powerIndex < shipDef.structuredPowers.length; powerIndex++) {
        const power: StructuredShipPower = shipDef.structuredPowers[powerIndex];
        if (power.type !== 'choice') continue;
        if (!power.timings.includes(phaseKey)) continue;

        const chargesCurrent = shipInstance.chargesCurrent ?? 0;

        // Option-level eligibility (Carrier has mixed costs)
        const eligibleChoices = (power as any).options
          .filter((opt: any) => {
            const cid = opt?.choiceId;
            if (cid === 'hold') return true;

            const optRequiresCharge = (opt?.requiresCharge ?? false) || (power.requiresCharge ?? false);
            if (!optRequiresCharge) return true;

            const cost = opt?.chargeCost ?? power.chargeCost ?? 1;
            return chargesCurrent >= cost;
          })
          .map((opt: any) => ({ choiceId: opt.choiceId }));

        const eligibleChoiceIds = new Set(
          eligibleChoices
            .map((choice: any) => choice?.choiceId)
            .filter((choiceId: unknown): choiceId is string => typeof choiceId === 'string')
        );

        // Only emit if there is at least one real (non-hold) option
        const hasNonHold = eligibleChoices.some((c: any) => c.choiceId !== 'hold');
        if (!hasNonHold) continue;

        const destroyOption = power.options.find((opt: any) =>
          eligibleChoiceIds.has(opt?.choiceId) &&
          getTargetedChoiceEffect(opt) != null
        );

        if (destroyOption) {
          const destroyEffect = getTargetedChoiceEffect(destroyOption);
          if (!destroyEffect) continue;

          const validTargets = getValidDestroyTargets(state, {
            sourcePlayerId: playerId,
            targetScope: destroyEffect.targetPlayer === 'self' ? 'self' : 'opponent',
            restriction: destroyEffect.restriction ?? 'any',
          });

          if (validTargets.length === 0) {
            continue;
          }

          actions.push({
            kind: 'destroy_target',
            actionId: `${shipDefId}#${powerIndex}`,
            shipDefId,
            sourceInstanceId,
            choices: eligibleChoices,
            validTargets,
            requiredTargetCount: getProjectedRequiredTargetCount(destroyEffect, validTargets.length),
          });
          continue;
        }

        actions.push({
          kind: 'choice',
          actionId: `${shipDefId}#${powerIndex}`,
          shipDefId,
          sourceInstanceId,
          choices: eligibleChoices,
        });
      }
    }

    actions.sort((a, b) => {
      if (a.shipDefId !== b.shipDefId) return a.shipDefId.localeCompare(b.shipDefId);
      if (a.sourceInstanceId !== b.sourceInstanceId) return a.sourceInstanceId.localeCompare(b.sourceInstanceId);
      return a.actionId.localeCompare(b.actionId);
    });

    return actions;
  }

  // ============================================================================
  // OTHER PHASES: Use fleetHasAvailablePowers (unchanged)
  // ============================================================================
  const subphases = getSubphasesForAvailableActions(phaseKey);
  if (subphases.length === 0) return [];

  return fleetHasAvailablePowers(state, phaseKey as any, playerId, subphases)
    ? [{ kind: 'phase_input', phaseKey }]
    : [];
}

// ============================================================================
// HELPER: Reconcile build.drawing if complete (Anti-Wedge Safety Net)
// ============================================================================
function reconcileBuildDrawingIfComplete(state: any, nowMs: number) {
  const phaseKey = getPhaseKey(state);
  if (!phaseKey || phaseKey !== 'build.drawing') return state;

  const turnNumber = state?.gameData?.turnNumber ?? state?.turnNumber ?? 0;
  const commitKey = getBuildCommitKey(turnNumber);

  const activePlayers = (state.players || []).filter((p: any) => p.role === 'player');
  if (activePlayers.length === 0) return state;

  // Completion condition: all active players have revealed BUILD_${turnNumber}
  const allSubmitted = activePlayers.every((p: any) => hasRevealed(state, commitKey, p.id));
  if (!allSubmitted) return state;

  // Ensure turnData exists
  if (!state.gameData) state.gameData = {};
  if (!state.gameData.turnData) state.gameData.turnData = {};
  const resolution = resolveBuildSubmitAuthoritatively({
    state,
    turnNumber,
    nowMs,
  });
  state = resolution.state;

  if (resolution.alreadyApplied) {
    // Completed + already applied, so we only need to ensure phase advances
    console.warn('[reconcileBuildDrawingIfComplete] Builds already applied; attempting phase advance only.', {
      gameId: state.gameId,
      turnNumber,
      commitKey,
    });
  } else {
    console.warn('[reconcileBuildDrawingIfComplete] Detected completed BUILD_SUBMIT but not resolved. Applying authoritative build resolution now.', {
      gameId: state.gameId,
      turnNumber,
      commitKey,
    });
  }

  // Attempt phase advance (same approach as IntentReducer: core advance + onEnter)
  const fromKey = phaseKey;
  const adv = advancePhaseCore(state);

  if (!adv.ok) {
    console.error('[reconcileBuildDrawingIfComplete] Phase advance blocked:', adv.error);
    return state;
  }

  state = adv.state;

  // Clear readiness + sync after advance
  if (state?.gameData) {
    state.gameData.phaseReadiness = [];
  }
  state = syncPhaseFields(state);

  const toKey = getPhaseKey(state);

  // Trigger on-enter hooks
  if (toKey) {
    const onEnter = onEnterPhase(state, fromKey, toKey, nowMs);
    state = onEnter.state;
    // We do NOT push events into actions log here (GET route), just reconcile state.
  }

  console.warn('[reconcileBuildDrawingIfComplete] Phase advanced via reconciliation.', {
    gameId: state.gameId,
    from: fromKey,
    to: toKey,
    turnNumber,
  });

  return state;
}

// ============================================================================
// HELPER: Apply game-state maintenance pipeline for GET responses (read-only; no persistence)
// ============================================================================
function applyGameStateMaintenance(state: any, nowMs: number): any {
  let s = state;
  // Safe maintenance for GET responses only:
  // - syncPhaseFields: keep derived phase fields consistent
  // - accrueClocks: compute up-to-date clock view
  // IMPORTANT: Do NOT run reconciliation that can advance phases in GET.
  s = syncPhaseFields(s);
  s = accrueClocks(s, nowMs);
  return s;
}

function doesStateNeedPhaseSync(state: any): boolean {
  const gameData = state?.gameData ?? {};
  const turnData = gameData?.turnData ?? {};
  const major =
    gameData.currentPhase ??
    turnData.currentMajorPhase ??
    state?.currentPhase;
  const sub =
    gameData.currentSubPhase ??
    turnData.currentSubPhase ??
    state?.currentSubPhase;

  if (!major || !sub) {
    return false;
  }

  return (
    state?.currentPhase !== major ||
    state?.currentSubPhase !== sub ||
    gameData.currentPhase !== major ||
    gameData.currentSubPhase !== sub ||
    turnData.currentMajorPhase !== major ||
    turnData.currentSubPhase !== sub
  );
}

type PreparedGameStateRead =
  | {
      ok: true;
      maintainedState: any;
      nowMs: number;
      terminalOccurred: boolean;
      requestingPlayerId: string;
      participant: any;
    }
  | {
      ok: false;
      error: 'not_found' | 'forbidden';
    };

export function registerGameRoutes(
  app: Hono,
  kvGet: (key: string) => Promise<any>,
  kvSet: (key: string, value: any) => Promise<void>,
  requireSession: (c: any) => Promise<any>,
  generateGameId: () => string
) {
  async function prepareGameStateRead(
    gameId: string,
    requestingPlayerId: string,
  ): Promise<PreparedGameStateRead> {
    const storedState = await kvGet(`game_${gameId}`);

    if (!storedState) {
      return { ok: false, error: 'not_found' };
    }

    const nowMs = Date.now();
    const prevStatus = storedState?.status;
    let maintainedState = applyGameStateMaintenance(
      ensureStateRevision(storedState),
      nowMs,
    );
    const nextStatus = maintainedState?.status;
    const terminalOccurred = prevStatus !== 'finished' && nextStatus === 'finished';

    if (terminalOccurred) {
      maintainedState = withBumpedStateRevision(maintainedState);
      await kvSet(`game_${gameId}`, maintainedState);
    }

    const participant = maintainedState?.players?.find(
      (player: any) => player?.id === requestingPlayerId,
    );
    if (!participant) {
      return { ok: false, error: 'forbidden' };
    }

    return {
      ok: true,
      maintainedState,
      nowMs,
      terminalOccurred,
      requestingPlayerId,
      participant,
    };
  }
  
  // ============================================================================
  // CREATE GAME
  // ============================================================================
  // Lines 1439-1525 from index.tsx
  app.post("/make-server-825e19ab/create-game", async (c) => {
    try {
      // Validate session token and get server-side identity
      const session = await requireSession(c);
      if (session instanceof Response) return session; // Return 401 if validation failed

      const requestBody = await c.req.json() as CreateGameRequestBody;
      
      // Note: Client may send playerId for backward compat, but it's IGNORED
      // Server-side identity is derived from sessionToken only
      const playerId = session.sessionId; // AUTHORITY: Server-minted identity
      const playerName =
        typeof requestBody?.playerName === 'string'
          ? requestBody.playerName.trim()
          : '';
      
      if (!playerName) {
        return c.json({ error: "Player name is required" }, 400);
      }

      let timeControl: TimeControlConfig | null;
      try {
        timeControl = resolveCreateGameTimeControl(requestBody);
      } catch (error) {
        const message = error instanceof Error ? error.message : 'Invalid create-game settings';
        return c.json({ error: message }, 400);
      }

      debugLog(`Creating game - Session: ${session.sessionId}, Display name: ${playerName}`);

      const gameId = generateGameId();
      const gameData = ensureStateRevision(
        createFreshGameData(gameId, playerId, playerName, timeControl),
      );

      await kvSet(`game_${gameId}`, gameData);
      await kvSet(
        getBattleLogHistoryKey(gameId),
        createEmptyBattleLogHistoryStore(gameId),
      );
      
      debugLog("Game created:", gameId);
      return c.json({ gameId, message: "Game created successfully" });

    } catch (error) {
      console.error("Create game error:", error);
      return c.json({ error: "Internal server error" }, 500);
    }
  });

  app.post("/make-server-825e19ab/create-computer-game", async (c) => {
    try {
      const session = await requireSession(c);
      if (session instanceof Response) return session;

      const requestBody = await c.req.json() as CreateComputerGameRequestBody;
      const playerId = session.sessionId;
      const playerName =
        typeof requestBody?.playerName === 'string'
          ? requestBody.playerName.trim()
          : '';

      if (!playerName) {
        return c.json({ error: "Player name is required" }, 400);
      }

      let timeControl: TimeControlConfig | null;
      try {
        timeControl = resolveCreateGameTimeControl(requestBody);
      } catch (error) {
        const message = error instanceof Error ? error.message : 'Invalid create-computer-game settings';
        return c.json({ error: message }, 400);
      }

      const requestedPlanId = requestBody?.planId;
      const gameId = generateGameId();

      let chosenPlanId: string;
      if (typeof requestedPlanId !== 'undefined') {
        if (typeof requestedPlanId !== 'string' || !getHumanBotPlanById(requestedPlanId)) {
          return c.json({ error: "Invalid planId" }, 400);
        }

        chosenPlanId = requestedPlanId;
      } else {
        chosenPlanId = chooseDeterministicHumanBotPlanId(gameId);
      }

      const gameData = createFreshComputerGameData(
        gameId,
        playerId,
        playerName,
        chosenPlanId,
        timeControl,
      );
      const botRunResult = await runBotsUntilSettled({
        state: gameData,
        nowMs: Date.now(),
      });

      await kvSet(`game_${gameId}`, ensureStateRevision(botRunResult.state));
      await kvSet(
        getBattleLogHistoryKey(gameId),
        createEmptyBattleLogHistoryStore(gameId),
      );

      debugLog("Computer game created:", gameId, {
        chosenPlanId,
        botStepsApplied: botRunResult.botStepsApplied,
      });
      return c.json({
        gameId,
        message: "Computer game created successfully",
        chosenBotPlanId: chosenPlanId,
      });
    } catch (error) {
      console.error("Create computer game error:", error);
      return c.json({ error: "Internal server error" }, 500);
    }
  });

  app.post("/make-server-825e19ab/new-game-from/:gameId", async (c) => {
    try {
      const session = await requireSession(c);
      if (session instanceof Response) return session;

      const sourceGameId = c.req.param('gameId');
      const sourceGame = await kvGet(`game_${sourceGameId}`);

      if (!sourceGame) {
        return c.json({ error: "Game not found" }, 404);
      }

      const playerId = session.sessionId;
      const sourcePlayer = sourceGame.players.find((player: any) => player?.id === playerId);

      if (!sourcePlayer || sourcePlayer.role !== 'player') {
        return c.json({ error: "Only players from this finished game can create a new game" }, 403);
      }

      const playerName =
        typeof sourcePlayer.name === 'string'
          ? sourcePlayer.name.trim()
          : '';

      if (!playerName) {
        return c.json({ error: "Player name is required" }, 400);
      }

      if (sourceGame.status !== 'finished') {
        return c.json({ error: "New game can only be created from a finished game" }, 400);
      }

      const newGameId = generateGameId();
      const inheritedTimeControl = sourceGame?.gameData?.clock?.timeControl ?? null;
      const opponentPlayer = sourceGame.players.find((player: any) =>
        player?.role === 'player' && player?.id !== playerId
      );
      const opponentController = opponentPlayer?.id
        ? sourceGame.controllersByPlayerId?.[opponentPlayer.id]
        : null;
      const isBotRematch = opponentController?.kind === 'bot';

      if (isBotRematch) {
        const chosenPlanId = chooseFreshHumanBotPlanId(opponentController?.chosenPlanId);
        const newGameData = createFreshComputerGameData(
          newGameId,
          playerId,
          playerName,
          chosenPlanId,
          inheritedTimeControl,
        );
        const botRunResult = await runBotsUntilSettled({
          state: newGameData,
          nowMs: Date.now(),
        });

        await kvSet(`game_${newGameId}`, ensureStateRevision(botRunResult.state));
        await kvSet(
          getBattleLogHistoryKey(newGameId),
          createEmptyBattleLogHistoryStore(newGameId),
        );

        debugLog("Computer rematch created from finished bot game:", {
          sourceGameId,
          newGameId,
          playerId,
          opponentPlayerId: opponentPlayer?.id ?? null,
          chosenPlanId,
          botStepsApplied: botRunResult.botStepsApplied,
        });

        return c.json({ gameId: newGameId });
      }

      const newGameData = ensureStateRevision(
        createFreshGameData(
          newGameId,
          playerId,
          playerName,
          inheritedTimeControl,
        ),
      );

      await kvSet(`game_${newGameId}`, newGameData);
      await kvSet(
        getBattleLogHistoryKey(newGameId),
        createEmptyBattleLogHistoryStore(newGameId),
      );

      try {
        await appendChatEntry(
          sourceGameId,
          {
            type: 'rematch_invite',
            playerId,
            playerName,
            content: `${playerName} wants to play again`,
            newGameId,
            timestamp: Date.now(),
          },
          kvGet,
          kvSet,
        );
      } catch (error) {
        console.warn("Failed to append rematch invite to source game chat:", {
          sourceGameId,
          newGameId,
          playerId,
          error,
        });
      }

      debugLog("New game created from finished game:", {
        sourceGameId,
        newGameId,
        playerId,
      });

      return c.json({ gameId: newGameId });
    } catch (error) {
      console.error("New game from finished game error:", error);
      return c.json({ error: "Internal server error" }, 500);
    }
  });

  // ============================================================================
  // JOIN GAME
  // ============================================================================
  // Lines 1530-1622 from index.tsx
  app.post("/make-server-825e19ab/join-game/:gameId", async (c) => {
    try {
      // Validate session token and get server-side identity
      const session = await requireSession(c);
      if (session instanceof Response) return session; // Return 401 if validation failed

      const gameId = c.req.param('gameId');
      const { playerName } = await c.req.json();
      
      // Note: Client may send playerId for backward compat, but it's IGNORED
      // Server-side identity is derived from sessionToken only
      const playerId = session.sessionId; // AUTHORITY: Server-minted identity
      
      if (!playerName) {
        return c.json({ error: "Player name is required" }, 400);
      }

      debugLog(`Joining game ${gameId} - Session: ${session.sessionId}, Display name: ${playerName}`);

      let gameData = await kvGet(`game_${gameId}`);
      if (!gameData) {
        return c.json({ error: "Game not found" }, 404);
      }
      gameData = ensureStateRevision(gameData);
      let didMutate = false;

      const existingPlayer = gameData.players.find((p: any) => p.id === playerId);

      // Determine final role:
      // - Existing participants keep their stored role on rejoin.
      // - New participants fill player seats only while fewer than two players exist.
      const finalRole =
        existingPlayer
          ? existingPlayer.role === 'player' ? 'player' : 'spectator'
          : gameData.players.filter((p: any) => p.role === 'player').length < 2
            ? 'player'
            : 'spectator';
      
      if (!existingPlayer) {
        const newPlayer = {
          id: playerId, // Server-derived from sessionToken
          name: playerName, // Client-provided metadata
          faction: null, // Species to be selected
          isReady: false,
          isActive: finalRole === 'player', // PART C: All players are active (no longer just first player)
          role: finalRole,
          joinedAt: new Date().toISOString(),
          health: 25,
          lines: finalRole === 'player' ? INITIAL_SAVED_LINES : 0,
          joiningLines: 0,
          energy: 0
        };

        gameData.players.push(newPlayer);
        didMutate = true;

        // Initialize ship collection for players only (not spectators)
        if (finalRole === 'player') {
          if (!gameData.gameData) gameData.gameData = { ships: {} };
          if (!gameData.gameData.ships) gameData.gameData.ships = {};
          gameData.gameData.ships[playerId] = [];
          
          // Ensure clock is initialized for this player using immutable helper
          if (gameData.gameData?.clock) {
            gameData.gameData.clock = ensurePlayerClock(gameData.gameData.clock, playerId);
          }
        }

        // Internal game action only; visible chat storage stays lazy.
        const joinMessage = `${playerName} joined as a ${finalRole}`;

        gameData.actions.push({
          playerId: "system",
          playerName: "System",
          actionType: "system",
          content: joinMessage,
          timestamp: new Date().toISOString()
        });

        // Start the game if we have 2 active players
        const newActivePlayerCount = gameData.players.filter((p: any) => p.role === 'player').length;
        if (newActivePlayerCount >= 2 && gameData.status === 'waiting') {
          gameData.status = 'active';
          gameData.actions.push({
            playerId: "system",
            playerName: "System",
            actionType: "system",
            content: "Game started! Players select species.",
            timestamp: new Date().toISOString()
          });
        }
        
        // PART C: Log activation
        debugLog("JOIN_GAME_ACTIVATED_PLAYER", {
          gameId,
          sessionId: playerId,
          role: finalRole,
          isActive: finalRole === 'player',
        });
      } else {
        // PART C: Rejoin - idempotently preserve existing player/spectator roles.
        
        // If finalRole is 'player', ensure the existing player is active
        if (finalRole === 'player') {
          // Always set isActive=true for players (idempotent)
          if (existingPlayer.isActive !== true) {
            existingPlayer.isActive = true;
            didMutate = true;
          }

          if (!gameData.gameData) {
            gameData.gameData = { ships: {} };
            didMutate = true;
          }
          if (!gameData.gameData.ships) {
            gameData.gameData.ships = {};
            didMutate = true;
          }
          if (!Array.isArray(gameData.gameData.ships[playerId])) {
            gameData.gameData.ships[playerId] = [];
            didMutate = true;
          }
          if (gameData.gameData?.clock) {
            const nextClock = ensurePlayerClock(gameData.gameData.clock, playerId);
            if (nextClock !== gameData.gameData.clock) {
              gameData.gameData.clock = nextClock;
              didMutate = true;
            }
          }
          
          debugLog("JOIN_GAME_REACTIVATED_PLAYER", {
            gameId,
            sessionId: playerId,
            role: existingPlayer.role,
            isActive: true,
          });
        } else {
          // finalRole is 'spectator' - ensure isActive is false
          if (existingPlayer.isActive !== false) {
            existingPlayer.isActive = false;
            didMutate = true;
          }
        }
      }

      // Normalize phase fields before saving
      if (doesStateNeedPhaseSync(gameData)) {
        didMutate = true;
      }
      gameData = syncPhaseFields(gameData);

      if (didMutate) {
        gameData = withBumpedStateRevision(gameData);
        await kvSet(`game_${gameId}`, gameData);
      }
      
      debugLog("Player joined game:", gameId, playerName);
      return c.json({ message: "Joined game successfully", gameData });

    } catch (error) {
      console.error("Join game error:", error);
      return c.json({ error: "Internal server error" }, 500);
    }
  });

  // ============================================================================
  // SWITCH ROLE
  // ============================================================================
  // Lines 1627-1731 from index.tsx
  app.post("/make-server-825e19ab/switch-role/:gameId", async (c) => {
    try {
      // Validate session token and get server-side identity
      const session = await requireSession(c);
      if (session instanceof Response) return session; // Return 401 if validation failed

      const gameId = c.req.param('gameId');
      const { newRole } = await c.req.json();
      
      // Note: Client may send playerId for backward compat, but it's IGNORED
      // Server-side identity is derived from sessionToken only
      const playerId = session.sessionId; // AUTHORITY: Server-minted identity
      
      if (!newRole) {
        return c.json({ error: "New role is required" }, 400);
      }

      if (!['player', 'spectator'].includes(newRole)) {
        return c.json({ error: "Role must be 'player' or 'spectator'" }, 400);
      }

      debugLog(`Role switch from session ${session.sessionId}: ${newRole} in game ${gameId}`);

      let gameData = await kvGet(`game_${gameId}`);
      if (!gameData) {
        return c.json({ error: "Game not found" }, 404);
      }
      gameData = ensureStateRevision(gameData);
      let didMutate = false;

      const player = gameData.players.find((p: any) => p.id === playerId);
      if (!player) {
        return c.json({ error: "Player not in game (session not recognized)" }, 403);
      }

      // Check if switching to player but game already has 2 players
      const activePlayers = gameData.players.filter((p: any) => p.role === 'player');
      if (newRole === 'player' && activePlayers.length >= 2 && player.role !== 'player') {
        return c.json({ error: "Game already has 2 active players" }, 400);
      }

      const oldRole = player.role;
      const isPromotingToPlayer = oldRole !== 'player' && newRole === 'player';
      
      // Find player index to update the player properly
      const playerIndex = gameData.players.findIndex((p: any) => p.id === playerId);
      if (playerIndex === -1) {
        return c.json({ error: "Player not found in game" }, 404);
      }
      
      // Update player resources based on new role - immutable update
      if (newRole === 'player') {
        // Initialize ship collection if needed
        if (!gameData.gameData) {
          gameData.gameData = { ships: {} };
          didMutate = true;
        }
        if (!gameData.gameData.ships) {
          gameData.gameData.ships = {};
          didMutate = true;
        }
        if (!gameData.gameData.ships[playerId]) {
          gameData.gameData.ships[playerId] = [];
          didMutate = true;
        }
        if (gameData.gameData?.clock) {
          const nextClock = ensurePlayerClock(gameData.gameData.clock, playerId);
          if (nextClock !== gameData.gameData.clock) {
            gameData.gameData.clock = nextClock;
            didMutate = true;
          }
        }

        const nextPlayers = gameData.players.map((p: any, idx: number) => {
          if (idx !== playerIndex) {
            return p;
          }

          const nextPlayer = {
            ...p,
            role: newRole,
            lines: isPromotingToPlayer ? (p.lines || INITIAL_SAVED_LINES) : p.lines,
            health: 25,
          };

          if (
            nextPlayer.role !== p.role ||
            nextPlayer.lines !== p.lines ||
            nextPlayer.health !== p.health
          ) {
            didMutate = true;
          }

          return nextPlayer;
        });

        gameData = {
          ...gameData,
          players: nextPlayers,
        };
      } else {
        // Switching to spectator - keep current resources but don't give new ones
        const nextPlayers = gameData.players.map((p: any, idx: number) => {
          if (idx !== playerIndex) {
            return p;
          }

          const nextPlayer = {
            ...p,
            role: newRole,
            isReady: false,
          };

          if (
            nextPlayer.role !== p.role ||
            nextPlayer.isReady !== p.isReady
          ) {
            didMutate = true;
          }

          return nextPlayer;
        });

        gameData = {
          ...gameData,
          players: nextPlayers,
        };
      }

      if (oldRole !== newRole) {
        const updatedPlayer = gameData.players[playerIndex];
        gameData.actions.push({
          playerId: "system",
          playerName: "System",
          actionType: "system",
          content: `${updatedPlayer.name} switched from ${oldRole} to ${newRole}`,
          timestamp: new Date().toISOString()
        });
        didMutate = true;
      }

      // Normalize phase fields before saving
      if (doesStateNeedPhaseSync(gameData)) {
        didMutate = true;
      }
      gameData = syncPhaseFields(gameData);

      if (didMutate) {
        gameData = withBumpedStateRevision(gameData);
        await kvSet(`game_${gameId}`, gameData);
      }
      
      debugLog("Player switched role:", gameId, player.name, oldRole, "->", newRole);
      return c.json({ message: "Role switched successfully", gameData });

    } catch (error) {
      console.error("Switch role error:", error);
      return c.json({ error: "Internal server error" }, 500);
    }
  });

  // ============================================================================
  // GET GAME STATE
  // ============================================================================
  // Lines 1736-1856 from index.tsx
  app.get("/make-server-825e19ab/game-state/:gameId", async (c) => {
    try {
      // Validate session token and get server-side identity
      const session = await requireSession(c);
      if (session instanceof Response) return session; // Return 401 if validation failed

      const gameId = c.req.param('gameId');
      
      // Note: Client may send playerId query for backward compat, but it's IGNORED
      // Server-side identity is derived from sessionToken only
      const requestingPlayerId = session.sessionId; // AUTHORITY: Server-minted identity

      const preparedRead = await prepareGameStateRead(gameId, requestingPlayerId);
      if (!preparedRead.ok) {
        if (preparedRead.error === 'not_found') {
          return c.json({ error: "Game not found" }, 404);
        }
        return c.json({ error: "Not authorized to view this game" }, 403);
      }

      const { maintainedState, nowMs, participant } = preparedRead;
      let gameData = maintainedState;

      const phaseKey = getPhaseKey(gameData);
      const sub = gameData.gameData.currentSubPhase;
      const phaseReadiness = gameData.gameData?.phaseReadiness || [];
      const inSpeciesSelection = phaseKey === 'setup.species_selection';

      gameData.players = gameData.players.map((player: any) => {
        const readiness = phaseReadiness.find((r: any) => r.playerId === player.id);

        // Support both new (major:sub) and older (sub only)
        const readyMatch =
          readiness?.currentStep === phaseKey ||
          readiness?.currentStep === sub;

        return {
          ...player,
          isReady: inSpeciesSelection
            ? false
            : Boolean(readiness?.isReady && readyMatch)
        };
      });

      // SECURITY: Filter pending declarations to only show requesting player's own pending data
      if (requestingPlayerId && gameData.gameData?.turnData) {
        const turnData = gameData.gameData.turnData;
        
        // Filter pending charge declarations
        if (turnData.pendingChargeDeclarations) {
          const filteredChargeDeclarations: Record<string, any[]> = {};
          // Only include requesting player's pending declarations
          if (turnData.pendingChargeDeclarations[requestingPlayerId]) {
            filteredChargeDeclarations[requestingPlayerId] = turnData.pendingChargeDeclarations[requestingPlayerId];
          }
          // For opponent, just show that they have pending declarations (count only)
          for (const playerId in turnData.pendingChargeDeclarations) {
            if (playerId !== requestingPlayerId) {
              filteredChargeDeclarations[playerId] = []; // Don't reveal opponent's declarations
            }
          }
          
          gameData = {
            ...gameData,
            gameData: {
              ...gameData.gameData,
              turnData: {
                ...turnData,
                pendingChargeDeclarations: filteredChargeDeclarations
              }
            }
          };
        }
        
        // Filter pending solar power declarations
        if (turnData.pendingSOLARPowerDeclarations) {
          const filteredSolarDeclarations: Record<string, any[]> = {};
          // Only include requesting player's pending declarations
          if (turnData.pendingSOLARPowerDeclarations[requestingPlayerId]) {
            filteredSolarDeclarations[requestingPlayerId] = turnData.pendingSOLARPowerDeclarations[requestingPlayerId];
          }
          // For opponent, just show that they have pending declarations (count only)
          for (const playerId in turnData.pendingSOLARPowerDeclarations) {
            if (playerId !== requestingPlayerId) {
              filteredSolarDeclarations[playerId] = []; // Don't reveal opponent's declarations
            }
          }
          
          gameData = {
            ...gameData,
            gameData: {
              ...gameData.gameData,
              turnData: {
                ...gameData.gameData.turnData,
                pendingSOLARPowerDeclarations: filteredSolarDeclarations
              }
            }
          };
        }
        
        // Filter pending first strike selections
        if (turnData.pendingFirstStrikeSelectionsByPlayerId) {
          const filteredSelections: Record<string, any> = {};
          if (turnData.pendingFirstStrikeSelectionsByPlayerId[requestingPlayerId]) {
            filteredSelections[requestingPlayerId] = turnData.pendingFirstStrikeSelectionsByPlayerId[requestingPlayerId];
          }

          gameData = {
            ...gameData,
            gameData: {
              ...gameData.gameData,
              turnData: {
                ...turnData,
                pendingFirstStrikeSelectionsByPlayerId: filteredSelections
              }
            }
          };
        }

        // Filter commit/reveal data (new commit/reveal protocol)
        if (turnData.commitments) {
          const filteredCommitments: any = {};
          
          // For each commitment key (e.g., SPECIES_1, BUILD_2, etc.)
          for (const commitKey in turnData.commitments) {
            const keyRecords = turnData.commitments[commitKey];
            filteredCommitments[commitKey] = {};
            
            // For each player in this commitment key
            for (const playerId in keyRecords) {
              const record = keyRecords[playerId];
              
              if (playerId === requestingPlayerId) {
                // Show requesting player's own commit/reveal data
                filteredCommitments[commitKey][playerId] = record;
              } else {
                // For opponent: hide reveal payload and nonce, but show status booleans
                filteredCommitments[commitKey][playerId] = {
                  hasCommitted: record.commitHash !== undefined,
                  hasRevealed: record.revealPayload !== undefined,
                  committedAt: record.committedAt,
                  revealedAt: record.revealedAt
                  // Do NOT include: commitHash, revealPayload, nonce
                };
              }
            }
          }
          
          gameData = {
            ...gameData,
            gameData: {
              ...gameData.gameData,
              turnData: {
                ...gameData.gameData.turnData,
                commitments: filteredCommitments
              }
            }
          };
        }
      }

      gameData = projectChronoswarmTurnData(gameData, requestingPlayerId);

      // Expose clock snapshot to client (STEP F)
      const clockData = gameData.gameData?.clock;
      const clockSnapshot = clockData ? {
        remainingMsByPlayerId: clockData.remainingMsByPlayerId,
        timeControl: clockData.timeControl,
        clocksAreLive: clocksAreLive(gameData),
        serverNowMs: nowMs,
      } : null;
      
      // Compute projected build-phase line bonuses for all players
      const bonusLinesByPlayerId: Record<string, number> = {};
      const bonusLinesOnEvenByPlayerId: Record<string, number> = {};
      const savedLinesByPlayerId: Record<string, number> = {};
      const joiningLinesByPlayerId: Record<string, number> = {};
      const joiningBonusLinesByPlayerId: Record<string, number> = {};
      const bonusBreakdownByPlayerId: Record<string, Array<{
        rowKind: 'ship' | 'adjustment';
        label: string;
        count?: number;
        amount: number;
        amountText: string;
      }>> = {};
      const buildEconomyByPlayerId: Record<string, {
        ordinaryLinesAvailable: number;
        joiningLinesAvailable: number;
        baseRollLines: number;
        ordinaryBonusLines: number;
        ordinaryBonusLinesOnEven: number;
        joiningBonusLines: number;
        chronoswarmBonusLines: number;
        linesDistributed: boolean;
      }> = {};
      const turnData = gameData.gameData?.turnData || {};
      const canonicalBaseRollLines =
        turnData.effectiveDiceRoll ??
        turnData.baseDiceRoll ??
        turnData.diceRoll;
      const chronoswarmRolls = Array.isArray(turnData.chronoswarmRolls)
        ? turnData.chronoswarmRolls.filter((roll: unknown): roll is number => typeof roll === 'number')
        : [];
      const playersInGame = gameData.players || [];
      for (const player of playersInGame) {
        if (player.role === 'player') {
          const publicSavedResources = getPublicSavedResourcesForPlayer(gameData, phaseKey, player.id);
          const ordinaryLinesAvailable = player.lines ?? 0;
          const joiningLinesAvailable = player.joiningLines ?? 0;
          const baseRollLines = turnData.effectiveDiceRollByPlayerId?.[player.id] ?? canonicalBaseRollLines ?? 0;
          const chronoswarmCountRaw = turnData.chronoswarmCountByPlayerId?.[player.id];
          const chronoswarmCount =
            Number.isInteger(chronoswarmCountRaw) && chronoswarmCountRaw > 0
              ? Math.min(chronoswarmCountRaw, chronoswarmRolls.length)
              : 0;
          let chronoswarmBonusLines = 0;
          for (let i = 0; i < chronoswarmCount; i++) {
            chronoswarmBonusLines += chronoswarmRolls[i] ?? 0;
          }

          savedLinesByPlayerId[player.id] = publicSavedResources.savedLines;
          joiningLinesByPlayerId[player.id] = publicSavedResources.savedJoiningLines;
          try {
            const lineBonuses = computeLineBonusesForPlayer(gameData.gameData, player.id);
            const playerSpecies = String((player as any)?.faction ?? (player as any)?.species ?? '')
              .trim()
              .toLowerCase();
            const displayedBonusRows =
              playerSpecies === 'centaur'
                ? [...lineBonuses.evenOnlyRows]
                : [...lineBonuses.ordinaryRows, ...lineBonuses.evenOnlyRows];
            bonusLinesByPlayerId[player.id] = lineBonuses.bonusLines;
            bonusLinesOnEvenByPlayerId[player.id] = lineBonuses.bonusLinesOnEven;
            joiningBonusLinesByPlayerId[player.id] = lineBonuses.joiningBonusLines;
            bonusBreakdownByPlayerId[player.id] = [...displayedBonusRows, ...lineBonuses.joiningRows].sort((a, b) => {
              if (b.amount !== a.amount) return b.amount - a.amount;
              return a.label.localeCompare(b.label);
            });
            buildEconomyByPlayerId[player.id] = {
              ordinaryLinesAvailable,
              joiningLinesAvailable,
              baseRollLines,
              ordinaryBonusLines: lineBonuses.bonusLines,
              ordinaryBonusLinesOnEven: lineBonuses.bonusLinesOnEven,
              joiningBonusLines: lineBonuses.joiningBonusLines,
              chronoswarmBonusLines,
              linesDistributed: turnData.linesDistributed === true,
            };
          } catch (err) {
            console.error(`[GET game-state] Failed to compute bonus lines for ${player.id}:`, err);
            bonusLinesByPlayerId[player.id] = 0; // Default to 0 on error
            bonusLinesOnEvenByPlayerId[player.id] = 0;
            joiningBonusLinesByPlayerId[player.id] = 0;
            bonusBreakdownByPlayerId[player.id] = [];
            buildEconomyByPlayerId[player.id] = {
              ordinaryLinesAvailable,
              joiningLinesAvailable,
              baseRollLines,
              ordinaryBonusLines: 0,
              ordinaryBonusLinesOnEven: 0,
              joiningBonusLines: 0,
              chronoswarmBonusLines,
              linesDistributed: turnData.linesDistributed === true,
            };
          }
        }
      }
      
      // Compute available actions for requesting player
      const availableActions = computeAvailableActionsForRequestingPlayer(gameData, requestingPlayerId);
      const {
        ships: _omitShips,
        battleLogScratch: _omitBattleLogScratch,
        ...responseState
      } = gameData;
      const {
        shipActivationCueBatches: _omitShipActivationCueBatches,
        ...responseTurnData
      } = responseState.gameData?.turnData ?? {};
      const responseGameData = responseState.gameData
        ? {
            ...responseState.gameData,
            turnData: responseTurnData,
          }
        : responseState.gameData;
      const lastTurnDamageDealtBreakdownByPlayerId =
        gameData.gameData?.lastTurnDamageDealtBreakdownByPlayerId ?? {};
      const lastTurnHealingReceivedBreakdownByPlayerId =
        gameData.gameData?.lastTurnHealingReceivedBreakdownByPlayerId ?? {};
      const currentTurnNumber =
        turnData.turnNumber ??
        gameData.gameData?.turnNumber ??
        gameData.turnNumber ??
        0;
      const meta = {
        turnNumber: currentTurnNumber,
        phaseKey,
        subPhaseKey: sub ?? null,
      };
      const visibleDice = {
        diceRoll: turnData.diceRoll ?? gameData.gameData?.diceRoll ?? null,
        baseDiceRoll: turnData.baseDiceRoll ?? null,
        effectiveDiceRoll: turnData.effectiveDiceRoll ?? null,
        effectiveDiceRollByPlayerId: turnData.effectiveDiceRollByPlayerId ?? {},
        chronoswarmRolls: Array.isArray(turnData.chronoswarmRolls)
          ? turnData.chronoswarmRolls
          : [],
      };
      const publicState = {
        players: gameData.players ?? [],
        phaseReadiness,
        clock: clockSnapshot,
        ships: gameData.gameData?.ships ?? {},
        voidShipsByPlayerId: gameData.gameData?.voidShipsByPlayerId ?? {},
        visibleDice,
        lastTurnStats: {
          netByPlayerId: gameData.gameData?.lastTurnNetByPlayerId ?? {},
          damageByPlayerId: gameData.gameData?.lastTurnDamageByPlayerId ?? {},
          healByPlayerId: gameData.gameData?.lastTurnHealByPlayerId ?? {},
        },
        controllersByPlayerId: gameData.controllersByPlayerId ?? gameData.gameData?.controllersByPlayerId ?? {},
        savedLinesByPlayerId,
        joiningLinesByPlayerId,
        bonusLinesByPlayerId,
        bonusLinesOnEvenByPlayerId,
        joiningBonusLinesByPlayerId,
        bonusBreakdownByPlayerId,
        presentationEvents: {
          shipActivationCueBatches: projectShipActivationCueBatches(
            turnData.shipActivationCueBatches,
            phaseKey,
            gameData.status
          ),
        },
      };
      const requester = {
        playerId: requestingPlayerId,
        availableActions,
        buildEconomy: buildEconomyByPlayerId[requestingPlayerId] ?? null,
        buildEconomyByPlayerId,
        lastTurnDamageDealtBreakdownByPlayerId,
        lastTurnHealingReceivedBreakdownByPlayerId,
        presentationEvents: {
          shipActivationCueBatches: projectRequesterShipActivationCueBatches(
            turnData.shipActivationCueBatches,
            phaseKey,
            gameData.status,
            currentTurnNumber,
            requestingPlayerId,
            participant?.role
          ),
        },
      };
      const result = {
        winnerPlayerId: gameData.winnerPlayerId ?? null,
        resultReason: gameData.resultReason ?? null,
      };
      
      return c.json({
        ...responseState,
        gameData: responseGameData,
        stateRevision: gameData.stateRevision,
        clock: clockSnapshot,
        meta,
        publicState,
        requester,
        result,
      });

    } catch (error) {
      console.error("Get game state error:", error);
      return c.json({ error: "Internal server error" }, 500);
    }
  });

  app.get("/make-server-825e19ab/game-state-head/:gameId", async (c) => {
    try {
      const session = await requireSession(c);
      if (session instanceof Response) return session;

      const gameId = c.req.param('gameId');
      const requestingPlayerId = session.sessionId;
      const preparedRead = await prepareGameStateRead(gameId, requestingPlayerId);

      if (!preparedRead.ok) {
        if (preparedRead.error === 'not_found') {
          return c.json({ error: "Game not found" }, 404);
        }
        return c.json({ error: "Not authorized to view this game" }, 403);
      }

      const { maintainedState, nowMs } = preparedRead;
      const phaseKey = getPhaseKey(maintainedState) ?? 'unknown';
      const clockData = maintainedState?.gameData?.clock;

      return c.json({
        gameId: maintainedState?.gameId ?? gameId,
        stateRevision: maintainedState.stateRevision,
        status: maintainedState?.status ?? 'unknown',
        turnNumber: maintainedState?.gameData?.turnNumber ?? maintainedState?.turnNumber ?? 0,
        phaseKey,
        clock: clockData
          ? {
              remainingMsByPlayerId: clockData.remainingMsByPlayerId ?? {},
              clocksAreLive: clocksAreLive(maintainedState),
              serverNowMs: nowMs,
            }
          : null,
      });
    } catch (error) {
      console.error("Get game state head error:", error);
      return c.json({ error: "Internal server error" }, 500);
    }
  });

  app.get("/make-server-825e19ab/game-history/:gameId", async (c) => {
    try {
      const session = await requireSession(c);
      if (session instanceof Response) return session;

      const gameId = c.req.param('gameId');
      const requestingPlayerId = session.sessionId;
      const gameData = await kvGet(`game_${gameId}`);

      if (!gameData) {
        return c.json({ error: "Game not found" }, 404);
      }

      const participant = gameData.players.find((p: any) => p.id === requestingPlayerId);
      if (!participant) {
        return c.json({ error: "Not authorized to view this game" }, 403);
      }

      const rawHistory = await kvGet(getBattleLogHistoryKey(gameId));
      const historyStore = normalizeBattleLogHistoryStore(gameId, rawHistory);
      return c.json(toBattleLogHistoryResponse(historyStore));
    } catch (error) {
      console.error("Get game history error:", error);
      return c.json({ error: "Internal server error" }, 500);
    }
  });

  // ============================================================================
  // SEND ACTION
  // ============================================================================
  // ⚠️ LEGACY HARNESS ONLY - PlayerMode must NOT call this endpoint
  // Use /intent endpoint for commit/reveal protocol instead
  // This endpoint remains for development dashboard and testing
  // ============================================================================
  app.post("/make-server-825e19ab/send-action/:gameId", async (c) => {
    try {
      // Validate session token and get server-side identity
      const session = await requireSession(c);
      if (session instanceof Response) return session; // Return 401 if validation failed

      const gameId = c.req.param('gameId');
      const requestBody = await c.req.json();
      
      // Note: Client may send playerId for backward compat, but it's IGNORED
      // Server-side identity is derived from sessionToken only
      const playerId = session.sessionId; // AUTHORITY: Server-minted identity
      
      const actionType = requestBody.actionType;
      const content = requestBody.content;
      const timestamp = requestBody.timestamp;
      
      if (!actionType) {
        return c.json({ error: "Action type is required" }, 400);
      }

      debugLog(`Action from session ${session.sessionId}: ${actionType} in game ${gameId}`);

      let gameData = await kvGet(`game_${gameId}`);
      if (!gameData) {
        return c.json({ error: "Game not found" }, 404);
      }

      const player = gameData.players.find((p: any) => p.id === playerId);
      if (!player) {
        return c.json({ error: "Player not in game (session not recognized)" }, 403);
      }

      // Store player information that we'll need later (to avoid const reference issues)
      const originalPlayerName = player.name;
      const originalPlayerRole = player.role;

      // Restrict spectator actions (they can only send messages or select species if slots available)
      if (originalPlayerRole === 'spectator' && actionType !== 'message' && actionType !== 'select_species') {
        return c.json({ error: "Spectators can only send messages and select species (if slots available)" }, 403);
      }

      // Simple action validation - allowlist of known actions
      const ALLOWED_ACTIONS = new Set([
        'select_species',
        'set_ready',
        'build_ship',
        'save_lines',
        'phase_action',
        'roll_dice',
        'advance_phase',
        'message',
        'declare_charge',
        'use_solar_power',
        'pass'
      ]);

      if (!ALLOWED_ACTIONS.has(actionType)) {
        return c.json({ error: `Unknown actionType '${actionType}'` }, 400);
      }

      // Handle different action types
      let responseMessage = "Action processed successfully";
      let logContent = content;
      
      debugLog("Processing action:", { 
        actionType, 
        playerId, 
        playerName: originalPlayerName, 
        playerRole: originalPlayerRole, 
        currentPhase: gameData.gameData?.turnData?.currentMajorPhase,
        currentStep: gameData.gameData?.turnData?.currentStep,
        content: content
      });

      try {
        switch (actionType) {
        case 'select_species':
          debugLog("Processing select_species action:", { playerId, content, playerRole: originalPlayerRole });
          
          // Validate species content
          if (!content || !content.species) {
            console.error("Invalid species selection - missing content.species:", content);
            return c.json({ error: "Species selection requires valid species name" }, 400);
          }
          
          const selectedSpecies = content.species;
          const validSpecies = ['human', 'xenite', 'centaur', 'ancient'];
          
          if (!validSpecies.includes(selectedSpecies)) {
            console.error("Invalid species selected:", selectedSpecies);
            return c.json({ error: `Invalid species. Must be one of: ${validSpecies.join(', ')}` }, 400);
          }
          
          // Find player index once for all updates  
          let playerIndex = gameData.players.findIndex((p: any) => p.id === playerId);
          
          // Handle spectator promotion to player
          if (originalPlayerRole === 'spectator') {
            const activePlayers = gameData.players.filter((p: any) => p.role === 'player');
            debugLog("Spectator trying to select species:", { activePlayerCount: activePlayers.length });
            
            if (activePlayers.length < 2) {
              // Promote spectator to player - update properly without mutating const reference
              if (playerIndex !== -1) {
                gameData.players[playerIndex] = {
                  ...gameData.players[playerIndex],
                  role: 'player',
                  health: 25,
                  lines: INITIAL_SAVED_LINES,
                  isActive: activePlayers.length === 0 // First promoted becomes active
                };
              }
              
              // Initialize ship collection
              if (!gameData.gameData) {
                debugLog("Initializing gameData object");
                gameData.gameData = { ships: {} };
              }
              if (!gameData.gameData.ships) {
                debugLog("Initializing ships object");
                gameData.gameData.ships = {};
              }
              gameData.gameData.ships[playerId] = [];
              
              // Ensure clock is initialized for this player using immutable helper
              if (gameData.gameData?.clock) {
                gameData.gameData.clock = ensurePlayerClock(gameData.gameData.clock, playerId);
              }
              
              debugLog("Promoted spectator to player:", playerId);
              
              gameData.actions.push({
                playerId: "system",
                playerName: "System",
                actionType: "system",
                content: `${originalPlayerName} became an active player by selecting ${selectedSpecies}`,
                timestamp: new Date().toISOString()
              });
              
              // Refresh playerIndex after promotion since array was modified
              playerIndex = gameData.players.findIndex((p: any) => p.id === playerId);
            } else {
              console.error("Cannot promote spectator - game full:", activePlayers.length);
              return c.json({ error: "Cannot select species as spectator - game already has 2 active players" }, 400);
            }
          }
          
          // Set species for players (including newly promoted ones)
          // Get current player status after potential promotion
          if (playerIndex !== -1) {
            const currentPlayer = gameData.players[playerIndex];
            if (currentPlayer && currentPlayer.role === 'player') {
              debugLog("Setting faction for player:", { playerId, selectedSpecies });
              
              // Update the faction immutably by creating a new players array
              gameData = {
                ...gameData,
                players: gameData.players.map((p: any, idx: number) => 
                  idx === playerIndex ? { ...p, faction: selectedSpecies } : p
                )
              };
            
              logContent = `selected ${selectedSpecies} species`;
              responseMessage = `Species ${selectedSpecies} selected`;
              
              // Manual readiness update for setup phase
              if (gameData.gameData?.turnData?.currentMajorPhase === 'setup') {
                debugLog("Auto-setting player ready after species selection");
                // Ensure phaseReadiness array exists
                if (!gameData.gameData.phaseReadiness) {
                  gameData.gameData.phaseReadiness = [];
                }
                const phaseKey = getPhaseKey(gameData);
                // Upsert readiness entry
                const existingIndex = gameData.gameData.phaseReadiness.findIndex((r: any) => r.playerId === playerId);
                if (existingIndex !== -1) {
                  gameData.gameData.phaseReadiness[existingIndex] = {
                    playerId,
                    isReady: true,
                    currentStep: phaseKey
                  };
                } else {
                  gameData.gameData.phaseReadiness.push({
                    playerId,
                    isReady: true,
                    currentStep: phaseKey
                  });
                }
              }
            } else {
              console.error("Player role not valid for species selection:", currentPlayer?.role);
              return c.json({ error: "Only players can select species" }, 403);
            }
          } else {
            console.error("Player not found after species selection:", playerId);
            return c.json({ error: "Player not found" }, 404);
          }
          
          debugLog("Species selection completed successfully:", { playerId, selectedSpecies });
          break;

        case 'set_ready':
          // Only active players can set ready
          if (originalPlayerRole !== 'player') {
            return c.json({ error: "Only active players can set ready status" }, 403);
          }
          
          // Manual readiness update using stable phase key
          if (!gameData.gameData) gameData.gameData = {};
          if (!gameData.gameData.phaseReadiness) {
            gameData.gameData.phaseReadiness = [];
          }
          const phaseKey = getPhaseKey(gameData);
          // Upsert readiness entry
          const existingReadyIndex = gameData.gameData.phaseReadiness.findIndex((r: any) => r.playerId === playerId);
          if (existingReadyIndex !== -1) {
            gameData.gameData.phaseReadiness[existingReadyIndex] = {
              playerId,
              isReady: true,
              currentStep: phaseKey
            };
          } else {
            gameData.gameData.phaseReadiness.push({
              playerId,
              isReady: true,
              currentStep: phaseKey
            });
          }
          
          logContent = 'is ready to advance';
          responseMessage = 'Marked as ready';
          break;

        case 'build_ship':
          // Only players can build ships  
          if (originalPlayerRole !== 'player') {
            return c.json({ error: "Only active players can build ships" }, 403);
          }
          
          // Simple ship building logic - UI-agnostic placeholders
          const shipData = {
            id: `ship_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
            name: `Ship ${content.shipId}`,
            shipId: content.shipId,
            healthValue: 0,
            damageValue: 0,
            isDestroyed: false,
            ownerId: playerId
          };
          
          if (!gameData.gameData) gameData.gameData = { ships: {} };
          if (!gameData.gameData.ships) gameData.gameData.ships = {};
          if (!gameData.gameData.ships[playerId]) gameData.gameData.ships[playerId] = [];
          
          gameData.gameData.ships[playerId].push(shipData);
          
          // No cost deduction for now (UI-agnostic server)
          const lineCost = 0;
          
          logContent = `built ${shipData.name}`;
          responseMessage = `${shipData.name} built successfully`;
          break;

        case 'save_lines':
          // Only players can save lines during drawing phase
          if (originalPlayerRole !== 'player') {
            return c.json({ error: "Only active players can save lines" }, 403);
          }
          
          const amount = content.amount || 1;
          const savingPlayer = gameData.players.find((p: any) => p.id === playerId);
          if ((savingPlayer?.lines || 0) < amount) {
            return c.json({ error: "Not enough lines to save" }, 400);
          }
          
          // For now, just deduct lines without implementing saved lines storage - immutable update
          const savePlayerIndex = gameData.players.findIndex((p: any) => p.id === playerId);
          if (savePlayerIndex !== -1) {
            gameData = {
              ...gameData,
              players: gameData.players.map((p: any, idx: number) => 
                idx === savePlayerIndex 
                  ? { ...p, lines: Math.max(0, (p.lines || 0) - amount) }
                  : p
              )
            };
          }
          
          logContent = `saved ${amount} line${amount > 1 ? 's' : ''}`;
          responseMessage = `Saved ${amount} line${amount > 1 ? 's' : ''}`;
          break;

        case 'phase_action':
          // Only players can perform phase actions
          if (originalPlayerRole !== 'player') {
            return c.json({ error: "Only active players can perform phase actions" }, 403);
          }
          switch (content.action) {
            case 'roll_dice':
              // Simple dice roll simulation
              const diceRoll = rollD6();
              const rollPlayerIndex = gameData.players.findIndex((p: any) => p.id === playerId);
              if (rollPlayerIndex !== -1) {
                gameData = {
                  ...gameData,
                  players: gameData.players.map((p: any, idx: number) => 
                    idx === rollPlayerIndex 
                      ? { ...p, lines: (p.lines || 0) + diceRoll }
                      : p
                  )
                };
              }
              logContent = `rolled ${diceRoll} and gained ${diceRoll} lines`;
              responseMessage = `Rolled ${diceRoll}! Gained ${diceRoll} lines`;
              break;
            case 'advance_phase':
              return c.json({
                error: "Invalid action. Use actionType 'advance_phase' to advance the phase."
              }, 400);
            case 'pass_turn':
              return c.json({
                error: "Invalid action. Use actionType 'set_ready' or 'pass' instead."
              }, 400);
            case 'end_turn':
              return c.json({
                error: "Invalid action. Use actionType 'advance_phase' to end the turn."
              }, 400);
            default:
              logContent = `performed ${content.action}`;
          }
          break;

        case 'roll_dice':
          // Only players can roll dice
          if (originalPlayerRole !== 'player') {
            return c.json({ error: "Only active players can roll dice" }, 403);
          }
          
          // Simple dice roll for simplified game - shared by both players
          const diceRoll = rollD6();
          
          if (!gameData.gameData) gameData.gameData = {};
          gameData.gameData.diceRoll = diceRoll;
          
          // Give lines to ALL active players (dice roll is shared)
          gameData.players = gameData.players.map((player: any) => {
            if (player.role === 'player') {
              return {
                ...player,
                lines: (player.lines || 0) + diceRoll
              };
            }
            return player;
          });
          
          logContent = `rolled ${diceRoll} - all players gained ${diceRoll} lines`;
          responseMessage = `Rolled ${diceRoll}! All players gained ${diceRoll} lines`;
          break;

        case 'advance_phase':
          // Only players can advance phases
          if (originalPlayerRole !== 'player') {
            return c.json({ error: "Only active players can advance phases" }, 403);
          }
          
          // Use canonical phase engine for advancement
          const result = advancePhase(gameData);
          if (!result.ok) {
            debugLog(`Phase advance blocked: ${result.error}`);
            return c.json({ error: result.error }, 400);
          }
          
          // Update game state with advanced phase
          gameData = result.state;
          
          // Normalize phase fields after advancement
          gameData = syncPhaseFields(gameData);
          
          debugLog(`Phase advanced successfully: ${result.from} → ${result.to}`);
          
          logContent = `advanced phase from ${result.from} to ${result.to}`;
          responseMessage = 'Phase advanced';
          
          // Add action to log
          gameData.actions.push({
            playerId,
            playerName: originalPlayerName,
            actionType,
            content: logContent,
            timestamp: timestamp || new Date().toISOString()
          });
          
          // Save state before returning
          await kvSet(`game_${gameId}`, gameData);
          
          debugLog("Phase advanced and saved successfully:", actionType, "by", originalPlayerName);
          
          // Include debug info in response
          return c.json({ 
            message: responseMessage,
            debug: { from: result.from, to: result.to },
            gameState: gameData 
          });
          break;

        case 'message':
          logContent = content.content || content;
          responseMessage = "Message sent";
          break;

        case 'declare_charge':
          // Only players can declare charges
          if (originalPlayerRole !== 'player') {
            return c.json({ error: "Only active players can declare charges" }, 403);
          }
          
          // Initialize pending declarations if needed
          if (!gameData.gameData) gameData.gameData = {};
          if (!gameData.gameData.turnData) gameData.gameData.turnData = {};
          if (!gameData.gameData.turnData.pendingChargeDeclarations) {
            gameData.gameData.turnData.pendingChargeDeclarations = {};
          }
          
          // Check if player is already ready for current step (cannot modify after ready)
          const currentStepCharge = gameData.gameData?.turnData?.currentStep;
          const chargeReadiness = (gameData.gameData?.phaseReadiness || []).find((r: any) => r.playerId === playerId);
          if (chargeReadiness?.isReady && chargeReadiness?.currentStep === currentStepCharge) {
            return c.json({ error: "Cannot declare charges after marking ready" }, 400);
          }
          
          // Create charge declaration
          const chargeDeclaration = {
            playerId,
            shipId: content.shipId,
            powerIndex: content.powerIndex || 0,
            targetPlayerId: content.targetPlayerId,
            targetShipId: content.targetShipId,
            timestamp: new Date().toISOString()
          };
          
          // Add to player's pending declarations (hidden from opponent)
          if (!gameData.gameData.turnData.pendingChargeDeclarations[playerId]) {
            gameData.gameData.turnData.pendingChargeDeclarations[playerId] = [];
          }
          gameData.gameData.turnData.pendingChargeDeclarations[playerId].push(chargeDeclaration);
          
          logContent = `declared a charge (hidden)`;
          responseMessage = 'Charge declaration added (hidden from opponent)';
          break;

        case 'use_solar_power':
          // Only players can use solar powers
          if (originalPlayerRole !== 'player') {
            return c.json({ error: "Only active players can use solar powers" }, 403);
          }
          
          // Initialize pending declarations if needed
          if (!gameData.gameData) gameData.gameData = {};
          if (!gameData.gameData.turnData) gameData.gameData.turnData = {};
          if (!gameData.gameData.turnData.pendingSOLARPowerDeclarations) {
            gameData.gameData.turnData.pendingSOLARPowerDeclarations = {};
          }
          
          // Check if player is already ready for current step
          const currentStepSolar = gameData.gameData?.turnData?.currentStep;
          const solarReadiness = (gameData.gameData?.phaseReadiness || []).find((r: any) => r.playerId === playerId);
          if (solarReadiness?.isReady && solarReadiness?.currentStep === currentStepSolar) {
            return c.json({ error: "Cannot use solar powers after marking ready" }, 400);
          }
          
          // Create solar power declaration
          const solarDeclaration = {
            playerId,
            powerType: content.powerType || 'unknown',
            energyCost: content.energyCost || {},
            targetPlayerId: content.targetPlayerId,
            targetShipId: content.targetShipId,
            cubeRepeated: content.cubeRepeated || false,
            timestamp: new Date().toISOString()
          };
          
          // Add to player's pending declarations (hidden from opponent)
          if (!gameData.gameData.turnData.pendingSOLARPowerDeclarations[playerId]) {
            gameData.gameData.turnData.pendingSOLARPowerDeclarations[playerId] = [];
          }
          gameData.gameData.turnData.pendingSOLARPowerDeclarations[playerId].push(solarDeclaration);
          
          logContent = `used a solar power (hidden)`;
          responseMessage = 'Solar power declaration added (hidden from opponent)';
          break;

        case 'pass':
          // Only players can pass
          if (originalPlayerRole !== 'player') {
            return c.json({ error: "Only active players can pass" }, 403);
          }
          
          // Pass means no declarations - just mark ready
          logContent = 'passed without declaring';
          responseMessage = 'Passed - no declarations made';
          // This will trigger setPlayerReady via set_ready action or explicit ready button
          break;

        default:
          debugLog("Unhandled action type:", actionType);
          logContent = typeof content === 'string' ? content : JSON.stringify(content);
      }
      
      } catch (actionError) {
        const actionErrorMessage = actionError instanceof Error ? actionError.message : String(actionError);
        const actionErrorStack = actionError instanceof Error ? actionError.stack : undefined;
        console.error("Error processing action:", { actionType, error: actionErrorMessage, stack: actionErrorStack });
        return c.json({ error: `Failed to process ${actionType} action: ${actionErrorMessage}` }, 500);
      }

      // Add action to log (use stored player name to avoid const reference issues)
      gameData.actions.push({
        playerId,
        playerName: originalPlayerName,
        actionType,
        content: logContent,
        timestamp: timestamp || new Date().toISOString()
      });

      // Normalize phase fields before saving
      const normalizedGameData = syncPhaseFields(gameData);

      await kvSet(`game_${gameId}`, normalizedGameData);
      
      debugLog("Action processed successfully:", actionType, "by", originalPlayerName);
      return c.json({ message: responseMessage, gameState: gameData });

    } catch (error) {
      console.error("Send action error:", error);
      return c.json({ error: "Internal server error" }, 500);
    }
  });
}
